#version 330 compatibility
#define VERTEX_SHADER
#define END
#define SPIDEREYES_PASS
#include "/program/gbuffers_terrain.glsl"
