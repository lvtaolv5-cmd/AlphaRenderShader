#include "/lib/settings.glsl"
#include "/lib/common.glsl"

/* ============================================================================
   AlphaRender - Hardware Early-Z Depth-Only Solid Shadow Pass (shadow_solid)
   ZERO texture fetches, ZERO alpha discard -> full GPU Hi-Z depth-only speed!
   ============================================================================ */

#ifdef VERTEX_SHADER

#include "/lib/shadows.glsl"

void main() {
    #ifdef SHADOW_ENABLED
    #if !defined(NETHER) && !defined(END)
        vec4 clipPos = gl_ProjectionMatrix * (gl_ModelViewMatrix * gl_Vertex);
        float invW = 1.0 / max(abs(clipPos.w), 1e-5);
        clipPos.xy = distortShadowXY(clipPos.xy * invW) * abs(clipPos.w);
        gl_Position = clipPos;
    #else
        gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
    #endif
    #else
        gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
    #endif
}

#endif // VERTEX_SHADER

#ifdef FRAGMENT_SHADER

/* RENDERTARGETS:0 */
layout(location = 0) out vec4 outShadowColor;

void main() {
    // No texture() fetch and no discard -> unlocks full GPU Early-Z depth-only rasterization!
    outShadowColor = vec4(1.0);
}

#endif // FRAGMENT_SHADER
