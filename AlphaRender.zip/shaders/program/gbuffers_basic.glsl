#include "/lib/settings.glsl"
#include "/lib/common.glsl"

#ifdef VERTEX_SHADER

uniform mat4 gbufferModelViewInverse;
uniform vec3 cameraPosition;
uniform int renderStage;

out vec4 vColor;
out vec3 vWorldPos;
flat out int vIsOutline;

void main() {
    vColor = gl_Color;
    vec4 mvPos = gl_ModelViewMatrix * gl_Vertex;
    vWorldPos = (gbufferModelViewInverse * mvPos).xyz + cameraPosition;

    int isOutline = 0;
    #ifdef MC_RENDER_STAGE_OUTLINE
        if (renderStage == MC_RENDER_STAGE_OUTLINE) {
            isOutline = 1;
        }
    #endif
    vIsOutline = isOutline;

    gl_Position = gl_ProjectionMatrix * mvPos;
}

#endif // VERTEX_SHADER

#ifdef FRAGMENT_SHADER

uniform float frameTimeCounter;

in vec4 vColor;
in vec3 vWorldPos;
flat in int vIsOutline;

/* RENDERTARGETS:0,1,2 */
layout(location = 0) out vec4 outColor;
layout(location = 1) out vec4 outNormalMat;
layout(location = 2) out vec4 outEmissive;

void main() {
    if (vColor.a < 0.005) discard;

    // Fallback outline support if drawn through gbuffers_basic
    if (vIsOutline == 1) {
        #if SELECT_BOX_MODE == 5
            discard;
        #endif
        vec3 outlineSrgb = vec3(0.0);
        float outlineAlpha = float(SELECT_BOX_ALPHA);
        #if SELECT_BOX_MODE == 0
            outlineSrgb = vec3(0.0);
            outlineAlpha = min(outlineAlpha, 0.55);
        #elif SELECT_BOX_MODE == 1
            outlineSrgb = vec3(float(SELECT_BOX_R), float(SELECT_BOX_G), float(SELECT_BOX_B)) / 255.0;
        #elif SELECT_BOX_MODE == 2
            float hue = fract(frameTimeCounter * 0.22 * float(SELECT_BOX_PULSE_SPEED) + dot(vWorldPos, vec3(0.28, 0.36, 0.24)));
            outlineSrgb = hsvToRgb(vec3(hue, 0.90, 1.0));
        #elif SELECT_BOX_MODE == 3
            vec3 baseRgb = vec3(float(SELECT_BOX_R), float(SELECT_BOX_G), float(SELECT_BOX_B)) / 255.0;
            float pulse = 0.45 + 0.55 * (0.5 + 0.5 * sin(frameTimeCounter * 3.14159 * float(SELECT_BOX_PULSE_SPEED)));
            outlineSrgb = baseRgb * pulse;
        #else
            outlineSrgb = vec3(0.32, 0.90, 1.00);
        #endif

        if (maxOf(outlineSrgb) > 0.004) {
            vec3 hdrOutline = srgbToLinear(outlineSrgb) * float(SELECT_BOX_BRIGHTNESS);
            outColor     = vec4(hdrOutline, outlineAlpha);
            outNormalMat = vec4(0.5, 0.5, MAT_OUTLINE, 1.0);
            outEmissive  = vec4(saturate(hdrOutline * outlineAlpha * 0.25), 1.0);
        } else {
            outColor     = vec4(0.0, 0.0, 0.0, outlineAlpha);
            outNormalMat = vec4(0.5, 0.5, MAT_OUTLINE, 0.0);
            outEmissive  = vec4(0.0);
        }
        return;
    }

    outColor = vec4(srgbToLinear(vColor.rgb), vColor.a);
    outNormalMat = vec4(0.5, 0.5, MAT_SOLID, 0.5);
    outEmissive = vec4(0.0);
}

#endif // FRAGMENT_SHADER
