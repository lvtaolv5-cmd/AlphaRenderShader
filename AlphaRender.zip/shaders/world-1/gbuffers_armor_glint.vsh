#version 330 compatibility
#define VERTEX_SHADER
#define NETHER
#define ARMOR_GLINT_PASS
#include "/program/gbuffers_terrain.glsl"
