#version 330 compatibility
#define FRAGMENT_SHADER
#define NETHER
#define SPIDEREYES_PASS
#include "/program/gbuffers_terrain.glsl"
