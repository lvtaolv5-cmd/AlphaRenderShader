#version 330 compatibility
#define VERTEX_SHADER
#define OVERWORLD
#define TEXTURED_PASS
#include "/program/gbuffers_terrain.glsl"
