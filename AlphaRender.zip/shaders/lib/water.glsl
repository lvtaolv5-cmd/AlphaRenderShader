#ifndef LIB_WATER_GLSL
#define LIB_WATER_GLSL

#include "/lib/colorStyles.glsl"

/* ============================================================================
   AlphaRender - High-Speed Analytic 4-Mode Water Engine
   All colortex3 refraction & SSR runs strictly in composite.glsl (100% Vulkan-safe,
   ZERO unbound gbuffer samplers, ZERO render-target feedback loops!).
   Modes:
     0: Vanilla Water          (原版水 - Sildur's Basic Fancy faithful)
     1: Vanilla Tinted Water   (原版上色水 - Sildur's Enhanced Default Fancy)
     2: Pure Non-Vanilla Water (纯非原版水 - Clean smooth stylized crystal water)
     3: Realistic PBR Water    (真实水 - 5-octave directional swells, Beer-Lambert
                                depth absorption, 3D seabed refraction & caustics,
                                shoreline foam & binary-refined SSR!)
   ============================================================================ */

// Fast analytic rotated directional trochoidal wavelets (ZERO square noise artifacts!)
// Returns vec3(dH/dx, dH/dz, height)
vec3 computeWaterWaveGrad(vec2 xz, float timeSec, float distToCam, bool highDetail) {
    float str = float(WATER_WAVES_STRENGTH);
    if (str <= 0.001) return vec3(0.0);

    float t = timeSec * float(WATER_WAVE_SPEED) * 1.45;
    float distAtten = exp(-distToCam * 0.0075);
    if (distAtten < 0.02) return vec3(0.0);

    vec2 grad = vec2(0.0);
    float height = 0.0;

    {
        vec2 d1 = vec2(0.866, 0.500);
        float f1 = 1.65;
        float p1 = dot(xz, d1) * f1 + t * 1.35;
        float a1 = 0.052;
        height += (sin(p1) + 0.25 * sin(2.0 * p1)) * a1;
        grad   += d1 * (f1 * a1 * (cos(p1) + 0.50 * cos(2.0 * p1)));
    }
    {
        vec2 d2 = vec2(-0.588, 0.809);
        float f2 = 2.45;
        float p2 = dot(xz, d2) * f2 - t * 1.72 + 1.1;
        float a2 = 0.036;
        height += (sin(p2) + 0.22 * sin(2.0 * p2)) * a2;
        grad   += d2 * (f2 * a2 * (cos(p2) + 0.44 * cos(2.0 * p2)));
    }
    {
        vec2 d3 = vec2(0.242, -0.970);
        float f3 = 4.10;
        float p3 = dot(xz, d3) * f3 + t * 2.25 + 2.4;
        float a3 = 0.020;
        height += sin(p3) * a3;
        grad   += d3 * (f3 * a3 * cos(p3));
    }
    {
        vec2 d4 = vec2(-0.924, -0.383);
        float f4 = 6.80;
        float p4 = dot(xz, d4) * f4 - t * 2.95 + 0.7;
        float a4 = 0.011;
        height += sin(p4) * a4;
        grad   += d4 * (f4 * a4 * cos(p4));
    }

    if (highDetail && distToCam < 48.0) {
        float nearAtten = 1.0 - smoothstep(18.0, 48.0, distToCam);
        vec2 d5 = vec2(0.707, -0.707);
        float f5 = 11.5;
        float p5 = dot(xz, d5) * f5 + t * 3.60 + height * 4.5;
        float a5 = 0.0055 * nearAtten;
        height += sin(p5) * a5;
        grad   += d5 * (f5 * a5 * cos(p5));
    }

    return vec3(grad * str * distAtten, height * str * distAtten);
}

vec3 computeWaterWorldNormal(vec3 worldPos, vec3 geoWorldNormal, float timeSec, float distToCam, bool highDetail, out vec2 waveSlope, out float waveH) {
    waveSlope = vec2(0.0);
    waveH = 0.0;
    vec3 gNorm = safeNormalize(geoWorldNormal);

    // Vertical flowing waterfalls get downward-scrolling ripple normals!
    if (abs(gNorm.y) < 0.35) {
        float str = float(WATER_WAVES_STRENGTH) * exp(-distToCam * 0.01);
        float flowT = timeSec * float(WATER_WAVE_SPEED) * 4.2;
        float horiz = abs(gNorm.x) > 0.5 ? worldPos.z : worldPos.x;
        float r1 = cos(worldPos.y * 5.0 + flowT + horiz * 2.2) * 0.14 * str;
        float r2 = cos(horiz * 7.5 - worldPos.y * 3.2 - flowT * 0.8) * 0.08 * str;
        waveSlope = vec2(r2, r1);
        vec3 tangent = abs(gNorm.x) > 0.5 ? vec3(0.0, 0.0, 1.0) : vec3(1.0, 0.0, 0.0);
        return safeNormalize(gNorm + tangent * r2 + vec3(0.0, r1, 0.0));
    }

    vec3 wh = computeWaterWaveGrad(worldPos.xz, timeSec, distToCam, highDetail);
    waveSlope = wh.xy;
    waveH = wh.z;
    float normalScale = highDetail ? 0.52 : 0.36;
    return safeNormalize(vec3(-wh.x * normalScale, sign(gNorm.y), -wh.y * normalScale));
}

// Fast underwater sunlight caustics projected directly onto 3D seabed world XZ!
float computeWaterCaustics(vec2 xz, float timeSec) {
    float t = timeSec * float(WATER_WAVE_SPEED) * 1.4;
    float w1 = sin(xz.x * 2.7 + xz.y * 1.4 + t * 1.5) + cos(xz.x * 1.8 - xz.y * 2.9 - t * 1.2);
    float w2 = sin(xz.x * 3.5 - xz.y * 2.1 - t * 1.8) + cos(xz.x * 2.2 + xz.y * 3.4 + t * 1.3);
    return pow(saturate(1.0 - abs(w1 * 0.35 - w2 * 0.35)), 5.0);
}

// Fast Exponential + Binary-Refined Screen-Space Reflections (runs strictly in composite.glsl!)
vec4 traceFastWaterSSR(
    vec3 viewPos,
    vec3 viewNormal,
    mat4 proj,
    float nearPlane,
    float farPlane,
    vec2 fragCoord,
    int frameCounter,
    sampler2D opaqueSceneTex,
    sampler2D opaqueDepthTex
) {
    #ifdef WATER_REFLECTIONS
    #ifdef WATER_SSR_ENABLED
        // Far ocean (> 96 blocks) reflects pure atmospheric sky — skip SSR raymarch!
        if (dot(viewPos, viewPos) > 9216.0) return vec4(0.0);

        vec3 V = safeNormalize(viewPos);
        vec3 R = reflect(V, viewNormal);
        if (R.z > 0.22) return vec4(0.0);

        float dither = interleavedGradientNoiseTemporal(fragCoord, frameCounter);
        vec3 rayDir = R * (0.65 + 0.35 * dither);
        vec3 rayPos = viewPos + viewNormal * 0.06 + rayDir;

        const int MAX_STEPS = WATER_SSR_STEPS;
        int refineCount = 0;

        for (int i = 0; i < MAX_STEPS; i++) {
            vec3 screenPos = viewToScreen(rayPos, proj);
            if (screenPos.x < 0.002 || screenPos.x > 0.998 || screenPos.y < 0.002 || screenPos.y > 0.998 || screenPos.z <= 0.0 || screenPos.z >= 1.0) {
                break;
            }

            float bufDepth = texture(opaqueDepthTex, screenPos.xy).r;
            if (bufDepth < 0.99985 && screenPos.z > bufDepth) {
                float rayLin = linearizeDepth(screenPos.z, nearPlane, farPlane);
                float bufLin = linearizeDepth(bufDepth, nearPlane, farPlane);
                float diff = rayLin - bufLin;

                if (diff > 0.0 && diff < max(1.2, length(rayDir) * 1.9)) {
                    refineCount++;
                    if (refineCount >= 3 || i >= MAX_STEPS - 1) {
                        vec2 border = smoothstep(vec2(0.0), vec2(0.10), screenPos.xy) * smoothstep(vec2(1.0), vec2(0.90), screenPos.xy);
                        float fade = border.x * border.y * (1.0 - float(i) / float(MAX_STEPS) * 0.30);
                        vec3 hitCol = sanitizeHDR(texture(opaqueSceneTex, screenPos.xy).rgb);
                        return vec4(hitCol, saturate(fade));
                    }
                    rayPos -= rayDir;
                    rayDir *= 0.35;
                    rayPos += rayDir;
                    continue;
                }
            }

            rayDir *= 1.38;
            rayPos += rayDir;
        }
        return vec4(0.0);
    #else
        return vec4(0.0);
    #endif
    #else
        return vec4(0.0);
    #endif
}

#endif // LIB_WATER_GLSL
