#include "/lib/settings.glsl"
#include "/lib/common.glsl"

#ifdef VERTEX_SHADER

out vec2 vTexCoord;

void main() {
    vTexCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    gl_Position = ftransform();
}

#endif // VERTEX_SHADER

#ifdef FRAGMENT_SHADER

#include "/lib/atmosphere.glsl"

uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D depthtex0;

uniform mat4 gbufferProjection;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;

uniform vec3 sunPosition;
uniform vec3 upPosition;
uniform vec3 fogColor;
uniform float near;
uniform float far;
uniform float viewWidth;
uniform float viewHeight;
uniform float rainStrength;
uniform int frameCounter;
uniform int isEyeInWater;

in vec2 vTexCoord;

/* RENDERTARGETS:0,3 */
layout(location = 0) out vec4 outColor;
layout(location = 1) out vec4 outOpaqueCopy;

// Fast Hemisphere SSAO (early distance cull + lean tap count)
float computeSSAO(vec2 uv, vec3 viewPos, vec3 viewNormal, float linearD) {
    #ifndef SSAO_ENABLED
        return 1.0;
    #else
        if (linearD > 38.0) return 1.0;

        #if SSAO_QUALITY == 1
            const int AO_TAPS = 4;
        #elif SSAO_QUALITY == 2
            const int AO_TAPS = 8;
        #else
            const int AO_TAPS = 12;
        #endif

        float distFade = 1.0 - smoothstep(22.0, 38.0, linearD);
        float radiusWorld = 0.55 * float(SSAO_RADIUS) * clamp(linearD * 0.08 + 0.6, 0.6, 2.0);
        float projScale = gbufferProjection[1][1] * 0.5;
        vec2 radiusUV = vec2(radiusWorld * projScale / max(linearD, 0.35));
        radiusUV.x *= viewHeight / max(viewWidth, 1.0);
        radiusUV = clamp(radiusUV, vec2(0.002), vec2(0.050));

        float rot = interleavedGradientNoiseTemporal(gl_FragCoord.xy, frameCounter) * TAU;
        float occ = 0.0;

        for (int i = 0; i < AO_TAPS; i++) {
            float r = sqrt((float(i) + 0.5) / float(AO_TAPS));
            float theta = float(i) * GOLDEN_ANGLE + rot;
            vec2 off = vec2(cos(theta), sin(theta)) * r * radiusUV;
            vec2 sUV = clamp(uv + off, vec2(0.001), vec2(0.999));

            float sDepth = texture(depthtex0, sUV).r;
            if (sDepth >= 0.9999) continue;

            vec3 sViewPos = screenToView(vec3(sUV, sDepth), gbufferProjectionInverse);
            vec3 diff = sViewPos - viewPos;
            float dist = length(diff);
            if (dist < 0.015) continue;

            vec3 dir = diff / dist;
            float nDot = max(dot(viewNormal, dir) - 0.12, 0.0);
            float rangeCheck = smoothstep(radiusWorld * 2.2, radiusWorld * 0.35, dist);
            occ += nDot * rangeCheck;
        }

        occ = saturate((occ / float(AO_TAPS)) * 2.35 * float(SSAO_STRENGTH) * distFade);
        return clamp(1.0 - occ, 0.24, 1.0);
    #endif
}

void main() {
    vec4 sceneData = texture(colortex0, vTexCoord);
    vec3 color = sanitizeHDR(sceneData.rgb);
    float depth = texture(depthtex0, vTexCoord).r;

    // Sky pixels pass straight through without SSAO or fog
    if (depth >= 0.99995) {
        vec4 res = vec4(color, sceneData.a);
        outColor = res;
        outOpaqueCopy = res;
        return;
    }

    vec4 normMat = texture(colortex1, vTexCoord);
    float matId = normMat.z;

    // First-person hand skips SSAO and distance fog
    if (abs(matId - MAT_HAND) < 0.06 || depth < 0.56) {
        vec4 res = vec4(color, sceneData.a);
        outColor = res;
        outOpaqueCopy = res;
        return;
    }

    vec3 viewPos = screenToView(vec3(vTexCoord, depth), gbufferProjectionInverse);
    vec3 viewNormal = decodeNormal(normMat.xy);
    float linD = linearizeDepth(depth, near, far);

    float ssao = computeSSAO(vTexCoord, viewPos, viewNormal, linD);
    color *= ssao;

    vec3 playerPos = (gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz;
    color = applyAtmosphericFog(color, viewPos, playerPos, sunPosition, upPosition, far, rainStrength, isEyeInWater, fogColor);

    vec4 finalOut = vec4(sanitizeHDR(color), sceneData.a);
    outColor = finalOut;
    // Copy clean pre-water opaque scene to colortex3 for feedback-free Water Refraction & SSR!
    outOpaqueCopy = finalOut;
}

#endif // FRAGMENT_SHADER
