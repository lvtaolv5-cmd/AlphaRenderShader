#version 330 compatibility
#define FRAGMENT_SHADER
#define NETHER
#define ARMOR_GLINT_PASS
#include "/program/gbuffers_terrain.glsl"
