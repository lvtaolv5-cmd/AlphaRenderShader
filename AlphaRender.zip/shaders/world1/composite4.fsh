#version 330 compatibility
#define FRAGMENT_SHADER
#define END
#include "/program/composite4.glsl"
