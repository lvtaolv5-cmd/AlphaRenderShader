#ifndef LIB_SETTINGS_GLSL
#define LIB_SETTINGS_GLSL

/* ============================================================================
   AlphaRender Shaders - Master Configuration & Iris Pipeline Constants
   Target: Minecraft 26.3 Fabric + Iris 1.12.0+ (Vulkan & OpenGL)
   ============================================================================ */

// ---------- Iris / OptiFine Built-in Constants ----------
const int   shadowMapResolution   = 2048;  // [512 1024 1536 2048 3072 4096]
const float shadowDistance        = 144.0; // [64.0 80.0 96.0 112.0 128.0 144.0 160.0 192.0 256.0 320.0]
const float shadowDistanceRenderMul = 1.0;
const float shadowIntervalSize    = 2.0;
const bool  generateShadowMipmap  = false;
const bool  generateShadowColorMipmap = false;
const float sunPathRotation       = -30.0; // [-60.0 -45.0 -35.0 -30.0 -25.0 -15.0 0.0 15.0 30.0 45.0 60.0]
const float ambientOcclusionLevel = 0.85;  // [0.0 0.2 0.4 0.5 0.6 0.7 0.8 0.85 0.9 1.0]
const float centerDepthHalflife   = 1.0;   // [0.1 0.25 0.5 0.75 1.0 1.5 2.0 3.0 4.0]
const float wetnessHalflife       = 60.0;
const float drynessHalflife       = 120.0;
const float eyeBrightnessHalflife = 6.0;

// ---------- 1. Color Palette Styles (12 Styles) ----------
// 0: Classic Color | 1: Nostalgia Color | 2: Legecy Color | 3: Vanilla Enhanced
// 4: Cinematic Filmic | 5: Vibrant Fantasy | 6: Nordic Cold | 7: Golden Hour
// 8: Pastel Dream | 9: Dark Moody | 10: Cyber Neon | 11: Retro Warm Film
#define COLOR_STYLE 0 // [0 1 2 3 4 5 6 7 8 9 10 11]
#define COLOR_STYLE_STRENGTH 1.00 // [0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.10 1.20 1.30 1.40 1.50]

// ---------- 2. Overall Color Adjustment & RGB Tone ----------
// 0: ACES Filmic | 1: AgX | 2: Uncharted 2 | 3: Reinhard Ext | 4: Vanilla Neutral | 5: Exposure Only
#define TONEMAP_OPERATOR 0 // [0 1 2 3 4 5]
#define EXPOSURE 0.00 // [-2.00 -1.80 -1.60 -1.40 -1.20 -1.00 -0.80 -0.60 -0.40 -0.20 -0.10 0.00 0.10 0.20 0.40 0.60 0.80 1.00 1.20 1.40 1.60 1.80 2.00]
#define AUTO_EXPOSURE
#define AUTO_EXPOSURE_TARGET 0.22 // [0.10 0.12 0.14 0.16 0.18 0.20 0.22 0.24 0.26 0.28 0.30 0.34 0.38 0.42 0.46]
#define AUTO_EXPOSURE_MIN 0.45 // [0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.60 0.70 0.80 0.90 1.00]
#define AUTO_EXPOSURE_MAX 2.20 // [1.00 1.20 1.40 1.60 1.80 2.00 2.20 2.50 2.80 3.20 3.60 4.00]
#define AUTO_EXPOSURE_SPEED 1.40 // [0.20 0.40 0.60 0.80 1.00 1.20 1.40 1.80 2.20 2.80 3.40 4.00]

#define BRIGHTNESS 1.00 // [0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.50 1.60]
#define GAMMA 1.00 // [0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.40 1.50]
#define CONTRAST 1.00 // [0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.40 1.50 1.60]
#define SATURATION 1.00 // [0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.30 1.40 1.50 1.60 1.80 2.00]
#define VIBRANCE 0.10 // [-0.50 -0.40 -0.30 -0.20 -0.10 -0.05 0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.40 0.50 0.60 0.80 1.00]

// Global RGB Tone Multipliers
#define COLOR_TONE_R 1.00 // [0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.40 1.50 1.60 1.80 2.00]
#define COLOR_TONE_G 1.00 // [0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.40 1.50 1.60 1.80 2.00]
#define COLOR_TONE_B 1.00 // [0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.40 1.50 1.60 1.80 2.00]

// 3-Way RGB Color Balance (Shadows / Midtones / Highlights)
#define SHADOW_TINT_R 1.00 // [0.50 0.60 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.40 1.50]
#define SHADOW_TINT_G 1.00 // [0.50 0.60 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.40 1.50]
#define SHADOW_TINT_B 1.00 // [0.50 0.60 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.40 1.50]

#define MIDTONE_TINT_R 1.00 // [0.50 0.60 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.40 1.50]
#define MIDTONE_TINT_G 1.00 // [0.50 0.60 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.40 1.50]
#define MIDTONE_TINT_B 1.00 // [0.50 0.60 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.40 1.50]

#define HIGHLIGHT_TINT_R 1.00 // [0.50 0.60 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.40 1.50]
#define HIGHLIGHT_TINT_G 1.00 // [0.50 0.60 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.40 1.50]
#define HIGHLIGHT_TINT_B 1.00 // [0.50 0.60 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.40 1.50]

#define COLOR_TEMPERATURE 0.00 // [-1.00 -0.80 -0.60 -0.40 -0.30 -0.20 -0.10 -0.05 0.00 0.05 0.10 0.20 0.30 0.40 0.60 0.80 1.00]
#define COLOR_GREEN_MAGENTA 0.00 // [-1.00 -0.80 -0.60 -0.40 -0.30 -0.20 -0.10 -0.05 0.00 0.05 0.10 0.20 0.30 0.40 0.60 0.80 1.00]

// ---------- 3. Bloom (Multi-Octave HDR) ----------
#define BLOOM_ENABLED
#define BLOOM_QUALITY 3 // [1 2 3 4 5]
#define BLOOM_STRENGTH 0.45 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.70 0.80 0.90 1.00 1.20 1.40 1.60 2.00 2.50]
#define BLOOM_THRESHOLD 0.75 // [0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.75 0.80 0.90 1.00 1.20 1.40 1.60 1.80 2.00]
#define BLOOM_KNEE 0.50 // [0.05 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00]
#define BLOOM_RADIUS 1.00 // [0.50 0.60 0.70 0.80 0.90 1.00 1.10 1.20 1.35 1.50 1.75 2.00]
#define BLOOM_SATURATION 1.10 // [0.00 0.20 0.40 0.60 0.80 0.90 1.00 1.10 1.20 1.35 1.50 1.75 2.00]
#define BLOOM_EMISSIVE_BOOST 1.20 // [0.00 0.20 0.40 0.60 0.80 1.00 1.20 1.40 1.60 1.80 2.00 2.50 3.00]
#define BLOOM_FIREFLY_CLAMP 12.0 // [2.0 4.0 6.0 8.0 10.0 12.0 16.0 24.0 32.0]
#define BLOOM_TINT_R 1.00 // [0.50 0.60 0.70 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.30 1.40 1.50]
#define BLOOM_TINT_G 1.00 // [0.50 0.60 0.70 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.30 1.40 1.50]
#define BLOOM_TINT_B 1.00 // [0.50 0.60 0.70 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.30 1.40 1.50]

// ---------- 4. Optical Glare / Light Scatter ----------
#define GLARE_ENABLED
// 0: Soft Halo | 1: Anamorphic Streak | 2: Starburst 4-Ray | 3: Starburst 6-Ray | 4: Full Optical Combine
#define GLARE_MODE 4 // [0 1 2 3 4]
#define GLARE_QUALITY 2 // [1 2 3 4]
#define GLARE_STRENGTH 0.35 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.60 0.75 0.90 1.10 1.40 1.80 2.50]
#define GLARE_THRESHOLD 0.95 // [0.00 0.15 0.30 0.45 0.60 0.75 0.85 0.95 1.10 1.30 1.60 2.00 2.50]
#define GLARE_RADIUS 1.10 // [0.40 0.60 0.80 0.95 1.10 1.30 1.50 1.80 2.10 2.50]
#define GLARE_CHROMA 0.45 // [0.00 0.10 0.20 0.30 0.45 0.60 0.80 1.00 1.30 1.60 2.00]
#define GLARE_ROTATION 20.0 // [0.0 10.0 15.0 20.0 30.0 45.0 60.0 75.0 90.0]

// ---------- 5. Depth of Field (Default DoF + Focus Blur + Reverse Focus + Manual + Tilt-Shift) ----------
#define DOF_ENABLED
// 0: Default DoF | 1: Focus Blur | 2: Reverse Focus Blur | 3: Manual Focus | 4: Tilt-Shift Miniature
#define DOF_MODE 0 // [0 1 2 3 4]
#define DOF_QUALITY 2 // [1 2 3 4 5]
#define DOF_STRENGTH 1.00 // [0.10 0.20 0.30 0.40 0.50 0.60 0.75 0.90 1.00 1.20 1.40 1.60 2.00 2.50 3.00]
#define DOF_APERTURE 1.40 // [0.50 0.70 0.90 1.10 1.25 1.40 1.60 1.80 2.00 2.40 2.80 3.40 4.00]
#define DOF_MANUAL_DISTANCE 18.0 // [2.0 4.0 6.0 8.0 10.0 12.0 15.0 18.0 22.0 28.0 36.0 48.0 64.0 90.0 120.0]
#define DOF_FOCUS_SPOT_RADIUS 0.22 // [0.05 0.08 0.12 0.16 0.20 0.22 0.26 0.32 0.40 0.50 0.65]
#define DOF_FOCUS_SOFTNESS 0.35 // [0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.45 0.55 0.70 0.90]
#define DOF_NEAR_BLUR 0.80 // [0.00 0.20 0.40 0.60 0.80 1.00 1.20 1.50 2.00]
#define DOF_FAR_BLUR 1.00 // [0.00 0.20 0.40 0.60 0.80 1.00 1.20 1.50 2.00]
#define DOF_MAX_RADIUS 14.0 // [4.0 6.0 8.0 10.0 12.0 14.0 16.0 20.0 24.0 28.0 32.0]
// 0: Circle | 1: Hexagon | 2: Octagon
#define DOF_BOKEH_SHAPE 1 // [0 1 2]
#define DOF_BOKEH_HIGHLIGHT 0.50 // [0.00 0.15 0.30 0.50 0.75 1.00 1.30 1.60 2.00]
#define DOF_CHROMA_FRINGE 0.30 // [0.00 0.10 0.20 0.30 0.45 0.60 0.80 1.00 1.50 2.00]
//#define DOF_BLUR_HAND

// ---------- 6. Anti-Aliasing Suite (TAA Far-Sharpness Fixed!) ----------
// 0: Off | 1: FXAA | 2: MSAA (Depth+Normal RGSS) | 3: SMAA | 4: TAA | 5: TAA + FXAA | 6: TAA + MSAA
#define AA_MODE 4 // [0 1 2 3 4 5 6]
#define MSAA_SAMPLES 4 // [2 4 8]
#define MSAA_EDGE_THRESHOLD 0.20 // [0.05 0.10 0.15 0.20 0.25 0.30 0.40 0.50 0.60]
#define MSAA_TEMPORAL_RGSS
#define FXAA_QUALITY 3 // [1 2 3 4]
#define FXAA_SUBPIX 0.75 // [0.00 0.15 0.25 0.40 0.50 0.65 0.75 0.85 0.95 1.00]
#define FXAA_EDGE_THRESHOLD 0.12 // [0.04 0.06 0.08 0.10 0.12 0.15 0.18 0.22 0.25]
#define TAA_BLEND_FACTOR 0.84 // [0.60 0.66 0.72 0.76 0.80 0.84 0.88 0.90 0.92 0.94 0.96]
#define TAA_JITTER_SCALE 0.75 // [0.25 0.40 0.50 0.65 0.75 0.85 1.00 1.15 1.30 1.50]
#define TAA_VARIANCE_GAMMA 1.05 // [0.50 0.65 0.75 0.85 0.95 1.05 1.15 1.25 1.40 1.60 1.80 2.00]
#define TAA_FAR_SHARPNESS 0.85 // [0.00 0.15 0.30 0.45 0.60 0.75 0.85 1.00 1.20 1.40]
#define TAA_BICUBIC_HISTORY
#define AA_SHARPENING 0.45 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.60 0.75 0.90 1.00]

// ---------- 7. Block Selection Outline (RGB + !Black Bloom/Glare Target) ----------
// 0: Vanilla Black | 1: Custom RGB | 2: Rainbow Flow | 3: Breathing RGB | 4: Auto Accent | 5: Hidden
#define SELECT_BOX_MODE 1 // [0 1 2 3 4 5]
#define SELECT_BOX_R 0 // [0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
#define SELECT_BOX_G 210 // [0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
#define SELECT_BOX_B 255 // [0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255]
#define SELECT_BOX_ALPHA 0.90 // [0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.85 0.90 0.95 1.00]
#define SELECT_BOX_WIDTH 2.5 // [1.0 1.5 2.0 2.5 3.0 3.5 4.0 4.5 5.0 6.0]
#define SELECT_BOX_BRIGHTNESS 1.60 // [0.50 0.70 0.90 1.00 1.20 1.40 1.60 1.80 2.00 2.40 2.80 3.40 4.00]
#define SELECT_BOX_BLOOM_MULT 1.20 // [0.00 0.20 0.40 0.60 0.80 1.00 1.20 1.50 1.80 2.20 2.60 3.00]
#define SELECT_BOX_GLARE_MULT 1.10 // [0.00 0.20 0.40 0.60 0.80 1.00 1.10 1.40 1.70 2.10 2.50 3.00]
#define SELECT_BOX_PULSE_SPEED 1.00 // [0.20 0.40 0.60 0.80 1.00 1.25 1.50 2.00 2.50 3.00]

// ---------- 8. Lighting, Hybrid Non-Realtime + Forced Pixel Shadows (Cool Default!), SSAO & Emissives ----------
#define SHADOW_ENABLED
// Forced Pixel-Locked Shadows (Always Enabled across Terrain, Entities & Block Entities!)
#define SHADOW_PIXEL 16 // [8 16 32 64]
#define SHADOW_QUALITY 2 // [1 2 3 4]
#define SHADOW_SOFTNESS 0.25 // [0.00 0.10 0.15 0.20 0.25 0.35 0.50 0.75 1.00 1.50 2.00]
#define SHADOW_COLORED
#define SHADOW_BIAS 1.00 // [0.50 0.65 0.80 0.90 1.00 1.15 1.30 1.50 1.75 2.00]
#define NON_REALTIME_SHADOW 1.00 // [0.00 0.20 0.40 0.60 0.80 1.00 1.15 1.30 1.50]
#define REALTIME_SHADOW_STRENGTH 1.00 // [0.00 0.20 0.40 0.60 0.80 1.00 1.15 1.30 1.50]

// Default Cool Shadow Color (Crisp Cool Azure-Blue Shadows)
#define SHADOW_COLOR_STRENGTH 1.00 // [0.00 0.20 0.40 0.60 0.80 1.00 1.15 1.30 1.50]
#define SHADOW_COLOR_R 0.56 // [0.20 0.30 0.40 0.48 0.56 0.64 0.72 0.80 0.90 1.00 1.15 1.30]
#define SHADOW_COLOR_G 0.78 // [0.20 0.35 0.50 0.60 0.70 0.78 0.86 0.94 1.00 1.15 1.30]
#define SHADOW_COLOR_B 1.26 // [0.40 0.60 0.80 0.95 1.05 1.15 1.26 1.35 1.45 1.60]

#define SUN_INTENSITY 1.00 // [0.40 0.55 0.70 0.85 1.00 1.15 1.30 1.50 1.75 2.00]
#define MOON_INTENSITY 1.00 // [0.20 0.40 0.60 0.80 1.00 1.20 1.40 1.70 2.00]
#define AMBIENT_INTENSITY 1.00 // [0.40 0.55 0.70 0.85 1.00 1.15 1.30 1.50 1.75 2.00]
#define BLOCKLIGHT_INTENSITY 1.10 // [0.40 0.60 0.80 0.95 1.10 1.25 1.45 1.70 2.00 2.50]
#define BLOCKLIGHT_WARMTH 1.00 // [0.00 0.25 0.50 0.75 1.00 1.25 1.50]
#define DYNAMIC_HANDLIGHT

#define SSAO_ENABLED
#define SSAO_QUALITY 1 // [1 2 3]
#define SSAO_STRENGTH 0.85 // [0.20 0.35 0.50 0.65 0.85 0.95 1.00 1.05 1.20 1.50 1.80 2.00]
#define SSAO_RADIUS 1.10 // [0.40 0.60 0.80 1.00 1.10 1.30 1.60 2.00 2.50]

#define EMISSIVE_BLOCKS
#define EMISSIVE_ORES
#define EMISSIVE_STRENGTH 1.30 // [0.40 0.60 0.80 1.00 1.15 1.30 1.50 1.80 2.20 2.60 3.00]
#define FOLIAGE_SSS
#define RAIN_WETNESS

// ---------- 9. Atmosphere, Sky, Fog, Godrays, Water (4 Modes) & Waving ----------
#define SKY_INTENSITY 1.00 // [0.50 0.65 0.80 0.90 1.00 1.15 1.30 1.50 1.75 2.00]
#define FOG_ENABLED
#define FOG_DENSITY 1.00 // [0.10 0.25 0.40 0.60 0.80 1.00 1.25 1.50 1.80 2.20 2.50]
#define HEIGHT_FOG 0.60 // [0.00 0.15 0.30 0.45 0.60 0.80 1.00 1.30 1.60 2.00]

#define LIGHT_SHAFTS_ENABLED
#define LIGHT_SHAFTS_QUALITY 2 // [1 2 3]
#define LIGHT_SHAFTS_STRENGTH 0.75 // [0.10 0.25 0.40 0.55 0.75 0.85 0.95 1.20 1.50 2.00]

// Water Style Mode:
// 0: Vanilla (原版水) | 1: Vanilla Tinted / Enhanced (原版上色水)
// 2: Pure Non-Vanilla (纯非原版水) | 3: Realistic PBR Water (真实水)
#define WATER_MODE 3 // [0 1 2 3]
#define WATER_REFLECTIONS
#define WATER_REFRACTION
#define WATER_FOAM
#define WATER_WAVES_STRENGTH 1.00 // [0.00 0.25 0.50 0.75 1.00 1.10 1.25 1.50 2.00]
#define WATER_WAVE_SPEED 1.00 // [0.20 0.40 0.60 0.80 1.00 1.25 1.50 2.00 2.50]
#define WATER_SSR_ENABLED
#define WATER_SSR_STEPS 14 // [8 12 14 20 28]
#define WATER_ABSORPTION 1.00 // [0.20 0.40 0.60 0.80 1.00 1.25 1.50 2.00]
#define WATER_CAUSTICS

#define WAVING_FOLIAGE
#define WAVING_WATER
#define WAVING_SPEED 1.00 // [0.20 0.40 0.60 0.80 1.00 1.25 1.50 2.00 2.50]

// ---------- 10. Post Lens Effects ----------
#define VIGNETTE_ENABLED
#define VIGNETTE_STRENGTH 0.28 // [0.05 0.10 0.15 0.20 0.28 0.35 0.45 0.55 0.70 0.85 1.00]
#define VIGNETTE_RADIUS 0.85 // [0.40 0.50 0.60 0.70 0.75 0.85 0.95 1.05 1.20]
//#define CA_ENABLED
#define CA_STRENGTH 0.40 // [0.10 0.20 0.30 0.40 0.55 0.75 1.00 1.40 2.00]
#define FILM_GRAIN 0.00 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.40 0.50]

// ---------- Derived Helper Macros ----------
#define AA_USES_TAA (AA_MODE == 4 || AA_MODE == 5 || AA_MODE == 6)
#define AA_USES_MSAA (AA_MODE == 2 || AA_MODE == 6)
#define AA_USES_FXAA (AA_MODE == 1 || AA_MODE == 5)
#define AA_USES_SMAA (AA_MODE == 3)

// Material IDs encoded into colortex1.z
#define MAT_SKY       0.00
#define MAT_SOLID     0.15
#define MAT_FOLIAGE   0.30
#define MAT_WATER     0.45
#define MAT_TRANS     0.60
#define MAT_HAND      0.75
#define MAT_OUTLINE   0.90

#endif // LIB_SETTINGS_GLSL
