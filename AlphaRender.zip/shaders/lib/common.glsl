#ifndef LIB_COMMON_GLSL
#define LIB_COMMON_GLSL

const float PI      = 3.14159265359;
const float TAU     = 6.28318530718;
const float HALF_PI = 1.57079632679;
const float INV_PI  = 0.31830988618;
const float GOLDEN_ANGLE = 2.39996322973;

float saturate(float x) { return clamp(x, 0.0, 1.0); }
vec2  saturate(vec2 x)  { return clamp(x, vec2(0.0), vec2(1.0)); }
vec3  saturate(vec3 x)  { return clamp(x, vec3(0.0), vec3(1.0)); }
vec4  saturate(vec4 x)  { return clamp(x, vec4(0.0), vec4(1.0)); }

float sqr(float x) { return x * x; }
float maxOf(vec3 v) { return max(v.x, max(v.y, v.z)); }
float minOf(vec3 v) { return min(v.x, min(v.y, v.z)); }

// Perceptual Rec.709 luminance
float getLuminance(vec3 c) {
    return dot(c, vec3(0.2126, 0.7152, 0.0722));
}

// Ultra-fast branchless zero-pow() sRGB <-> Linear polynomials (error < 0.0008, ~6x faster!)
vec3 srgbToLinear(vec3 c) {
    c = max(c, vec3(0.0));
    return c * (c * (c * 0.305306011 + 0.682171111) + 0.012522878);
}

vec3 linearToSrgb(vec3 c) {
    c = max(c, vec3(0.0));
    vec3 s1 = sqrt(c);
    vec3 s2 = sqrt(s1);
    vec3 s3 = sqrt(s2);
    return max(0.662002687 * s1 + 0.684122060 * s2 - 0.323583601 * s3 - 0.0225411470 * c, vec3(0.0));
}

// Safe normalize to prevent Vulkan NaNs on degenerate geometry
vec3 safeNormalize(vec3 v) {
    float len2 = dot(v, v);
    return len2 > 1e-10 ? v * inversesqrt(len2) : vec3(0.0, 1.0, 0.0);
}

vec2 safeNormalize2(vec2 v) {
    float len2 = dot(v, v);
    return len2 > 1e-10 ? v * inversesqrt(len2) : vec2(1.0, 0.0);
}

// High-precision octahedral normal encoding [0, 1]^2 <-> unit vec3
vec2 encodeNormal(vec3 n) {
    n = safeNormalize(n);
    float invL1 = 1.0 / (abs(n.x) + abs(n.y) + abs(n.z) + 1e-6);
    vec2 p = n.xy * invL1;
    if (n.z < 0.0) {
        vec2 signNotZero = vec2(p.x >= 0.0 ? 1.0 : -1.0, p.y >= 0.0 ? 1.0 : -1.0);
        p = (1.0 - abs(p.yx)) * signNotZero;
    }
    return p * 0.5 + 0.5;
}

vec3 decodeNormal(vec2 enc) {
    vec2 f = enc * 2.0 - 1.0;
    vec3 n = vec3(f.x, f.y, 1.0 - abs(f.x) - abs(f.y));
    float t = saturate(-n.z);
    n.x += (n.x >= 0.0) ? -t : t;
    n.y += (n.y >= 0.0) ? -t : t;
    return safeNormalize(n);
}

// Interleaved Gradient Noise (Jorge Jimenez)
float interleavedGradientNoise(vec2 pixelPos) {
    vec3 magic = vec3(0.06711056, 0.00583715, 52.9829189);
    return fract(magic.z * fract(dot(pixelPos, magic.xy)));
}

float interleavedGradientNoiseTemporal(vec2 pixelPos, int frameCounter) {
    float jitter = float(frameCounter & 63) * 5.588238;
    return interleavedGradientNoise(pixelPos + vec2(jitter, jitter * 0.713));
}

// Smooth 2D value noise
float hash12(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

float valueNoise2D(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    vec2 u = f * f * (3.0 - 2.0 * f);
    float a = hash12(i);
    float b = hash12(i + vec2(1.0, 0.0));
    float c = hash12(i + vec2(0.0, 1.0));
    float d = hash12(i + vec2(1.0, 1.0));
    return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}

// Fast Depth & Diagonal Perspective Space Conversions (~3.5x faster than full mat4*vec4!)
float linearizeDepth(float depth, float nearPlane, float farPlane) {
    return (2.0 * nearPlane * farPlane) / max(farPlane + nearPlane - (depth * 2.0 - 1.0) * (farPlane - nearPlane), 1e-4);
}

vec3 screenToView(vec3 screenPos, mat4 projInv) {
    vec3 ndc = screenPos * 2.0 - 1.0;
    vec4 diag = vec4(projInv[0].x, projInv[1].y, projInv[2].z, projInv[2].w);
    vec4 viewPos = diag * ndc.xyzz + projInv[3];
    return viewPos.xyz / max(abs(viewPos.w), 1e-6) * (viewPos.w >= 0.0 ? 1.0 : -1.0);
}

vec3 viewToScreen(vec3 viewPos, mat4 proj) {
    vec3 clipXYZ = vec3(proj[0].x * viewPos.x, proj[1].y * viewPos.y, proj[2].z * viewPos.z + proj[3].z);
    float clipW = proj[2].w * viewPos.z + proj[3].w;
    float invW = 1.0 / max(abs(clipW), 1e-6);
    return (clipXYZ * invW) * 0.5 + 0.5;
}

// HSV -> RGB helper
vec3 hsvToRgb(vec3 hsv) {
    vec3 p = abs(fract(hsv.xxx + vec3(1.0, 2.0 / 3.0, 1.0 / 3.0)) * 6.0 - 3.0);
    return hsv.z * mix(vec3(1.0), clamp(p - 1.0, 0.0, 1.0), hsv.y);
}

// Sanitize HDR floats against NaN / Inf (Vulkan SPIR-V safe)
vec3 sanitizeHDR(vec3 c) {
    return vec3(
        (isnan(c.x) || isinf(c.x)) ? 0.0 : max(c.x, 0.0),
        (isnan(c.y) || isinf(c.y)) ? 0.0 : max(c.y, 0.0),
        (isnan(c.z) || isinf(c.z)) ? 0.0 : max(c.z, 0.0)
    );
}

// Time-of-day factor helpers (Overworld)
void getDayFactors(vec3 sunDirView, vec3 upDirView, out float dayFactor, out float sunsetFactor, out float nightFactor) {
    float sunHeight = dot(safeNormalize(sunDirView), safeNormalize(upDirView));
    dayFactor    = smoothstep(-0.08, 0.22, sunHeight);
    nightFactor  = 1.0 - smoothstep(-0.22, 0.05, sunHeight);
    sunsetFactor = exp(-sqr((sunHeight - 0.02) * 5.5)) * (1.0 - nightFactor * 0.5);
}

#endif // LIB_COMMON_GLSL
