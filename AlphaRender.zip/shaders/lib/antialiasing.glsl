#ifndef LIB_ANTIALIASING_GLSL
#define LIB_ANTIALIASING_GLSL

#include "/lib/jitter.glsl"

/* ============================================================================
   AlphaRender - Complete Anti-Aliasing Suite (TAA Far-View Blur Fixed!)
   Key TAA Fixes:
     1. Exact Velocity Dilation: prevUV = uv + (reproject(bestUV) - bestUV)
        (Fixes 1-pixel history offset smear across distant depth gradients!)
     2. Unjittered Reprojection + Pure-Rotation Sky/Infinity Reprojection
     3. Distance-Adaptive Dual Neighborhood Clamp (+ cross & 3x3 variance)
     4. Subpixel Resampling Blur Rejection (off-texel penalty during motion)
     5. Neighborhood-Clamped Catmull-Rom 5-Tap Bicubic Filter (zero ringing)
   ============================================================================ */

vec3 hdrToTaaSpace(vec3 c) {
    c = sanitizeHDR(c);
    return c / (1.0 + getLuminance(c));
}

vec3 taaSpaceToHdr(vec3 c) {
    c = max(c, vec3(0.0));
    return c / max(1.0 - getLuminance(c), 0.015);
}

vec3 rgbToYCoCg(vec3 c) {
    return vec3(
         0.25 * c.r + 0.50 * c.g + 0.25 * c.b,
         0.50 * c.r              - 0.50 * c.b,
        -0.25 * c.r + 0.50 * c.g - 0.25 * c.b
    );
}

vec3 yCoCgToRgb(vec3 c) {
    float tmp = c.x - c.z;
    return max(vec3(tmp + c.y, c.x + c.z, tmp - c.y), vec3(0.0));
}

// 5-tap optimized Catmull-Rom bicubic filter (preserves crisp distant textures)
vec3 sampleCatmullRom5(sampler2D tex, vec2 uv, vec2 texSize) {
    vec2 samplePos = uv * texSize;
    vec2 texPos1 = floor(samplePos - 0.5) + 0.5;
    vec2 f = samplePos - texPos1;
    vec2 f2 = f * f;
    vec2 f3 = f2 * f;

    vec2 w0 = f2 - 0.5 * (f3 + f);
    vec2 w1 = 1.5 * f3 - 2.5 * f2 + 1.0;
    vec2 w3 = 0.5 * (f3 - f2);
    vec2 w2 = 1.0 - w0 - w1 - w3;

    vec2 w12 = w1 + w2;
    vec2 offset12 = w2 / max(w12, vec2(1e-4));

    vec2 invSize = 1.0 / texSize;
    vec2 texPos0  = clamp((texPos1 - 1.0) * invSize, vec2(0.001), vec2(0.999));
    vec2 texPos3  = clamp((texPos1 + 2.0) * invSize, vec2(0.001), vec2(0.999));
    vec2 texPos12 = clamp((texPos1 + offset12) * invSize, vec2(0.001), vec2(0.999));

    vec3 res = vec3(0.0);
    res += texture(tex, vec2(texPos12.x, texPos0.y)).rgb  * (w12.x * w0.y);
    res += texture(tex, vec2(texPos0.x,  texPos12.y)).rgb * (w0.x  * w12.y);
    res += texture(tex, vec2(texPos12.x, texPos12.y)).rgb * (w12.x * w12.y);
    res += texture(tex, vec2(texPos3.x,  texPos12.y)).rgb * (w3.x  * w12.y);
    res += texture(tex, vec2(texPos12.x, texPos3.y)).rgb  * (w12.x * w3.y);

    float totalW = w12.x * w0.y + w0.x * w12.y + w12.x * w12.y + w3.x * w12.y + w12.x * w3.y;
    return max(res / max(totalW, 1e-4), vec3(0.0));
}

// Reproject an unjittered screen UV to previous frame UV (with infinity-safe sky rotation!)
vec2 reprojectScreenUV(
    vec2 unjitteredUV,
    float depth,
    mat4 projInv,
    mat4 mvInv,
    vec3 camPos,
    vec3 prevCamPos,
    mat4 prevMV,
    mat4 prevProj
) {
    vec3 viewPos = screenToView(vec3(unjitteredUV, depth), projInv);

    // For sky / extreme far horizon, use pure camera rotation to avoid 32-bit float translation drift!
    if (depth >= 0.9999) {
        vec3 worldDir = mat3(mvInv) * safeNormalize(viewPos);
        vec3 prevViewDir = mat3(prevMV) * worldDir;
        vec4 prevClip = prevProj * vec4(prevViewDir * 100.0, 1.0);
        if (prevClip.w <= 1e-5) return vec2(-1.0);
        return (prevClip.xy / prevClip.w) * 0.5 + 0.5;
    }

    vec4 feetPos = mvInv * vec4(viewPos, 1.0);
    vec3 prevFeet = feetPos.xyz + (camPos - prevCamPos);
    vec4 prevView = prevMV * vec4(prevFeet, 1.0);
    vec4 prevClip = prevProj * prevView;
    if (prevClip.w <= 1e-5) return vec2(-1.0);
    return (prevClip.xy / prevClip.w) * 0.5 + 0.5;
}

// ---------- Fixed Razor-Sharp TAA (Runs in composite5) ----------
vec3 computeTAA(
    vec2 uv,
    vec2 viewSize,
    float nearPlane,
    float farPlane,
    int frameCounter,
    sampler2D currTex,
    sampler2D histTex,
    sampler2D depthTex,
    sampler2D matTex,
    mat4 projInv,
    mat4 mvInv,
    vec3 camPos,
    vec3 prevCamPos,
    mat4 prevMV,
    mat4 prevProj
) {
    vec2 texel = 1.0 / viewSize;
    vec3 currHDR = sanitizeHDR(texture(currTex, uv).rgb);
    float centerDepth = texture(depthTex, uv).r;
    float matId = texture(matTex, uv).z;

    bool isHandOrOutline = (abs(matId - MAT_HAND) < 0.06) || (abs(matId - MAT_OUTLINE) < 0.06);
    bool isSky = (centerDepth >= 0.9999) || (abs(matId - MAT_SKY) < 0.04);

    // Fast 5-tap (+) depth search for velocity dilation + 9-tap YCoCg statistics
    // (Cuts depthtex0 fetches from 9 -> 5 while keeping razor-sharp far-terrain edges!)
    float minDepth = centerDepth;
    vec2 bestUV = uv;

    vec3 m1 = vec3(0.0);
    vec3 m2 = vec3(0.0);
    vec3 crossMin = vec3( 1e5);
    vec3 crossMax = vec3(-1e5);
    vec3 box3Min  = vec3( 1e5);
    vec3 box3Max  = vec3(-1e5);

    for (int y = -1; y <= 1; y++) {
        for (int x = -1; x <= 1; x++) {
            vec2 sUV = clamp(uv + vec2(float(x), float(y)) * texel, vec2(0.001), vec2(0.999));
            bool isCross = (x == 0 || y == 0);
            if (isCross && (x != 0 || y != 0)) {
                float d = texture(depthTex, sUV).r;
                if (d < minDepth) {
                    minDepth = d;
                    bestUV = sUV;
                }
            }
            vec3 sYCoCg = rgbToYCoCg(hdrToTaaSpace(texture(currTex, sUV).rgb));
            m1 += sYCoCg;
            m2 += sYCoCg * sYCoCg;
            box3Min = min(box3Min, sYCoCg);
            box3Max = max(box3Max, sYCoCg);
            if (isCross) {
                crossMin = min(crossMin, sYCoCg);
                crossMax = max(crossMax, sYCoCg);
            }
        }
    }

    // Distance factor: 0.0 near player, 1.0 on distant mountains / forests / horizon
    float linDepth = linearizeDepth(centerDepth, nearPlane, farPlane);
    float farFactor = isSky ? 1.0 : smoothstep(22.0, 110.0, linDepth);
    float farSharp = clamp(float(TAA_FAR_SHARPNESS), 0.0, 1.4);

    // Tighter variance box on far terrain preserves crisp 1px distant blocks & foliage!
    vec3 mean = m1 / 9.0;
    vec3 sigma = sqrt(max(m2 / 9.0 - mean * mean, vec3(0.0)));
    float baseGamma = float(TAA_VARIANCE_GAMMA);
    float effGamma = mix(baseGamma, max(baseGamma * 0.58, 0.48), saturate(farFactor * farSharp));
    vec3 varMin = mean - sigma * effGamma;
    vec3 varMax = mean + sigma * effGamma;

    // Blend 3x3 variance box with tighter 5-tap (+) cross bounds at distance (Playdead/UE TAA trick)
    vec3 tightMin = max(varMin, mix(box3Min, crossMin, saturate(0.35 + 0.55 * farFactor * farSharp)));
    vec3 tightMax = min(varMax, mix(box3Max, crossMax, saturate(0.35 + 0.55 * farFactor * farSharp)));

    // FIXED VELOCITY DILATION: compute motion vector AT bestUV, then apply displacement to uv!
    vec2 prevUV = uv;
    if (!isHandOrOutline) {
        vec2 currJitterUV = getSubpixelJitterUV(frameCounter, viewSize);
        vec2 bestUnjitter = clamp(bestUV - currJitterUV, vec2(0.001), vec2(0.999));
        vec2 bestPrevUV = reprojectScreenUV(bestUnjitter, minDepth, projInv, mvInv, camPos, prevCamPos, prevMV, prevProj);
        if (bestPrevUV.x < -0.5) return currHDR;
        vec2 velocity = bestPrevUV - bestUnjitter;
        prevUV = uv + velocity;
    }

    if (prevUV.x < 0.001 || prevUV.x > 0.999 || prevUV.y < 0.001 || prevUV.y > 0.999) {
        return currHDR;
    }

    #ifdef TAA_BICUBIC_HISTORY
        vec3 histTaa = sampleCatmullRom5(histTex, prevUV, viewSize);
    #else
        vec3 histTaa = texture(histTex, prevUV).rgb;
    #endif

    // Clamp history into distance-tightened YCoCg neighborhood to kill both ghosting & far smear
    vec3 histYCoCg = clamp(rgbToYCoCg(histTaa), tightMin, tightMax);
    vec3 clampedHist = yCoCgToRgb(histYCoCg);

    vec3 currTaa = hdrToTaaSpace(currHDR);

    // Compute camera motion velocity & subpixel off-texel resampling factor
    vec2 velPx = (prevUV - uv) * viewSize;
    float velLen = length(velPx);

    // Distance from exact texel center: 0.0 = exact pixel hit (zero blur), 0.707 = worst half-texel resample
    float subpixOff = saturate(length(fract(prevUV * viewSize) - 0.5) * 1.41421356);
    float motionMask = smoothstep(0.03, 1.25, velLen);

    // Dynamic history retention: rock-solid when static, anti-smear during motion & at far distances!
    float velFade = exp(-velLen * mix(0.06, 0.16, farFactor));
    float resamplePenalty = 1.0 - subpixOff * motionMask * mix(0.18, 0.48, farFactor) * saturate(farSharp);
    float farCap = mix(1.0, 0.76, farFactor * saturate(farSharp) * (0.30 + 0.70 * motionMask));

    float blend = float(TAA_BLEND_FACTOR) * (0.38 + 0.62 * velFade) * resamplePenalty * farCap;
    if (isHandOrOutline) blend *= 0.15;
    if (isSky) blend *= 0.55;

    vec3 blendedTaa = mix(currTaa, clampedHist, saturate(blend));
    return taaSpaceToHdr(blendedTaa);
}

// ---------- MSAA: Geometric Depth + Normal Coverage Mask + 2x/4x/8x RGSS Resolve ----------
vec3 computeGeometricMSAA(
    vec2 uv,
    vec2 viewSize,
    float nearPlane,
    float farPlane,
    sampler2D colorTex,
    sampler2D depthTex,
    sampler2D matTex
) {
    vec2 texel = 1.0 / viewSize;
    vec3 centerCol = sanitizeHDR(texture(colorTex, uv).rgb);
    float cDepth = linearizeDepth(texture(depthTex, uv).r, nearPlane, farPlane);
    vec4 cMat = texture(matTex, uv);
    vec3 cNorm = decodeNormal(cMat.xy);

    float dL = linearizeDepth(texture(depthTex, clamp(uv - vec2(texel.x, 0.0), vec2(0.001), vec2(0.999))).r, nearPlane, farPlane);
    float dR = linearizeDepth(texture(depthTex, clamp(uv + vec2(texel.x, 0.0), vec2(0.001), vec2(0.999))).r, nearPlane, farPlane);
    float dD = linearizeDepth(texture(depthTex, clamp(uv - vec2(0.0, texel.y), vec2(0.001), vec2(0.999))).r, nearPlane, farPlane);
    float dU = linearizeDepth(texture(depthTex, clamp(uv + vec2(0.0, texel.y), vec2(0.001), vec2(0.999))).r, nearPlane, farPlane);

    float depthGrad = (abs(dL - cDepth) + abs(dR - cDepth) + abs(dD - cDepth) + abs(dU - cDepth)) / max(cDepth * 1.2 + 0.5, 0.5);

    vec4 mL = texture(matTex, clamp(uv - vec2(texel.x, 0.0), vec2(0.001), vec2(0.999)));
    vec4 mR = texture(matTex, clamp(uv + vec2(texel.x, 0.0), vec2(0.001), vec2(0.999)));
    vec4 mD = texture(matTex, clamp(uv - vec2(0.0, texel.y), vec2(0.001), vec2(0.999)));
    vec4 mU = texture(matTex, clamp(uv + vec2(0.0, texel.y), vec2(0.001), vec2(0.999)));

    float normDiff = (1.0 - dot(cNorm, decodeNormal(mL.xy))) + (1.0 - dot(cNorm, decodeNormal(mR.xy))) +
                     (1.0 - dot(cNorm, decodeNormal(mD.xy))) + (1.0 - dot(cNorm, decodeNormal(mU.xy)));
    float matDiff = abs(mL.z - cMat.z) + abs(mR.z - cMat.z) + abs(mD.z - cMat.z) + abs(mU.z - cMat.z);

    float edgeMetric = depthGrad * 1.15 + normDiff * 0.55 + matDiff * 2.5;
    float edgeMask = smoothstep(float(MSAA_EDGE_THRESHOLD) * 0.5, float(MSAA_EDGE_THRESHOLD) * 2.0, edgeMetric);

    if (edgeMask <= 0.005) return centerCol;

    vec3 resolved = vec3(0.0);
    float wSum = 0.0;

    #if MSAA_SAMPLES == 2
        const vec2 SAMPLES_2[2] = vec2[2](vec2(-0.25, -0.25), vec2(0.25, 0.25));
        for (int i = 0; i < 2; i++) {
            vec2 off = SAMPLES_2[i] * texel * 1.65;
            resolved += sanitizeHDR(texture(colorTex, clamp(uv + off, vec2(0.001), vec2(0.999))).rgb);
            wSum += 1.0;
        }
    #elif MSAA_SAMPLES == 4
        const vec2 SAMPLES_4[4] = vec2[4](
            vec2(-0.125, -0.375), vec2( 0.375, -0.125),
            vec2(-0.375,  0.125), vec2( 0.125,  0.375)
        );
        for (int i = 0; i < 4; i++) {
            vec2 off = SAMPLES_4[i] * texel * 1.85;
            resolved += sanitizeHDR(texture(colorTex, clamp(uv + off, vec2(0.001), vec2(0.999))).rgb);
            wSum += 1.0;
        }
    #else
        const vec2 SAMPLES_8[8] = vec2[8](
            vec2( 0.0625, -0.1875), vec2(-0.0625,  0.1875),
            vec2( 0.3125,  0.0625), vec2(-0.1875, -0.3125),
            vec2(-0.3125,  0.3125), vec2(-0.4375, -0.0625),
            vec2( 0.1875,  0.4375), vec2( 0.4375, -0.4375)
        );
        for (int i = 0; i < 8; i++) {
            vec2 off = SAMPLES_8[i] * texel * 1.95;
            resolved += sanitizeHDR(texture(colorTex, clamp(uv + off, vec2(0.001), vec2(0.999))).rgb);
            wSum += 1.0;
        }
    #endif

    resolved /= max(wSum, 1.0);
    return mix(centerCol, resolved, edgeMask * 0.85);
}

// ---------- FXAA 3.11 Quality ----------
float fxaaLuma(vec3 c) {
    return sqrt(max(getLuminance(c / (1.0 + getLuminance(c))), 0.0));
}

vec3 computeFXAA(vec2 uv, vec2 texel, sampler2D tex) {
    vec3 rgbM  = sanitizeHDR(texture(tex, uv).rgb);
    vec3 rgbN  = sanitizeHDR(texture(tex, clamp(uv + vec2( 0.0, -texel.y), vec2(0.001), vec2(0.999))).rgb);
    vec3 rgbS  = sanitizeHDR(texture(tex, clamp(uv + vec2( 0.0,  texel.y), vec2(0.001), vec2(0.999))).rgb);
    vec3 rgbW  = sanitizeHDR(texture(tex, clamp(uv + vec2(-texel.x,  0.0), vec2(0.001), vec2(0.999))).rgb);
    vec3 rgbE  = sanitizeHDR(texture(tex, clamp(uv + vec2( texel.x,  0.0), vec2(0.001), vec2(0.999))).rgb);

    float lumaM = fxaaLuma(rgbM);
    float lumaN = fxaaLuma(rgbN);
    float lumaS = fxaaLuma(rgbS);
    float lumaW = fxaaLuma(rgbW);
    float lumaE = fxaaLuma(rgbE);

    float rangeMin = min(lumaM, min(min(lumaN, lumaS), min(lumaW, lumaE)));
    float rangeMax = max(lumaM, max(max(lumaN, lumaS), max(lumaW, lumaE)));
    float range = rangeMax - rangeMin;

    if (range < max(0.0312, rangeMax * float(FXAA_EDGE_THRESHOLD))) {
        return rgbM;
    }

    float lumaNW = fxaaLuma(sanitizeHDR(texture(tex, clamp(uv + vec2(-texel.x, -texel.y), vec2(0.001), vec2(0.999))).rgb));
    float lumaNE = fxaaLuma(sanitizeHDR(texture(tex, clamp(uv + vec2( texel.x, -texel.y), vec2(0.001), vec2(0.999))).rgb));
    float lumaSW = fxaaLuma(sanitizeHDR(texture(tex, clamp(uv + vec2(-texel.x,  texel.y), vec2(0.001), vec2(0.999))).rgb));
    float lumaSE = fxaaLuma(sanitizeHDR(texture(tex, clamp(uv + vec2( texel.x,  texel.y), vec2(0.001), vec2(0.999))).rgb));

    float lumaNS = lumaN + lumaS;
    float lumaWE = lumaW + lumaE;
    float subpixRcpRange = 1.0 / max(range, 1e-4);
    float subpixNSWE = lumaNS + lumaWE;

    float edgeHorz = abs(-2.0 * lumaW + (lumaNW + lumaSW)) + abs(-2.0 * lumaM + lumaNS) * 2.0 + abs(-2.0 * lumaE + (lumaNE + lumaSE));
    float edgeVert = abs(-2.0 * lumaN + (lumaNW + lumaNE)) + abs(-2.0 * lumaM + lumaWE) * 2.0 + abs(-2.0 * lumaS + (lumaSW + lumaSE));
    bool isHorz = edgeHorz >= edgeVert;

    float luma1 = isHorz ? lumaN : lumaW;
    float luma2 = isHorz ? lumaS : lumaE;
    float grad1 = abs(luma1 - lumaM);
    float grad2 = abs(luma2 - lumaM);
    bool is1Steepest = grad1 >= grad2;
    float gradScaled = 0.25 * max(grad1, grad2);

    float stepLength = isHorz ? texel.y : texel.x;
    float lumaLocalAvg = 0.5 * ((is1Steepest ? luma1 : luma2) + lumaM);
    if (is1Steepest) stepLength = -stepLength;

    vec2 currUV = uv;
    if (isHorz) currUV.y += stepLength * 0.5;
    else        currUV.x += stepLength * 0.5;

    vec2 offset = isHorz ? vec2(texel.x, 0.0) : vec2(0.0, texel.y);
    vec2 uv1 = currUV - offset;
    vec2 uv2 = currUV + offset;

    float lumaEnd1 = fxaaLuma(sanitizeHDR(texture(tex, clamp(uv1, vec2(0.001), vec2(0.999))).rgb)) - lumaLocalAvg;
    float lumaEnd2 = fxaaLuma(sanitizeHDR(texture(tex, clamp(uv2, vec2(0.001), vec2(0.999))).rgb)) - lumaLocalAvg;
    bool reached1 = abs(lumaEnd1) >= gradScaled;
    bool reached2 = abs(lumaEnd2) >= gradScaled;

    #if FXAA_QUALITY == 1
        const int SEARCH_STEPS = 4;
    #elif FXAA_QUALITY == 2
        const int SEARCH_STEPS = 6;
    #elif FXAA_QUALITY == 3
        const int SEARCH_STEPS = 9;
    #else
        const int SEARCH_STEPS = 12;
    #endif

    for (int i = 0; i < SEARCH_STEPS; i++) {
        if (reached1 && reached2) break;
        float mult = i < 3 ? 1.0 : (i < 6 ? 1.5 : 2.0);
        if (!reached1) {
            uv1 -= offset * mult;
            lumaEnd1 = fxaaLuma(sanitizeHDR(texture(tex, clamp(uv1, vec2(0.001), vec2(0.999))).rgb)) - lumaLocalAvg;
            reached1 = abs(lumaEnd1) >= gradScaled;
        }
        if (!reached2) {
            uv2 += offset * mult;
            lumaEnd2 = fxaaLuma(sanitizeHDR(texture(tex, clamp(uv2, vec2(0.001), vec2(0.999))).rgb)) - lumaLocalAvg;
            reached2 = abs(lumaEnd2) >= gradScaled;
        }
    }

    float dist1 = isHorz ? (uv.x - uv1.x) : (uv.y - uv1.y);
    float dist2 = isHorz ? (uv2.x - uv.x) : (uv2.y - uv.y);
    bool dir1 = dist1 < dist2;
    float distMin = min(dist1, dist2);
    float edgeThickness = max(dist1 + dist2, 1e-5);
    float pixelOffset = -distMin / edgeThickness + 0.5;

    bool isMlt = lumaM < lumaLocalAvg;
    bool correctVar = ((dir1 ? lumaEnd1 : lumaEnd2) < 0.0) != isMlt;
    float finalOffset = correctVar ? pixelOffset : 0.0;

    float lumaAvg = (1.0 / 12.0) * (2.0 * subpixNSWE + (lumaNW + lumaNE + lumaSW + lumaSE));
    float subpix1 = clamp(abs(lumaAvg - lumaM) * subpixRcpRange, 0.0, 1.0);
    float subpix2 = (-2.0 * subpix1 + 3.0) * subpix1 * subpix1;
    float subpixOffset = subpix2 * subpix2 * float(FXAA_SUBPIX);

    finalOffset = max(finalOffset, subpixOffset);
    vec2 finalUV = uv;
    if (isHorz) finalUV.y += finalOffset * stepLength;
    else        finalUV.x += finalOffset * stepLength;

    return sanitizeHDR(texture(tex, clamp(finalUV, vec2(0.001), vec2(0.999))).rgb);
}

// ---------- SMAA-Style Morphological Pattern Edge AA ----------
vec3 computeSMAA(vec2 uv, vec2 texel, sampler2D tex) {
    vec3 cM = sanitizeHDR(texture(tex, uv).rgb);
    vec3 cL = sanitizeHDR(texture(tex, clamp(uv - vec2(texel.x, 0.0), vec2(0.001), vec2(0.999))).rgb);
    vec3 cR = sanitizeHDR(texture(tex, clamp(uv + vec2(texel.x, 0.0), vec2(0.001), vec2(0.999))).rgb);
    vec3 cT = sanitizeHDR(texture(tex, clamp(uv - vec2(0.0, texel.y), vec2(0.001), vec2(0.999))).rgb);
    vec3 cB = sanitizeHDR(texture(tex, clamp(uv + vec2(0.0, texel.y), vec2(0.001), vec2(0.999))).rgb);

    float eL = maxOf(abs(cM - cL)) / max(1.0 + getLuminance(cM), 1.0);
    float eR = maxOf(abs(cM - cR)) / max(1.0 + getLuminance(cM), 1.0);
    float eT = maxOf(abs(cM - cT)) / max(1.0 + getLuminance(cM), 1.0);
    float eB = maxOf(abs(cM - cB)) / max(1.0 + getLuminance(cM), 1.0);

    float thresh = max(float(FXAA_EDGE_THRESHOLD) * 0.75, 0.04);
    float horzEdge = max(eT, eB);
    float vertEdge = max(eL, eR);
    if (max(horzEdge, vertEdge) < thresh) return cM;

    bool isH = horzEdge >= vertEdge;
    vec2 tangent = isH ? vec2(texel.x, 0.0) : vec2(0.0, texel.y);
    vec2 normalDir = isH ? (eT >= eB ? vec2(0.0, -texel.y) : vec2(0.0, texel.y))
                         : (eL >= eR ? vec2(-texel.x, 0.0) : vec2(texel.x, 0.0));

    float spanNeg = 0.0;
    float spanPos = 0.0;
    const int MAX_SPAN = 10;
    for (int i = 1; i <= MAX_SPAN; i++) {
        vec2 pUV = clamp(uv - tangent * float(i), vec2(0.001), vec2(0.999));
        vec3 s0 = sanitizeHDR(texture(tex, pUV).rgb);
        vec3 s1 = sanitizeHDR(texture(tex, clamp(pUV + normalDir, vec2(0.001), vec2(0.999))).rgb);
        float d = maxOf(abs(s0 - s1)) / max(1.0 + getLuminance(s0), 1.0);
        if (d < thresh) break;
        spanNeg += 1.0;
    }
    for (int i = 1; i <= MAX_SPAN; i++) {
        vec2 pUV = clamp(uv + tangent * float(i), vec2(0.001), vec2(0.999));
        vec3 s0 = sanitizeHDR(texture(tex, pUV).rgb);
        vec3 s1 = sanitizeHDR(texture(tex, clamp(pUV + normalDir, vec2(0.001), vec2(0.999))).rgb);
        float d = maxOf(abs(s0 - s1)) / max(1.0 + getLuminance(s0), 1.0);
        if (d < thresh) break;
        spanPos += 1.0;
    }

    float totalSpan = max(spanNeg + spanPos + 1.0, 1.0);
    float nearestEnd = min(spanNeg, spanPos);
    float blendW = clamp(0.5 - (nearestEnd + 0.5) / totalSpan, 0.0, 0.5);
    vec2 sampleUV = clamp(uv + normalDir * blendW, vec2(0.001), vec2(0.999));
    return sanitizeHDR(texture(tex, sampleUV).rgb);
}

// ---------- Distance-Aware Contrast Adaptive Sharpening (CAS) ----------
vec3 applyCASSharpening(vec3 centerColor, vec2 uv, vec2 texel, float extraBoost, sampler2D tex) {
    float str = saturate(float(AA_SHARPENING) + extraBoost);
    if (str <= 0.001) return centerColor;

    vec3 a = sanitizeHDR(texture(tex, clamp(uv + vec2( 0.0, -texel.y), vec2(0.001), vec2(0.999))).rgb);
    vec3 b = sanitizeHDR(texture(tex, clamp(uv + vec2(-texel.x,  0.0), vec2(0.001), vec2(0.999))).rgb);
    vec3 c = centerColor;
    vec3 d = sanitizeHDR(texture(tex, clamp(uv + vec2( texel.x,  0.0), vec2(0.001), vec2(0.999))).rgb);
    vec3 e = sanitizeHDR(texture(tex, clamp(uv + vec2( 0.0,  texel.y), vec2(0.001), vec2(0.999))).rgb);

    a = hdrToTaaSpace(a); b = hdrToTaaSpace(b); c = hdrToTaaSpace(c); d = hdrToTaaSpace(d); e = hdrToTaaSpace(e);

    vec3 minRGB = min(c, min(min(a, b), min(d, e)));
    vec3 maxRGB = max(c, max(max(a, b), max(d, e)));
    vec3 amp = sqrt(clamp(min(minRGB, 1.0 - maxRGB) / max(maxRGB, vec3(1e-4)), vec3(0.0), vec3(1.0)));

    float peak = -1.0 / mix(8.0, 5.0, str);
    vec3 w = amp * peak * str;
    vec3 sharpened = (c + (a + b + d + e) * w) / max(1.0 + 4.0 * w, vec3(0.15));
    return taaSpaceToHdr(saturate(sharpened));
}

#endif // LIB_ANTIALIASING_GLSL
