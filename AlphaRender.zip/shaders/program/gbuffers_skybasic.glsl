#include "/lib/settings.glsl"
#include "/lib/common.glsl"

#ifdef VERTEX_SHADER

out vec4 vColor;
out vec3 vViewPos;

void main() {
    vec4 viewPos = gl_ModelViewMatrix * gl_Vertex;
    vViewPos = viewPos.xyz;
    vColor = gl_Color;
    gl_Position = gl_ProjectionMatrix * viewPos;
}

#endif // VERTEX_SHADER

#ifdef FRAGMENT_SHADER

#include "/lib/atmosphere.glsl"

uniform vec3 sunPosition;
uniform vec3 upPosition;
uniform vec3 fogColor;
uniform float rainStrength;
uniform int renderStage;

in vec4 vColor;
in vec3 vViewPos;

/* RENDERTARGETS:0,1,2 */
layout(location = 0) out vec4 outColor;
layout(location = 1) out vec4 outNormalMat;
layout(location = 2) out vec4 outEmissive;

void main() {
    vec3 viewDir = safeNormalize(vViewPos);
    vec3 skyCol = computeSkyColor(viewDir, sunPosition, upPosition, rainStrength, fogColor);

    // Preserve vanilla stars softly during night (MC_RENDER_STAGE_STARS)
    #ifdef MC_RENDER_STAGE_STARS
    if (renderStage == MC_RENDER_STAGE_STARS) {
        float starBright = maxOf(vColor.rgb);
        vec3 starCol = srgbToLinear(vColor.rgb) * (1.0 - rainStrength) * 1.45;
        outColor = vec4(skyCol + starCol, 1.0);
        outNormalMat = vec4(0.5, 0.5, MAT_SKY, 1.0);
        outEmissive = vec4(saturate(starCol * smoothstep(0.3, 0.9, starBright) * 0.15), 0.5);
        return;
    }
    #endif

    outColor = vec4(skyCol, 1.0);
    outNormalMat = vec4(0.5, 0.5, MAT_SKY, 1.0);
    outEmissive = vec4(0.0);
}

#endif // FRAGMENT_SHADER
