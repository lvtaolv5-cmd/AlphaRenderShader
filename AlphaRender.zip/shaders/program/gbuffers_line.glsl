#include "/lib/settings.glsl"
#include "/lib/common.glsl"

/* ============================================================================
   AlphaRender - Block Selection Outline & Line Program (gbuffers_line)
   - Supports RGB Custom Color, Vanilla Black, Rainbow Flow, Breathing RGB,
     Auto Accent, and Hidden modes.
   - CRITICAL FEATURE: Any Block Selection Outline with color (!Black) is
     explicitly written into colortex2 (a = 1.0), entering BOTH Bloom and
     Optical Glare/Scatter targets! Black outlines write vec4(0.0) so they
     do NOT enter Bloom or Glare.
   ============================================================================ */

#ifdef VERTEX_SHADER

uniform mat4 gbufferModelViewInverse;
uniform vec3 cameraPosition;
uniform float viewWidth;
uniform float viewHeight;
uniform int renderStage;

flat out vec4 vColor;
flat out int vIsOutline;
out vec3 vWorldPos;

void main() {
    vColor = gl_Color;

    int isOutline = 0;
    #ifdef MC_RENDER_STAGE_OUTLINE
        if (renderStage == MC_RENDER_STAGE_OUTLINE) {
            isOutline = 1;
        }
    #endif
    // Fallback heuristic if a mod renders vanilla black outline without OUTLINE stage
    if (isOutline == 0 && abs(gl_Color.a - 0.4) < 0.06 && dot(gl_Color.rgb, gl_Color.rgb) < 0.015) {
        isOutline = 1;
    }
    vIsOutline = isOutline;

    vec4 mvStart = gl_ModelViewMatrix * gl_Vertex;
    vWorldPos = (gbufferModelViewInverse * mvStart).xyz + cameraPosition;

    // Vanilla MC 1.17+ / 26.3 screen-space extruded line quad
    const float VIEW_SHRINK = 1.0 - (1.0 / 256.0);
    vec4 startClip = gl_ProjectionMatrix * vec4(mvStart.xyz * VIEW_SHRINK, 1.0);
    vec4 endClip   = gl_ProjectionMatrix * vec4((gl_ModelViewMatrix * vec4(gl_Vertex.xyz + gl_Normal, 1.0)).xyz * VIEW_SHRINK, 1.0);

    vec3 ndc1 = startClip.xyz / max(abs(startClip.w), 1e-5) * sign(startClip.w >= 0.0 ? 1.0 : -1.0);
    vec3 ndc2 = endClip.xyz   / max(abs(endClip.w),   1e-5) * sign(endClip.w   >= 0.0 ? 1.0 : -1.0);

    vec2 screenSize = max(vec2(viewWidth, viewHeight), vec2(1.0));
    vec2 lineDir = safeNormalize2((ndc2.xy - ndc1.xy) * screenSize);

    float lineWidth = (isOutline == 1) ? float(SELECT_BOX_WIDTH) : 2.0;
    vec2 lineOffset = vec2(-lineDir.y, lineDir.x) * (lineWidth / screenSize);
    if (lineOffset.x < 0.0) {
        lineOffset = -lineOffset;
    }

    float side = (gl_VertexID & 1) == 0 ? 1.0 : -1.0;
    gl_Position = vec4((ndc1 + vec3(lineOffset * side, 0.0)) * startClip.w, startClip.w);
    // Intentionally unjittered so the block selection box never trembles under TAA!
}

#endif // VERTEX_SHADER

#ifdef FRAGMENT_SHADER

uniform float frameTimeCounter;

flat in vec4 vColor;
flat in int vIsOutline;
in vec3 vWorldPos;

/* RENDERTARGETS:0,1,2 */
layout(location = 0) out vec4 outColor;
layout(location = 1) out vec4 outNormalMat;
layout(location = 2) out vec4 outEmissive;

void main() {
    if (vColor.a < 0.005) discard;

    if (vIsOutline == 1) {
        #if SELECT_BOX_MODE == 5
            discard;
        #endif

        vec3 outlineSrgb = vec3(0.0);
        float outlineAlpha = float(SELECT_BOX_ALPHA);

        #if SELECT_BOX_MODE == 0
            // Vanilla Default Black
            outlineSrgb = vec3(0.0);
            outlineAlpha = min(outlineAlpha, 0.55);
        #elif SELECT_BOX_MODE == 1
            // Custom RGB Color
            outlineSrgb = vec3(float(SELECT_BOX_R), float(SELECT_BOX_G), float(SELECT_BOX_B)) / 255.0;
        #elif SELECT_BOX_MODE == 2
            // Rainbow Flow (world + time animated)
            float hue = fract(frameTimeCounter * 0.22 * float(SELECT_BOX_PULSE_SPEED) + dot(vWorldPos, vec3(0.28, 0.36, 0.24)));
            outlineSrgb = hsvToRgb(vec3(hue, 0.90, 1.0));
        #elif SELECT_BOX_MODE == 3
            // Breathing Pulse Custom RGB (remains Black if R=G=B=0!)
            vec3 baseRgb = vec3(float(SELECT_BOX_R), float(SELECT_BOX_G), float(SELECT_BOX_B)) / 255.0;
            float pulse = 0.45 + 0.55 * (0.5 + 0.5 * sin(frameTimeCounter * 3.14159 * float(SELECT_BOX_PULSE_SPEED)));
            outlineSrgb = baseRgb * pulse;
        #else
            // Auto Luminous Accent
            outlineSrgb = vec3(0.32, 0.90, 1.00);
        #endif

        // CRITICAL CHECK: Is the selection outline non-black (!Black)?
        bool isColoredOutline = maxOf(outlineSrgb) > 0.004;

        if (isColoredOutline) {
            vec3 hdrOutline = srgbToLinear(outlineSrgb) * float(SELECT_BOX_BRIGHTNESS);
            outColor     = vec4(hdrOutline, outlineAlpha);
            outNormalMat = vec4(0.5, 0.5, MAT_OUTLINE, 1.0);
            // Explicitly write into RGBA8 colortex2 (0.25x HDR scale, alpha = 1.0) -> unconditionally enters Bloom & Glare targets!
            outEmissive  = vec4(saturate(hdrOutline * outlineAlpha * 0.25), 1.0);
        } else {
            // Pure Black selection box: rendered cleanly, ZERO Bloom & ZERO Glare!
            outColor     = vec4(0.0, 0.0, 0.0, outlineAlpha);
            outNormalMat = vec4(0.5, 0.5, MAT_OUTLINE, 0.0);
            outEmissive  = vec4(0.0, 0.0, 0.0, 0.0);
        }
        return;
    }

    // Non-selection lines (fishing line, F3+B hitboxes, Litematica schematic lines, etc.)
    outColor     = vec4(srgbToLinear(vColor.rgb), vColor.a);
    outNormalMat = vec4(0.5, 0.5, MAT_TRANS, 0.0);
    outEmissive  = vec4(0.0);
}

#endif // FRAGMENT_SHADER
