# Changelog

## v1.0.0 (Initial Modrinth Release)

- Packaged in standard Modrinth / Iris shaderpack archive format (`shaders/` at archive root).
- 5-tier configuration profiles (`LOW`, `MEDIUM`, `HIGH`, `ULTRA`, `EXTREME`).
- 12 color palette styles including Classic Color, Nostalgia Color, and Legacy Color, plus global and 3-way RGB tone grading.
- Hybrid real-time pixel-locked shadows (terrain, entities, block entities, water) with cool shadow tinting and vanilla directional/lightmap shading.
- 4-mode water system (Vanilla, Vanilla Tinted, Pure Non-Vanilla, Realistic PBR) with composite-stage refraction, caustics, foam, and SSR.
- Extreme Performance pipeline: hardware `0.5x0.5` half-res Bloom & Optical Glare, Early-Z depth-only `shadow_solid`, conditional `program.*.enabled` pass skipping, 32-bit `R11F_G11F_B10F`/`RGBA8` targets, vertex-hoisted lighting, and 1-pixel auto-exposure.
- Multi-mode Bokeh DoF (Default, Focus Blur, Reverse Focus Blur, Manual Focus, Tilt-Shift).
- Anti-Aliasing suite (FXAA, MSAA, SMAA, TAA with far-view blur fix, TAA+FXAA, TAA+MSAA, CAS Sharpening).
- RGB Block Selection Box with automatic Bloom & Optical Glare contribution for non-black colors.
- Complete `en_US` and `zh_CN` localization.
