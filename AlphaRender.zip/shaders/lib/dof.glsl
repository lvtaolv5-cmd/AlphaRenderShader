#ifndef LIB_DOF_GLSL
#define LIB_DOF_GLSL

/* ============================================================================
   AlphaRender - High-Performance Multi-Mode Bokeh Depth of Field
   Modes:
     0: Default DoF         (默认 DoF)
     1: Focus Blur          (焦点模糊)
     2: Reverse Focus Blur  (反焦模糊)
     3: Manual Focus        (手动定焦)
     4: Tilt-Shift          (移轴微缩)
   Performance Optimizations:
     - Adaptive tap scaling based on actual pixel CoC radius (~2.5x faster!)
     - Chroma fringe computed only on outer bokeh ring (r > 0.60) & large CoC
   ============================================================================ */

float shapeBokehRadius(float angle) {
    #if DOF_BOKEH_SHAPE == 0
        return 1.0;
    #elif DOF_BOKEH_SHAPE == 1
        float n = 6.0;
        float sector = PI / n;
        return cos(sector) / max(cos(mod(angle + sector, 2.0 * sector) - sector), 0.35);
    #else
        float n = 8.0;
        float sector = PI / n;
        return cos(sector) / max(cos(mod(angle + sector, 2.0 * sector) - sector), 0.35);
    #endif
}

float computeSignedCoC(float rawDepth, float centerDepthSmoothVal, vec2 uv, float aspect, float nearPlane, float farPlane) {
    float maxRad = float(DOF_MAX_RADIUS);
    float strength = float(DOF_STRENGTH);
    float apertureScale = float(DOF_APERTURE) / 1.40;

    #if DOF_MODE == 4
        float band = abs(uv.y - 0.52);
        float coc = smoothstep(0.08, 0.46, band) * maxRad * strength;
        return clamp(coc, 0.0, maxRad);
    #else
        float pixelDist = linearizeDepth(rawDepth, nearPlane, farPlane);

        #if DOF_MODE == 3
            float focusDist = float(DOF_MANUAL_DISTANCE);
        #else
            float focusDist = linearizeDepth(clamp(centerDepthSmoothVal, 0.001, 0.9999), nearPlane, farPlane);
            focusDist = clamp(focusDist, 1.2, farPlane * 0.78);
        #endif

        float diff = pixelDist - focusDist;
        float relDiff = diff / max(pixelDist + focusDist * 0.35, 1.5);

        #if DOF_MODE == 0 || DOF_MODE == 3
            float coc = relDiff * 7.2 * apertureScale * strength;
            if (coc < 0.0) coc *= float(DOF_NEAR_BLUR);
            else           coc *= float(DOF_FAR_BLUR);
            float deadzoned = max(abs(coc) - 0.40, 0.0);
            return sign(coc) * min(deadzoned, maxRad);

        #elif DOF_MODE == 1
            float depthCoC = relDiff * 11.5 * apertureScale * strength;
            if (depthCoC < 0.0) depthCoC *= float(DOF_NEAR_BLUR);
            else                depthCoC *= float(DOF_FAR_BLUR);

            vec2 centered = (uv - 0.5) * vec2(aspect, 1.0);
            float radialDist = length(centered);
            float spotR = float(DOF_FOCUS_SPOT_RADIUS);
            float spotSoft = max(float(DOF_FOCUS_SOFTNESS), 0.04);
            float radialWeight = smoothstep(spotR, spotR + spotSoft, radialDist);

            float radialCoC = radialWeight * maxRad * 0.72 * strength * apertureScale;
            float signedDepth = sign(depthCoC) * max(abs(depthCoC) - 0.25, 0.0);

            float combinedMag = max(abs(signedDepth), radialCoC);
            float outSign = abs(signedDepth) >= radialCoC ? sign(signedDepth) : 1.0;
            return outSign * min(combinedMag, maxRad);

        #else
            float focusBand = exp(-sqr(relDiff * 3.8 / max(float(DOF_FOCUS_SOFTNESS) * 2.5, 0.35)));
            vec2 centered = (uv - 0.5) * vec2(aspect, 1.0);
            float spotFalloff = 1.0 - smoothstep(float(DOF_FOCUS_SPOT_RADIUS) * 0.6, float(DOF_FOCUS_SPOT_RADIUS) + float(DOF_FOCUS_SOFTNESS) + 0.35, length(centered));
            float coc = focusBand * mix(0.65, 1.0, spotFalloff) * maxRad * 0.85 * strength * apertureScale;
            return clamp(coc, 0.0, maxRad);
        #endif
    #endif
}

vec3 computeBokehDoF(
    vec2 uv,
    vec2 fragCoord,
    vec2 texelSize,
    float viewWidth,
    float viewHeight,
    float nearPlane,
    float farPlane,
    float centerDepthSmoothVal,
    int frameCounter,
    sampler2D colorTex,
    sampler2D depthTex,
    sampler2D matTex
) {
    vec3 centerColor = sanitizeHDR(texture(colorTex, uv).rgb);

    #ifndef DOF_ENABLED
        return centerColor;
    #else
        float rawDepth = texture(depthTex, uv).r;
        float matId = texture(matTex, uv).z;

        #ifndef DOF_BLUR_HAND
            if (abs(matId - MAT_HAND) < 0.06 || rawDepth < 0.56) {
                return centerColor;
            }
        #endif

        float aspect = viewWidth / max(viewHeight, 1.0);
        float centerCoC = computeSignedCoC(rawDepth, centerDepthSmoothVal, uv, aspect, nearPlane, farPlane);
        float blurRadiusPx = abs(centerCoC);
        if (blurRadiusPx < 0.35) {
            return centerColor;
        }

        #if DOF_QUALITY == 1
            const int MAX_TAPS = 10;
        #elif DOF_QUALITY == 2
            const int MAX_TAPS = 16;
        #elif DOF_QUALITY == 3
            const int MAX_TAPS = 24;
        #elif DOF_QUALITY == 4
            const int MAX_TAPS = 34;
        #else
            const int MAX_TAPS = 46;
        #endif

        // Adaptive tap count: crisp small blurs need far fewer taps than huge 14px bokeh!
        int activeTaps = blurRadiusPx < 2.2 ? min(MAX_TAPS, 8) : (blurRadiusPx < 5.0 ? min(MAX_TAPS, 14) : MAX_TAPS);

        float rotOffset = interleavedGradientNoiseTemporal(fragCoord, frameCounter) * TAU;
        float centerLinDepth = linearizeDepth(rawDepth, nearPlane, farPlane);
        float chromaStr = (blurRadiusPx > 2.4) ? (float(DOF_CHROMA_FRINGE) * 0.085) : 0.0;
        float highlightBoost = float(DOF_BOKEH_HIGHLIGHT);

        vec3 accum = centerColor;
        float weightSum = 1.0;

        for (int i = 0; i < MAX_TAPS; i++) {
            if (i >= activeTaps) break;
            float t = (float(i) + 0.5) / float(activeTaps);
            float r = sqrt(t);
            float theta = float(i) * GOLDEN_ANGLE + rotOffset;
            float shapedR = r * shapeBokehRadius(theta);

            vec2 dir = vec2(cos(theta), sin(theta));
            vec2 offsetUV = dir * (shapedR * blurRadiusPx) * texelSize;
            vec2 sampleUV = clamp(uv + offsetUV, vec2(0.001), vec2(0.999));

            #ifndef DOF_BLUR_HAND
                float sampleMat = texture(matTex, sampleUV).z;
                if (abs(sampleMat - MAT_HAND) < 0.06) continue;
            #endif

            float sampleDepth = texture(depthTex, sampleUV).r;
            float sampleCoC = computeSignedCoC(sampleDepth, centerDepthSmoothVal, sampleUV, aspect, nearPlane, farPlane);
            float sampleAbsCoC = abs(sampleCoC);
            float sampleLinDepth = linearizeDepth(sampleDepth, nearPlane, farPlane);

            float depthGuard = 1.0;
            #if DOF_MODE == 2
                depthGuard = smoothstep(0.05, 0.85, sampleAbsCoC / max(blurRadiusPx * 0.5, 0.25));
            #else
                if (sampleLinDepth < centerLinDepth - 0.5) {
                    depthGuard = saturate(sampleAbsCoC / max(blurRadiusPx, 0.5));
                } else {
                    depthGuard = smoothstep(0.08, 0.90, sampleAbsCoC / max(blurRadiusPx * 0.45, 0.25));
                }
            #endif

            if (depthGuard <= 0.001) continue;

            vec3 sCol;
            if (chromaStr > 0.001 && r > 0.62) {
                vec2 uvR = clamp(uv + offsetUV * (1.0 + chromaStr), vec2(0.001), vec2(0.999));
                vec2 uvB = clamp(uv + offsetUV * (1.0 - chromaStr), vec2(0.001), vec2(0.999));
                sCol = vec3(
                    texture(colorTex, uvR).r,
                    texture(colorTex, sampleUV).g,
                    texture(colorTex, uvB).b
                );
            } else {
                sCol = texture(colorTex, sampleUV).rgb;
            }
            sCol = sanitizeHDR(sCol);

            float lum = getLuminance(sCol);
            float bokehHighlightW = 1.0 + smoothstep(0.75, 2.5, lum) * highlightBoost * (0.4 + 0.6 * r);

            float w = depthGuard * bokehHighlightW;
            accum += sCol * w;
            weightSum += w;
        }

        return accum / max(weightSum, 1e-4);
    #endif
}

#endif // LIB_DOF_GLSL
