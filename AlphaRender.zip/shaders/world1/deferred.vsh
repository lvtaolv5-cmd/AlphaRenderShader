#version 330 compatibility
#define VERTEX_SHADER
#define END
#include "/program/deferred.glsl"
