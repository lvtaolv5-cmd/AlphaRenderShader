#version 330 compatibility
#define VERTEX_SHADER
#define END
#include "/program/composite1.glsl"
