#version 330 compatibility
#define FRAGMENT_SHADER
#define END
#include "/program/composite2.glsl"
