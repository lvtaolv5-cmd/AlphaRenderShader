#ifndef LIB_JITTER_GLSL
#define LIB_JITTER_GLSL

// Fast-converging Halton(2, 3) 8-sample sequence for sharp TAA without distant lag
const vec2 HALTON_8[8] = vec2[8](
    vec2(0.500000, 0.333333),
    vec2(0.250000, 0.666667),
    vec2(0.750000, 0.111111),
    vec2(0.125000, 0.444444),
    vec2(0.625000, 0.777778),
    vec2(0.375000, 0.222222),
    vec2(0.875000, 0.555556),
    vec2(0.062500, 0.888889)
);

// Rotated Grid 4-tap pattern for Temporal RGSS MSAA
const vec2 RGSS_4[4] = vec2[4](
    vec2(-0.125, -0.375),
    vec2( 0.375, -0.125),
    vec2(-0.375,  0.125),
    vec2( 0.125,  0.375)
);

vec2 getSubpixelJitterPixels(int frameCounter) {
    #if AA_USES_TAA
        vec2 h = HALTON_8[frameCounter & 7] - 0.5;
        return h * float(TAA_JITTER_SCALE);
    #elif AA_USES_MSAA && defined(MSAA_TEMPORAL_RGSS)
        return RGSS_4[frameCounter & 3] * 0.75;
    #else
        return vec2(0.0);
    #endif
}

vec2 getSubpixelJitterUV(int frameCounter, vec2 viewSize) {
    return getSubpixelJitterPixels(frameCounter) / max(viewSize, vec2(1.0));
}

vec2 getClipJitterOffset(int frameCounter, float width, float height) {
    vec2 px = getSubpixelJitterPixels(frameCounter);
    return (px * 2.0) / max(vec2(width, height), vec2(1.0));
}

#endif // LIB_JITTER_GLSL
