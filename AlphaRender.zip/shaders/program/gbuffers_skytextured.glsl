#include "/lib/settings.glsl"
#include "/lib/common.glsl"

#ifdef VERTEX_SHADER

out vec2 vTexCoord;
out vec4 vColor;

void main() {
    vTexCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    vColor = gl_Color;
    gl_Position = ftransform();
}

#endif // VERTEX_SHADER

#ifdef FRAGMENT_SHADER

#include "/lib/colorStyles.glsl"

uniform sampler2D tex;
uniform vec3 sunPosition;
uniform vec3 upPosition;
uniform float rainStrength;
uniform int renderStage;

in vec2 vTexCoord;
in vec4 vColor;

/* RENDERTARGETS:0,1,2 */
layout(location = 0) out vec4 outColor;
layout(location = 1) out vec4 outNormalMat;
layout(location = 2) out vec4 outEmissive;

void main() {
    vec4 raw = texture(tex, vTexCoord) * vColor;
    if (raw.a < 0.01) discard;

    vec3 lin = srgbToLinear(raw.rgb);
    StyleLightingPalette pal = getStyleLightingPalette();

    float dayFactor, sunsetFactor, nightFactor;
    getDayFactors(sunPosition, upPosition, dayFactor, sunsetFactor, nightFactor);

    vec3 outRgb = lin * float(SKY_INTENSITY);
    vec3 emitRgb = vec3(0.0);

    #ifdef MC_RENDER_STAGE_SUN
    if (renderStage == MC_RENDER_STAGE_SUN) {
        vec3 sunTint = mix(pal.sunSunset, pal.sunDay, smoothstep(0.05, 0.45, dayFactor));
        outRgb = lin * sunTint * 3.2 * (1.0 - rainStrength * 0.85) * float(SUN_INTENSITY);
        emitRgb = outRgb * 0.75;
    } else
    #endif
    #ifdef MC_RENDER_STAGE_MOON
    if (renderStage == MC_RENDER_STAGE_MOON) {
        outRgb = lin * pal.moonColor * 1.65 * (1.0 - rainStrength * 0.80) * float(MOON_INTENSITY);
        emitRgb = outRgb * 0.40;
    } else
    #endif
    {
        // Custom skyboxes / Enhanced Celestials custom sky textures
        outRgb = lin * float(SKY_INTENSITY) * (1.0 - rainStrength * 0.5);
        emitRgb = max(outRgb - vec3(0.6), vec3(0.0)) * 0.45;
    }

    outColor = vec4(outRgb, raw.a);
    outNormalMat = vec4(0.5, 0.5, MAT_SKY, 1.0);
    outEmissive = vec4(saturate(emitRgb * 0.25), maxOf(emitRgb) > 0.05 ? 0.5 : 0.0);
}

#endif // FRAGMENT_SHADER
