#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/waving.glsl"

#ifdef VERTEX_SHADER

in vec3 mc_Entity;
in vec2 mc_midTexCoord;

uniform mat4 shadowModelViewInverse;
uniform mat4 shadowModelView;
uniform vec3 cameraPosition;
uniform float frameTimeCounter;
uniform float rainStrength;

out vec2 vTexCoord;
out vec4 vColor;
flat out int vBlockId;

#include "/lib/shadows.glsl"

void main() {
    #ifdef SHADOW_ENABLED
    #if !defined(NETHER) && !defined(END)
        vTexCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
        vColor = gl_Color;
        vBlockId = int(mc_Entity.x + 0.5);

        vec4 shadowViewPos = gl_ModelViewMatrix * gl_Vertex;

        // Cull tiny sub-pixel short grass & flowers beyond 50% shadowDistance for huge FPS boost in plains/forests!
        if (vBlockId == 10001 || vBlockId == 10002) {
            vec3 pPos = (shadowModelViewInverse * shadowViewPos).xyz;
            float maxGrassDist = shadowDistance * 0.50;
            if (dot(pPos.xz, pPos.xz) > maxGrassDist * maxGrassDist) {
                gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
                return;
            }
            #ifdef WAVING_FOLIAGE
                vec2 uvMidOffset = vTexCoord - mc_midTexCoord;
                vec3 wave = computeWavingOffset(pPos + cameraPosition, vBlockId, uvMidOffset, frameTimeCounter, rainStrength);
                shadowViewPos = shadowModelView * vec4(pPos + wave, 1.0);
            #endif
        } else if (vBlockId >= 10003 && vBlockId <= 10010) {
            vec3 playerPos = (shadowModelViewInverse * shadowViewPos).xyz;
            vec2 uvMidOffset = vTexCoord - mc_midTexCoord;
            vec3 wave = computeWavingOffset(playerPos + cameraPosition, vBlockId, uvMidOffset, frameTimeCounter, rainStrength);
            shadowViewPos = shadowModelView * vec4(playerPos + wave, 1.0);
        }

        vec4 clipPos = gl_ProjectionMatrix * shadowViewPos;
        float invW = 1.0 / max(abs(clipPos.w), 1e-5);
        clipPos.xy = distortShadowXY(clipPos.xy * invW) * abs(clipPos.w);
        gl_Position = clipPos;
    #else
        gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
        vTexCoord = vec2(0.0);
        vColor = vec4(1.0);
        vBlockId = 0;
    #endif
    #else
        gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
        vTexCoord = vec2(0.0);
        vColor = vec4(1.0);
        vBlockId = 0;
    #endif
}

#endif // VERTEX_SHADER

#ifdef FRAGMENT_SHADER

uniform sampler2D tex;
uniform float alphaTestRef;
uniform int blockEntityId;

in vec2 vTexCoord;
in vec4 vColor;
flat in int vBlockId;

/* RENDERTARGETS:0 */
layout(location = 0) out vec4 outShadowColor;

void main() {
    if (blockEntityId == 10101) discard;

    vec4 albedo = texture(tex, vTexCoord) * vColor;
    if (albedo.a < max(alphaTestRef, 0.05)) discard;

    if (vBlockId == 10010) {
        outShadowColor = vec4(0.48, 0.80, 0.94, 0.30);
    } else {
        outShadowColor = albedo;
    }
}

#endif // FRAGMENT_SHADER
