#include "/lib/settings.glsl"
#include "/lib/common.glsl"

#ifdef VERTEX_SHADER

out vec2 vTexCoord;

void main() {
    vTexCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    gl_Position = ftransform();
}

#endif // VERTEX_SHADER

#ifdef FRAGMENT_SHADER

#include "/lib/dof.glsl"

uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D depthtex0;

uniform float viewWidth;
uniform float viewHeight;
uniform float near;
uniform float far;
uniform float centerDepthSmooth;
uniform int frameCounter;

in vec2 vTexCoord;

/* RENDERTARGETS:0 */
layout(location = 0) out vec4 outColor;

void main() {
    vec2 texelSize = 1.0 / max(vec2(viewWidth, viewHeight), vec2(1.0));

    vec3 dofColor = computeBokehDoF(
        vTexCoord, gl_FragCoord.xy, texelSize, viewWidth, viewHeight,
        near, far, centerDepthSmooth, frameCounter,
        colortex0, depthtex0, colortex1
    );

    outColor = vec4(sanitizeHDR(dofColor), 1.0);
}

#endif // FRAGMENT_SHADER
