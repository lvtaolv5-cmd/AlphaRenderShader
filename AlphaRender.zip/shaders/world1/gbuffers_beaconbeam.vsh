#version 330 compatibility
#define VERTEX_SHADER
#define END
#define BEACON_PASS
#include "/program/gbuffers_terrain.glsl"
