#version 330 compatibility
#define VERTEX_SHADER
#define NETHER
#include "/program/gbuffers_clouds.glsl"
