#include "/lib/settings.glsl"
#include "/lib/common.glsl"

#ifdef VERTEX_SHADER

out vec2 vTexCoord;

void main() {
    vTexCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    gl_Position = ftransform();
}

#endif // VERTEX_SHADER

#ifdef FRAGMENT_SHADER

#include "/lib/bloomGlare.glsl"

uniform sampler2D colortex4;
uniform sampler2D colortex6;
uniform float viewWidth;
uniform float viewHeight;

in vec2 vTexCoord;

// TRUE HARDWARE 0.5x0.5 HALF-RES RENDER PASS (4x fewer pixels rasterized!)
/* RENDERTARGETS:6,4 */
layout(location = 0) out vec4 outBloomAtlasV;
layout(location = 1) out vec4 outGlarePass2;

void main() {
    // 1 texel of our 0.5x0.5 half-res buffers = 2.0 / full resolution
    vec2 halfTexelSize = 2.0 / max(vec2(viewWidth, viewHeight), vec2(2.0));

    // Pass 2: Vertically Blur all 5 Bloom Octaves strictly inside padded bounds
    vec3 bloomV = computeBloomTilePass2(vTexCoord, halfTexelSize, colortex6);

    // Pass 2: Optical Glare / Light Scatter on 0.5x0.5 buffer
    vec3 glare2 = computeGlarePass2(vTexCoord, halfTexelSize, colortex4);

    outBloomAtlasV = vec4(sanitizeHDR(bloomV), 1.0);
    outGlarePass2  = vec4(sanitizeHDR(glare2), 1.0);
}

#endif // FRAGMENT_SHADER
