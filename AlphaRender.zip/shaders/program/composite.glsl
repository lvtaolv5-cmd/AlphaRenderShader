#include "/lib/settings.glsl"
#include "/lib/common.glsl"

#ifdef VERTEX_SHADER

out vec2 vTexCoord;

void main() {
    vTexCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    gl_Position = ftransform();
}

#endif // VERTEX_SHADER

#ifdef FRAGMENT_SHADER

// High-Speed 32-bit + Hardware Half-Res RenderTarget Layout
/*
const int colortex0Format = R11F_G11F_B10F;
const int colortex1Format = RGBA8;
const int colortex2Format = RGBA8;
const int colortex3Format = R11F_G11F_B10F;
const int colortex4Format = R11F_G11F_B10F;
const int colortex5Format = RGBA16F;
const int colortex6Format = R11F_G11F_B10F;
*/

#include "/lib/atmosphere.glsl"
#include "/lib/water.glsl"
#include "/lib/bloomGlare.glsl"

uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D colortex2;
uniform sampler2D colortex3; // Clean pre-water opaque scene written by deferred.glsl!
uniform sampler2D depthtex0;
uniform sampler2D depthtex1;

uniform mat4 gbufferProjection;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform vec3 cameraPosition;
uniform vec3 sunPosition;
uniform vec3 moonPosition;
uniform vec3 upPosition;
uniform vec3 fogColor;
uniform float near;
uniform float far;
uniform float frameTimeCounter;
uniform float rainStrength;
uniform int frameCounter;
uniform int isEyeInWater;

in vec2 vTexCoord;

/* RENDERTARGETS:0,3 */
layout(location = 0) out vec4 outScene;
layout(location = 1) out vec4 outBloomSrc;

// Full 4-Mode Optical Water Composition (100% Iris/Vulkan legal — runs ONLY on MAT_WATER pixels!)
vec3 shadeWaterComposite(vec2 uv, vec3 surfaceCol, vec4 normMat, vec4 emissiveTarget, float depth0, float depth1) {
    vec3 waterViewPos = screenToView(vec3(uv, depth0), gbufferProjectionInverse);
    vec3 waterPlayerPos = (gbufferModelViewInverse * vec4(waterViewPos, 1.0)).xyz;
    vec3 waterWorldPos = waterPlayerPos + cameraPosition;
    vec3 waterViewNorm = decodeNormal(normMat.xy);
    float skyLight = normMat.w;

    float waterLin = linearizeDepth(depth0, near, far);
    float bgLin = linearizeDepth(depth1, near, far);
    float waterDepth = max(bgLin - waterLin, 0.0);
    float distToCam = length(waterViewPos);

    vec3 V = safeNormalize(-waterViewPos);
    float NdotV = max(dot(waterViewNorm, V), 0.0);

    // Unpack sun/moon specular sparkle written by gbuffers_water into colortex2
    vec3 waterSpecular = (emissiveTarget.a > 0.10 && emissiveTarget.a < 0.75) ? unpackEmissiveHDR(emissiveTarget.rgb) : vec3(0.0);

    // ---------- 1. Refracted Underwater Seabed Sampling from Read-Only colortex3 ----------
    vec2 refractUV = uv;
    float refractedDepth = waterDepth;
    #ifdef WATER_REFRACTION
        #if WATER_MODE > 0
            // Project wave normal deviation into screen-space refraction offset
            vec3 upView = safeNormalize(upPosition);
            vec3 dev = waterViewNorm - upView * dot(waterViewNorm, upView);
            float refractAmp = (WATER_MODE == 3 ? 0.032 : 0.020) * saturate(waterDepth * 0.45) / max(distToCam * 0.07 + 1.0, 1.0);
            vec2 candUV = clamp(uv + dev.xy * refractAmp, vec2(0.002), vec2(0.998));
            float candDepth = texture(depthtex1, candUV).r;
            // Strict depth guard: only sample refracted pixel if it lies BEHIND the water surface!
            if (candDepth >= depth0 - 1e-5) {
                refractUV = candUV;
                refractedDepth = max(linearizeDepth(candDepth, near, far) - waterLin, 0.0);
            }
        #endif
    #endif
    vec3 underwaterBg = sanitizeHDR(texture(colortex3, refractUV).rgb);

    // ---------- 2. Sky & Fast Binary-Refined SSR Reflection ----------
    vec3 reflectionCol = vec3(0.0);
    float fresnel = 0.0;
    #ifdef WATER_REFLECTIONS
        vec3 reflDir = reflect(-V, waterViewNorm);
        vec3 upV = safeNormalize(upPosition);
        float reflUp = dot(reflDir, upV);
        if (reflUp < 0.02) {
            reflDir = safeNormalize(reflDir - upV * (reflUp - 0.02));
        }
        vec3 skyRefl = computeSkyColor(reflDir, sunPosition, upPosition, rainStrength, fogColor);
        skyRefl *= mix(0.18, 1.0, smoothstep(0.08, 0.65, skyLight));

        #if WATER_MODE == 0
            fresnel = 0.02 + 0.34 * pow(1.0 - NdotV, 4.5);
            reflectionCol = skyRefl;
        #else
            float f0 = (WATER_MODE == 3) ? 0.028 : 0.042;
            fresnel = f0 + (1.0 - f0) * pow(1.0 - NdotV, 4.5);
            vec4 ssr = traceFastWaterSSR(
                waterViewPos, waterViewNorm, gbufferProjection,
                near, far, gl_FragCoord.xy, frameCounter, colortex3, depthtex1
            );
            reflectionCol = mix(skyRefl, ssr.rgb, ssr.a * 0.92);
        #endif
    #endif

    // ---------- 3. Compose by Active Water Mode (0..3) ----------
    vec3 finalWater = surfaceCol;

    #if WATER_MODE == 0
        // Mode 0: 原版水 (Vanilla Water) — surfaceCol already has clean GPU alpha-blended vanilla water!
        #ifdef WATER_REFLECTIONS
            finalWater = mix(finalWater, reflectionCol, fresnel * 0.45);
        #endif

    #elif WATER_MODE == 1
        // Mode 1: 原版上色水 (Enhanced Vanilla — Sildur's Enhanced Default Fancy)
        // surfaceCol holds pure boosted vanilla water texture + vibrant biome tint!
        float depthAlpha = clamp(1.0 - exp(-refractedDepth * 0.24 * float(WATER_ABSORPTION)), 0.32, 0.84);
        vec3 tintedBg = underwaterBg * mix(vec3(1.0), clamp(surfaceCol * 1.45 + vec3(0.25), vec3(0.35), vec3(1.0)), saturate(refractedDepth * 0.14));
        finalWater = mix(tintedBg, surfaceCol, depthAlpha);
        #ifdef WATER_REFLECTIONS
            finalWater = mix(finalWater, reflectionCol, saturate(fresnel * 0.88));
        #endif
        finalWater += waterSpecular * 0.80;

    #elif WATER_MODE == 2
        // Mode 2: 纯非原版水 (Pure Non-Vanilla Clean Stylized Water — ZERO vanilla pixel texture!)
        vec3 absorb = exp(-refractedDepth * vec3(0.30, 0.14, 0.08) * float(WATER_ABSORPTION));
        vec3 transmitted = underwaterBg * mix(vec3(1.0), absorb, 0.88);
        float bodyOpacity = clamp(1.0 - exp(-refractedDepth * 0.20 * float(WATER_ABSORPTION)), 0.08, 0.82);
        finalWater = mix(transmitted, surfaceCol * 0.82, bodyOpacity);
        #ifdef WATER_REFLECTIONS
            finalWater = mix(finalWater, reflectionCol, saturate(fresnel * 0.94));
        #endif
        finalWater += waterSpecular * 0.85;

    #else
        // Mode 3: 真实水 (Realistic PBR Water — Beer-Lambert + 3D Seabed Caustics + Shore Foam + SSR!)
        StyleLightingPalette pal = getStyleLightingPalette();
        float dayFactor, sunsetFactor, nightFactor;
        getDayFactors(sunPosition, upPosition, dayFactor, sunsetFactor, nightFactor);
        vec3 sunCol = mix(pal.sunSunset, pal.sunDay, smoothstep(0.05, 0.45, dayFactor)) * dayFactor * float(SUN_INTENSITY);

        vec3 bgWithCaustics = underwaterBg;
        #ifdef WATER_CAUSTICS
            if (refractedDepth > 0.05 && refractedDepth < 16.0 && dayFactor > 0.05) {
                float refractedDepthRaw = texture(depthtex1, refractUV).r;
                vec3 seabedView = screenToView(vec3(refractUV, refractedDepthRaw), gbufferProjectionInverse);
                vec3 seabedWorld = (gbufferModelViewInverse * vec4(seabedView, 1.0)).xyz + cameraPosition;
                float caustics = computeWaterCaustics(seabedWorld.xz, frameTimeCounter);
                float cFade = exp(-refractedDepth * 0.18) * smoothstep(0.05, 0.45, refractedDepth) * smoothstep(0.2, 0.7, skyLight) * (1.0 - rainStrength * 0.75);
                bgWithCaustics += underwaterBg * sunCol * caustics * cFade * 0.78;
            }
        #endif

        vec3 transmittance = exp(-refractedDepth * vec3(0.42, 0.16, 0.085) * float(WATER_ABSORPTION));
        vec3 waterVolume = bgWithCaustics * transmittance + surfaceCol * (1.0 - transmittance);

        // Subtle realistic shoreline edge contact foam
        #ifdef WATER_FOAM
            float shoreMask = (1.0 - smoothstep(0.02, 0.34, refractedDepth)) * smoothstep(0.0, 0.04, refractedDepth);
            float foamWave = smoothstep(0.18, 0.78, sin(waterWorldPos.x * 5.2 + waterWorldPos.z * 4.7 + frameTimeCounter * 2.4) * 0.5 + 0.5);
            float foam = shoreMask * (0.28 + 0.45 * foamWave);
            vec3 foamColor = vec3(0.86, 0.93, 0.98) * (0.25 + 0.75 * dayFactor) * (0.35 + 0.65 * skyLight);
            waterVolume = mix(waterVolume, foamColor, saturate(foam * 0.62));
        #endif

        finalWater = waterVolume;
        #ifdef WATER_REFLECTIONS
            finalWater = mix(finalWater, reflectionCol, saturate(fresnel * 0.95));
        #endif
        finalWater += waterSpecular;
    #endif

    // Apply atmospheric fog seamlessly over composited water (Mode 0 already fogged in gbuffers_water)
    #if WATER_MODE == 0
        return finalWater;
    #else
        return applyAtmosphericFog(finalWater, waterViewPos, waterPlayerPos, sunPosition, upPosition, far, rainStrength, isEyeInWater, fogColor);
    #endif
}

void main() {
    vec2 uv = vTexCoord;

    // Subtle underwater refractive shimmer when submerged
    if (isEyeInWater == 1) {
        vec2 wave = vec2(
            sin(uv.y * 28.0 + frameTimeCounter * 3.2),
            cos(uv.x * 24.0 + frameTimeCounter * 2.7)
        ) * 0.0020;
        vec2 border = smoothstep(vec2(0.0), vec2(0.06), uv) * smoothstep(vec2(1.0), vec2(0.94), uv);
        uv = clamp(uv + wave * border.x * border.y, vec2(0.001), vec2(0.999));
    }

    vec3 sceneCol = sanitizeHDR(texture(colortex0, uv).rgb);
    vec4 normMat = texture(colortex1, uv);
    vec4 emissiveTarget = texture(colortex2, uv);

    // Execute 4-Mode Water Composition strictly on water pixels when camera is above water!
    if (isEyeInWater == 0 && abs(normMat.z - MAT_WATER) < 0.06) {
        float d0 = texture(depthtex0, uv).r;
        float d1 = texture(depthtex1, uv).r;
        if (d0 < 0.9999 && d1 >= d0 - 1e-5) {
            sceneCol = shadeWaterComposite(uv, sceneCol, normMat, emissiveTarget, d0, d1);
        }
    }

    // Volumetric screen-space sun/moon light shafts (early radial culled!)
    if (isEyeInWater == 0) {
        vec3 shafts = computeLightShafts(
            uv, gl_FragCoord.xy, frameCounter,
            sunPosition, moonPosition, upPosition,
            gbufferProjection, rainStrength, depthtex0
        );
        sceneCol += shafts;
    }

    // Extract HDR + Emissives + Colored (!Black) Selection Outline into Bloom Source (colortex3)
    vec3 bloomSource = extractBloomSource(sceneCol, emissiveTarget);

    outScene    = vec4(sanitizeHDR(sceneCol), 1.0);
    outBloomSrc = vec4(sanitizeHDR(bloomSource), 1.0);
}

#endif // FRAGMENT_SHADER
