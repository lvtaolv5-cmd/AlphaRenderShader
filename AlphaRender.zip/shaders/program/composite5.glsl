#include "/lib/settings.glsl"
#include "/lib/common.glsl"

#ifdef VERTEX_SHADER

out vec2 vTexCoord;

void main() {
    vTexCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    gl_Position = ftransform();
}

#endif // VERTEX_SHADER

#ifdef FRAGMENT_SHADER

// Keep colortex5 persistent across frames for TAA / Temporal MSAA history & (0,0) Auto-Exposure!
const bool colortex5Clear = false;

#include "/lib/antialiasing.glsl"

uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D colortex5;
uniform sampler2D depthtex0;

uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferPreviousModelView;
uniform mat4 gbufferPreviousProjection;
uniform vec3 cameraPosition;
uniform vec3 previousCameraPosition;
uniform float viewWidth;
uniform float viewHeight;
uniform float near;
uniform float far;
uniform float frameTime;
uniform int frameCounter;

in vec2 vTexCoord;

/* RENDERTARGETS:0,5 */
layout(location = 0) out vec4 outColor;
layout(location = 1) out vec4 outHistory;

// Execute the 5x5 auto-exposure meter ONLY on texel (0, 0) instead of every pixel (~3,000,000x faster!)
float updateSmoothAutoExposurePixel0() {
    #ifndef AUTO_EXPOSURE
        return float(AUTO_EXPOSURE_TARGET);
    #else
        if (ivec2(gl_FragCoord.xy) != ivec2(0, 0)) {
            return 0.0;
        }
        float logSum = 0.0;
        float wSum = 0.0;
        for (int y = 0; y < 5; y++) {
            for (int x = 0; x < 5; x++) {
                vec2 p = vec2((float(x) + 0.5) / 5.0, (float(y) + 0.5) / 5.0);
                float distC = length(p - 0.5);
                float w = exp(-distC * distC * 3.5);
                vec3 s = sanitizeHDR(texture(colortex0, p).rgb);
                float lum = clamp(getLuminance(s), 0.012, 12.0);
                logSum += log2(lum) * w;
                wSum += w;
            }
        }
        float currAvgLum = exp2(logSum / max(wSum, 1e-4));
        float prevLum = texelFetch(colortex5, ivec2(0, 0), 0).a;

        if (frameCounter < 2 || prevLum <= 1e-4 || isnan(prevLum) || isinf(prevLum)) {
            return currAvgLum;
        }
        float adapt = 1.0 - exp(-clamp(frameTime, 0.001, 0.25) * float(AUTO_EXPOSURE_SPEED));
        return mix(prevLum, currAvgLum, saturate(adapt));
    #endif
}

void main() {
    vec2 viewSize = max(vec2(viewWidth, viewHeight), vec2(1.0));
    vec3 result = sanitizeHDR(texture(colortex0, vTexCoord).rgb);

    #if AA_MODE == 2
        vec3 msaaCol = computeGeometricMSAA(vTexCoord, viewSize, near, far, colortex0, depthtex0, colortex1);
        #ifdef MSAA_TEMPORAL_RGSS
            if (frameCounter >= 2) {
                vec3 taaEst = computeTAA(
                    vTexCoord, viewSize, near, far, frameCounter,
                    colortex0, colortex5, depthtex0, colortex1,
                    gbufferProjectionInverse, gbufferModelViewInverse,
                    cameraPosition, previousCameraPosition,
                    gbufferPreviousModelView, gbufferPreviousProjection
                );
                result = mix(msaaCol, taaEst, 0.45);
            } else {
                result = msaaCol;
            }
        #else
            result = msaaCol;
        #endif
    #elif AA_MODE == 4 || AA_MODE == 5
        if (frameCounter >= 2) {
            result = computeTAA(
                vTexCoord, viewSize, near, far, frameCounter,
                colortex0, colortex5, depthtex0, colortex1,
                gbufferProjectionInverse, gbufferModelViewInverse,
                cameraPosition, previousCameraPosition,
                gbufferPreviousModelView, gbufferPreviousProjection
            );
        }
    #elif AA_MODE == 6
        vec3 msaaCol = computeGeometricMSAA(vTexCoord, viewSize, near, far, colortex0, depthtex0, colortex1);
        if (frameCounter >= 2) {
            vec3 taaCol = computeTAA(
                vTexCoord, viewSize, near, far, frameCounter,
                colortex0, colortex5, depthtex0, colortex1,
                gbufferProjectionInverse, gbufferModelViewInverse,
                cameraPosition, previousCameraPosition,
                gbufferPreviousModelView, gbufferPreviousProjection
            );
            result = mix(taaCol, msaaCol, 0.35);
        } else {
            result = msaaCol;
        }
    #endif

    float smoothAvgLum = updateSmoothAutoExposurePixel0();

    outColor   = vec4(sanitizeHDR(result), 1.0);
    outHistory = vec4(hdrToTaaSpace(result), smoothAvgLum);
}

#endif // FRAGMENT_SHADER
