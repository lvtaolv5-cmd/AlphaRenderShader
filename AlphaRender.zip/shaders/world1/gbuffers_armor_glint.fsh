#version 330 compatibility
#define FRAGMENT_SHADER
#define END
#define ARMOR_GLINT_PASS
#include "/program/gbuffers_terrain.glsl"
