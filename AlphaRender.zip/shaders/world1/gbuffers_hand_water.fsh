#version 330 compatibility
#define FRAGMENT_SHADER
#define END
#define HAND_WATER_PASS
#include "/program/gbuffers_water.glsl"
