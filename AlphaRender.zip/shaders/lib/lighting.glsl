#ifndef LIB_LIGHTING_GLSL
#define LIB_LIGHTING_GLSL

#include "/lib/colorStyles.glsl"

// Frame-constant lighting values precomputed ONCE per vertex (flat out) instead of per fragment!
struct VertexLightData {
    vec3 shadowLightDir;
    vec3 styleSkyTint;
    vec3 sunLightColor;
    vec3 blocklightTint;
    vec3 ambientDay;
    float dayFactor;
    float horizonFade;
};

VertexLightData precomputeVertexLightData(vec3 shadowLightPos, vec3 sunPos, vec3 upPos, float rainStrength) {
    VertexLightData d;
    StyleLightingPalette pal = getStyleLightingPalette();
    d.shadowLightDir = safeNormalize(shadowLightPos);
    d.blocklightTint = pal.blocklightTint;
    d.ambientDay = pal.ambientDay;

    float dayF, sunsetF, nightF;
    getDayFactors(sunPos, upPos, dayF, sunsetF, nightF);
    d.dayFactor = dayF;

    vec3 styleSun = mix(pal.sunSunset, pal.sunDay, smoothstep(0.05, 0.45, dayF));
    vec3 skyTint = mix(pal.ambientNight * 1.6 + vec3(0.45), mix(pal.ambientDay * 0.55 + vec3(0.55), styleSun, 0.45), dayF);
    d.styleSkyTint = mix(skyTint, vec3(1.0), rainStrength * 0.60);

    d.sunLightColor = dayF >= 0.05
        ? styleSun * float(SUN_INTENSITY) * (0.85 + 0.35 * dayF)
        : pal.moonColor * float(MOON_INTENSITY) * 0.42;

    float shadowSunHeight = abs(dot(d.shadowLightDir, safeNormalize(upPos)));
    d.horizonFade = smoothstep(0.01, 0.10, shadowSunHeight);
    return d;
}

// Compute emissive boost from block.properties IDs & albedo
vec3 computeBlockEmissive(vec3 linearAlbedo, int blockId, vec2 lmCoord) {
    #ifndef EMISSIVE_BLOCKS
        return vec3(0.0);
    #else
        float emissiveWeight = 0.0;

        if (blockId == 10100) {
            emissiveWeight = 1.75;
        } else if (blockId == 10101) {
            emissiveWeight = 1.95;
        } else if (blockId == 10102) {
            float luma = getLuminance(linearAlbedo);
            float sat = maxOf(linearAlbedo) - minOf(linearAlbedo);
            emissiveWeight = smoothstep(0.08, 0.55, luma + sat * 1.4) * 1.25;
        }
        #ifdef EMISSIVE_ORES
        else if (blockId == 10103) {
            float maxC = maxOf(linearAlbedo);
            float minC = minOf(linearAlbedo);
            float chroma = maxC - minC;
            float oreMask = smoothstep(0.11, 0.28, chroma) * smoothstep(0.08, 0.30, maxC);
            emissiveWeight = oreMask * 1.40;
        }
        #endif

        if (emissiveWeight <= 0.001) return vec3(0.0);
        return linearAlbedo * emissiveWeight * float(EMISSIVE_STRENGTH);
    #endif
}

// Vanilla Minecraft Non-Realtime Directional Block-Face Shading
float computeVanillaFaceShade(vec3 worldNormal, bool isFoliage) {
    if (isFoliage) return 0.92;
    vec3 n = safeNormalize(worldNormal);
    float topWeight    = max(n.y, 0.0);
    float bottomWeight = max(-n.y, 0.0);
    float nsWeight     = abs(n.z);
    float ewWeight     = abs(n.x);
    float normSum = max(topWeight + bottomWeight + nsWeight + ewWeight, 1e-4);
    return (topWeight * 1.00 + nsWeight * 0.86 + ewWeight * 0.74 + bottomWeight * 0.56) / normSum;
}

// High-Speed Hybrid Lighting Engine (Sildur Basic Fancy + Enhanced Default Fancy + Cool Pixel Shadows!)
vec3 computeHybridSurfaceLightingFast(
    vec3 linearAlbedo,
    vec3 vanillaLightmapLinear,
    vec3 viewNormal,
    vec3 worldNormal,
    vec3 viewPos,
    vec2 lmCoord,
    float ao,
    vec3 shadowVis,
    bool isFoliage,
    vec3 shadowLightDir,
    vec3 styleSkyTint,
    vec3 sunLightColor,
    vec3 blocklightTint,
    vec3 ambientDay,
    float dayFactor,
    float horizonFade,
    float rainStrength,
    float wetness,
    int eyeBrightSky,
    out vec3 specularBloomAdd
) {
    specularBloomAdd = vec3(0.0);

    float nonRtStrength = float(NON_REALTIME_SHADOW);
    float vanillaFace = computeVanillaFaceShade(worldNormal, isFoliage);

    float torchMask = smoothstep(0.08, 0.95, lmCoord.x);
    vec3 torchWarmMod = mix(vec3(1.0), mix(vec3(1.0, 0.94, 0.88), blocklightTint * 1.15, float(BLOCKLIGHT_WARMTH)), torchMask * 0.55);
    float blockLightBoost = mix(1.0, float(BLOCKLIGHT_INTENSITY), torchMask * 0.65);

    #ifdef NETHER
        float nShade = mix(1.0, vanillaFace, nonRtStrength);
        return linearAlbedo * vanillaLightmapLinear * vec3(1.02, 0.98, 0.96) * torchWarmMod * blockLightBoost * nShade * ao * float(AMBIENT_INTENSITY);
    #elif defined(END)
        float eShade = mix(1.0, vanillaFace, nonRtStrength);
        return linearAlbedo * vanillaLightmapLinear * vec3(0.99, 0.98, 1.03) * torchWarmMod * blockLightBoost * eShade * ao * float(AMBIENT_INTENSITY);
    #else
        float rawNdotL = dot(viewNormal, shadowLightDir);
        float NdotL = isFoliage ? 0.68 : clamp(rawNdotL * 1.02 - 0.02, 0.0, 1.0);

        float sss = 0.0;
        #ifdef FOLIAGE_SSS
            if (isFoliage) {
                vec3 viewDir = safeNormalize(-viewPos);
                float backLight = pow(saturate(dot(viewDir, -shadowLightDir)), 2.5);
                sss = backLight * 0.45 * lmCoord.y;
            }
        #endif

        // LAYER 1: Sildur's Basic Fancy Non-Realtime Shadows & Vanilla Lightmap
        float basicDirShade = clamp((1.0 + NdotL) * 0.64, 0.58, 1.12);
        float combinedNonRtShade = mix(1.0, mix(vanillaFace, vanillaFace * basicDirShade, 0.65), nonRtStrength);

        vec3 baseLightmap = vanillaLightmapLinear * mix(vec3(1.0), styleSkyTint, saturate(lmCoord.y) * 0.52) * torchWarmMod * blockLightBoost;
        vec3 baseLit = linearAlbedo * baseLightmap * combinedNonRtShade * ao * float(AMBIENT_INTENSITY);

        // LAYER 2: Sildur's Enhanced Default Fancy Real-Time Forced Pixel Shadows + Cool Shadow Color
        #ifdef SHADOW_ENABLED
            float eyeSkyFactor = clamp((float(eyeBrightSky) / 240.0 - 2.0 / 16.0) * 4.0, 0.0, 1.0);
            float skyCaveMask = mix(clamp((lmCoord.y - 2.0 / 16.0) * 1.142857, 0.0, 1.0), 1.0, eyeSkyFactor);
            float rtActive = skyCaveMask * (1.0 - rainStrength * 0.85) * horizonFade * float(REALTIME_SHADOW_STRENGTH);

            vec3 directFactor = shadowVis * (NdotL * 0.88 + sss * 0.55 + (isFoliage ? 0.12 : 0.0));

            float visLum = saturate(getLuminance(shadowVis));
            float sunlitMask = saturate(visLum * smoothstep(0.0, 0.25, NdotL + (isFoliage ? 0.25 : 0.0)));
            float inShadowMask = (1.0 - sunlitMask) * rtActive * (1.0 - torchMask * 0.72);

            vec3 coolShadowTint = vec3(float(SHADOW_COLOR_R), float(SHADOW_COLOR_G), float(SHADOW_COLOR_B));
            vec3 shadowColorMod = mix(vec3(1.0), coolShadowTint, saturate(inShadowMask * float(SHADOW_COLOR_STRENGTH)));
            float shadowDarken = mix(1.0, 0.62, saturate(inShadowMask * (0.45 + 0.55 * dayFactor)));

            vec3 hybridColor = baseLit * shadowColorMod * shadowDarken + baseLit * (directFactor * sunLightColor * 0.82 * rtActive);
        #else
            float backShadeMask = (1.0 - NdotL) * saturate(lmCoord.y) * (1.0 - torchMask * 0.7) * (1.0 - rainStrength * 0.7);
            vec3 coolShadowTint = vec3(float(SHADOW_COLOR_R), float(SHADOW_COLOR_G), float(SHADOW_COLOR_B));
            vec3 shadeMod = mix(vec3(1.0), coolShadowTint, saturate(backShadeMask * float(SHADOW_COLOR_STRENGTH) * 0.55));
            vec3 sunLift = mix(vec3(1.0), sunLightColor * 0.35 + vec3(0.95), NdotL * dayFactor * (1.0 - rainStrength * 0.7));
            vec3 hybridColor = baseLit * shadeMod * sunLift;
        #endif

        #ifdef RAIN_WETNESS
            float wetMask = wetness * smoothstep(0.70, 0.96, lmCoord.y) * smoothstep(0.35, 0.85, worldNormal.y);
            if (wetMask > 0.01) {
                vec3 V = safeNormalize(-viewPos);
                vec3 H = safeNormalize(shadowLightDir + V);
                float NdotH = max(dot(viewNormal, H), 0.0);
                float NdotV = max(dot(viewNormal, V), 0.0);
                float fresnel = 0.03 + 0.97 * pow(1.0 - NdotV, 5.0);
                float ggx = pow(NdotH, 64.0) * 1.15;
                vec3 wetSpec = (sunLightColor * ggx * shadowVis + ambientDay * fresnel * 0.45) * wetMask * 0.48;
                hybridColor = hybridColor * mix(1.0, 0.82, wetMask) + wetSpec;
                specularBloomAdd = sunLightColor * ggx * shadowVis * wetMask * 0.30;
            }
        #endif

        return hybridColor;
    #endif
}

#endif // LIB_LIGHTING_GLSL
