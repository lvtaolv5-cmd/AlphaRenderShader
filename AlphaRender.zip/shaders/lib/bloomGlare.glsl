#ifndef LIB_BLOOM_GLARE_GLSL
#define LIB_BLOOM_GLARE_GLSL

/* ============================================================================
   AlphaRender - EXTREME PERFORMANCE Hardware Half-Res Bloom & Optical Glare
   - colortex6 (Bloom Atlas) AND colortex4 (Optical Glare) BOTH use
     size.buffer = 0.5 0.5 -> TRUE HARDWARE 4x FEWER PIXELS RASTERIZED in
     both composite1 & composite2!!
   - Colored (!Black) Block Selection Outlines (colortex2.a >= 0.75) still
     unconditionally enter BOTH Bloom & Optical Glare targets!
   ============================================================================ */

// 5-octave padded bloom atlas inside 0.5x0.5 colortex6 (effective 1/4, 1/8, 1/16, 1/32, 1/64 screen!)
vec4 getBloomTileRect(int octave) {
    if (octave == 0) return vec4(0.00, 0.00, 0.500000, 0.500000); // 1/4 screen
    if (octave == 1) return vec4(0.52, 0.00, 0.250000, 0.250000); // 1/8 screen
    if (octave == 2) return vec4(0.79, 0.00, 0.125000, 0.125000); // 1/16 screen
    if (octave == 3) return vec4(0.52, 0.28, 0.062500, 0.062500); // 1/32 screen
    return                  vec4(0.61, 0.28, 0.031250, 0.031250); // 1/64 screen
}

int getActiveBloomOctaves() {
    #if BLOOM_QUALITY == 1
        return 3;
    #elif BLOOM_QUALITY == 2
        return 4;
    #else
        return 5;
    #endif
}

vec3 softThresholdHDR(vec3 hdr, float threshold, float knee) {
    hdr = min(sanitizeHDR(hdr), vec3(float(BLOOM_FIREFLY_CLAMP)));
    float br = maxOf(hdr);
    float k = max(threshold * knee, 1e-4);
    float rq = clamp(br - threshold + k, 0.0, 2.0 * k);
    rq = (rq * rq) / (4.0 * k);
    float contrib = max(rq, br - threshold) / max(br, 1e-4);
    return hdr * max(contrib, 0.0);
}

vec3 unpackEmissiveHDR(vec3 packedRgb) {
    return min(sanitizeHDR(packedRgb * 4.0), vec3(float(BLOOM_FIREFLY_CLAMP)));
}

// Extract unified Bloom source in composite.fsh
vec3 extractBloomSource(vec3 hdrScene, vec4 emissiveTarget) {
    #ifndef BLOOM_ENABLED
        return vec3(0.0);
    #else
        vec3 bloomIn = softThresholdHDR(hdrScene, float(BLOOM_THRESHOLD), float(BLOOM_KNEE));

        if (emissiveTarget.a > 0.10 && emissiveTarget.a < 0.75) {
            bloomIn += unpackEmissiveHDR(emissiveTarget.rgb) * float(BLOOM_EMISSIVE_BOOST) * 0.55;
        }
        // Colored (!Black) Block Selection Outline unconditionally enters Bloom target!
        if (emissiveTarget.a >= 0.75) {
            bloomIn += unpackEmissiveHDR(emissiveTarget.rgb) * float(SELECT_BOX_BLOOM_MULT);
        }

        float luma = getLuminance(bloomIn);
        return max(mix(vec3(luma), bloomIn, float(BLOOM_SATURATION)), vec3(0.0));
    #endif
}

// Extract Optical Glare source at half-res in composite1.fsh
vec3 extractGlareSource(vec3 hdrScene, vec4 emissiveTarget) {
    #ifndef GLARE_ENABLED
        return vec3(0.0);
    #else
        vec3 glareIn = softThresholdHDR(hdrScene, float(GLARE_THRESHOLD), 0.35);

        if (emissiveTarget.a > 0.10 && emissiveTarget.a < 0.75) {
            glareIn += unpackEmissiveHDR(emissiveTarget.rgb) * 0.45 * float(BLOOM_EMISSIVE_BOOST);
        }
        // Colored (!Black) Block Selection Outline unconditionally enters Optical Glare target!
        if (emissiveTarget.a >= 0.75) {
            glareIn += unpackEmissiveHDR(emissiveTarget.rgb) * float(SELECT_BOX_GLARE_MULT) * 1.25;
        }

        return glareIn;
    #endif
}

// Hardware Half-Res Bloom Pass 1 (Downsample full-res colortex3 -> 0.5x0.5 colortex6 + H-Blur)
vec3 computeBloomTilePass1(vec2 uv, vec2 fullTexelSize, sampler2D fullSourceTex) {
    #ifndef BLOOM_ENABLED
        return vec3(0.0);
    #else
        if (uv.y > 0.51 || uv.x > 0.925) return vec3(0.0);

        int maxOct = getActiveBloomOctaves();
        for (int oct = 0; oct < 5; oct++) {
            if (oct >= maxOct) break;
            vec4 rect = getBloomTileRect(oct);
            if (uv.x >= rect.x && uv.x <= rect.x + rect.z && uv.y >= rect.y && uv.y <= rect.y + rect.w) {
                vec2 localUV = (uv - rect.xy) / rect.zw;
                // Because colortex6 is already 0.5x0.5, rect.z=0.5 corresponds to 1/4 full screen (scale=4)
                float scale = exp2(float(oct + 2));
                vec2 stepUV = vec2(fullTexelSize.x * scale * 0.78 * float(BLOOM_RADIUS), 0.0);

                #if BLOOM_QUALITY >= 5
                    const int HALF_TAPS = 4;
                #elif BLOOM_QUALITY >= 3
                    const int HALF_TAPS = 3;
                #else
                    const int HALF_TAPS = 2;
                #endif

                vec3 accum = vec3(0.0);
                float wSum = 0.0;
                for (int i = -HALF_TAPS; i <= HALF_TAPS; i++) {
                    float fi = float(i);
                    float w = exp(-0.5 * sqr(fi / (float(HALF_TAPS) * 0.55)));
                    vec2 sampleUV = clamp(localUV + stepUV * fi, vec2(0.001), vec2(0.999));
                    accum += texture(fullSourceTex, sampleUV).rgb * w;
                    wSum += w;
                }
                return accum / max(wSum, 1e-4);
            }
        }
        return vec3(0.0);
    #endif
}

// Hardware Half-Res Bloom Pass 2 (V-Blur strictly inside each tile of 0.5x0.5 colortex6)
vec3 computeBloomTilePass2(vec2 uv, vec2 halfTexelSize, sampler2D atlasTex) {
    #ifndef BLOOM_ENABLED
        return vec3(0.0);
    #else
        if (uv.y > 0.51 || uv.x > 0.925) return vec3(0.0);

        int maxOct = getActiveBloomOctaves();
        for (int oct = 0; oct < 5; oct++) {
            if (oct >= maxOct) break;
            vec4 rect = getBloomTileRect(oct);
            if (uv.x >= rect.x && uv.x <= rect.x + rect.z && uv.y >= rect.y && uv.y <= rect.y + rect.w) {
                vec2 minBound = rect.xy + halfTexelSize * 0.6;
                vec2 maxBound = rect.xy + rect.zw - halfTexelSize * 0.6;
                vec2 stepUV = vec2(0.0, halfTexelSize.y * 1.15 * float(BLOOM_RADIUS));

                #if BLOOM_QUALITY >= 5
                    const int HALF_TAPS = 4;
                #elif BLOOM_QUALITY >= 3
                    const int HALF_TAPS = 3;
                #else
                    const int HALF_TAPS = 2;
                #endif

                vec3 accum = vec3(0.0);
                float wSum = 0.0;
                for (int i = -HALF_TAPS; i <= HALF_TAPS; i++) {
                    float fi = float(i);
                    float w = exp(-0.5 * sqr(fi / (float(HALF_TAPS) * 0.55)));
                    vec2 sampleUV = clamp(uv + stepUV * fi, minBound, maxBound);
                    accum += texture(atlasTex, sampleUV).rgb * w;
                    wSum += w;
                }
                return accum / max(wSum, 1e-4);
            }
        }
        return vec3(0.0);
    #endif
}

// Ultra-fast 1-fetch-per-octave Hardware-Bilinear Bloom Upsample (composite3)
vec3 sampleCombinedBloom(vec2 uv, vec2 halfTexelSize, sampler2D atlasTex) {
    #ifndef BLOOM_ENABLED
        return vec3(0.0);
    #else
        int maxOct = getActiveBloomOctaves();
        const float OCT_WEIGHTS[5] = float[5](0.32, 0.25, 0.19, 0.14, 0.10);

        vec3 total = vec3(0.0);
        float weightNorm = 0.0;
        for (int oct = 0; oct < 5; oct++) {
            if (oct >= maxOct) break;
            vec4 rect = getBloomTileRect(oct);
            vec2 minBound = rect.xy + halfTexelSize * 0.75;
            vec2 maxBound = rect.xy + rect.zw - halfTexelSize * 0.75;
            vec2 tileUV = clamp(rect.xy + uv * rect.zw, minBound, maxBound);

            float w = OCT_WEIGHTS[oct];
            total += texture(atlasTex, tileUV).rgb * w;
            weightNorm += w;
        }
        total /= max(weightNorm, 1e-4);

        vec3 bloomTint = vec3(float(BLOOM_TINT_R), float(BLOOM_TINT_G), float(BLOOM_TINT_B));
        return sanitizeHDR(total) * bloomTint * float(BLOOM_STRENGTH);
    #endif
}

// ---------- Hardware Half-Res Optical Glare / Light Scatter (0.5x0.5 colortex4!) ----------

vec3 glareSpectralWeight(float t) {
    float chroma = float(GLARE_CHROMA);
    if (chroma <= 0.001) return vec3(1.0);
    vec3 prism = vec3(
        1.0 + 0.42 * sin(t * 5.2 + 0.0),
        1.0 + 0.28 * sin(t * 5.2 + 2.1),
        1.0 + 0.42 * sin(t * 5.2 + 4.2)
    );
    return mix(vec3(1.0), max(prism, vec3(0.28)), saturate(chroma * 0.65));
}

vec3 sampleHalfResStreak(vec2 uv, vec2 dir, vec2 halfTexelSize, float spreadPx, int taps, sampler2D halfTex) {
    vec3 accum = vec3(0.0);
    float wSum = 0.0;
    vec2 minBound = halfTexelSize * 0.75;
    vec2 maxBound = vec2(1.0) - halfTexelSize * 0.75;

    for (int i = -taps; i <= taps; i++) {
        float fi = float(i);
        float normDist = abs(fi) / max(float(taps), 1.0);
        float w = exp(-normDist * 2.55);
        vec2 sUV = clamp(uv + dir * halfTexelSize * (fi * spreadPx), minBound, maxBound);
        vec3 s = texture(halfTex, sUV).rgb;
        accum += s * w * glareSpectralWeight(normDist);
        wSum += w;
    }
    return accum / max(wSum, 1e-4);
}

// Glare Pass 1 on TRUE 0.5x0.5 viewport (uv directly in [0, 1]!)
vec3 computeGlarePass1(vec2 uv, vec2 fullTexelSize, sampler2D fullSceneTex, sampler2D fullEmissiveTex) {
    #ifndef GLARE_ENABLED
        return vec3(0.0);
    #else
        // 4-tap box prefilter over full-res source captures thin 2px colored selection lines cleanly!
        vec2 h = fullTexelSize * 0.75;
        vec2 u0 = clamp(uv + vec2(-h.x, -h.y), vec2(0.001), vec2(0.999));
        vec2 u1 = clamp(uv + vec2( h.x, -h.y), vec2(0.001), vec2(0.999));
        vec2 u2 = clamp(uv + vec2(-h.x,  h.y), vec2(0.001), vec2(0.999));
        vec2 u3 = clamp(uv + vec2( h.x,  h.y), vec2(0.001), vec2(0.999));

        vec3 g0 = extractGlareSource(texture(fullSceneTex, u0).rgb, texture(fullEmissiveTex, u0));
        vec3 g1 = extractGlareSource(texture(fullSceneTex, u1).rgb, texture(fullEmissiveTex, u1));
        vec3 g2 = extractGlareSource(texture(fullSceneTex, u2).rgb, texture(fullEmissiveTex, u2));
        vec3 g3 = extractGlareSource(texture(fullSceneTex, u3).rgb, texture(fullEmissiveTex, u3));
        return (g0 + g1 + g2 + g3) * 0.25;
    #endif
}

// Glare Pass 2 on TRUE 0.5x0.5 viewport
vec3 computeGlarePass2(vec2 uv, vec2 halfTexelSize, sampler2D glarePass1Tex) {
    #ifndef GLARE_ENABLED
        return vec3(0.0);
    #else
        #if GLARE_QUALITY == 1
            const int TAPS = 3;
        #elif GLARE_QUALITY == 2
            const int TAPS = 4;
        #elif GLARE_QUALITY == 3
            const int TAPS = 6;
        #else
            const int TAPS = 8;
        #endif

        float spread = 3.2 * float(GLARE_RADIUS);
        float rotRad = radians(float(GLARE_ROTATION));
        vec2 dA = vec2(cos(rotRad), sin(rotRad));
        vec2 dB = vec2(-dA.y, dA.x);

        vec3 glare = vec3(0.0);

        #if GLARE_MODE == 0
            vec3 h1 = sampleHalfResStreak(uv, vec2(1.0, 0.0), halfTexelSize, spread * 0.90, TAPS, glarePass1Tex);
            vec3 h2 = sampleHalfResStreak(uv, vec2(0.0, 1.0), halfTexelSize, spread * 0.90, TAPS, glarePass1Tex);
            glare = (h1 + h2) * 0.55;
        #elif GLARE_MODE == 1
            vec3 sNarrow = sampleHalfResStreak(uv, vec2(1.0, 0.0), halfTexelSize, spread * 0.85, TAPS, glarePass1Tex);
            vec3 sWide   = sampleHalfResStreak(uv, vec2(1.0, 0.0), halfTexelSize, spread * 2.15, TAPS, glarePass1Tex);
            glare = (sNarrow * 0.55 + sWide * 0.65) * vec3(0.92, 0.98, 1.12);
        #elif GLARE_MODE == 2
            vec3 r1 = sampleHalfResStreak(uv, dA, halfTexelSize, spread * 1.20, TAPS, glarePass1Tex);
            vec3 r2 = sampleHalfResStreak(uv, dB, halfTexelSize, spread * 1.20, TAPS, glarePass1Tex);
            glare = (r1 + r2) * 0.58;
        #elif GLARE_MODE == 3
            vec2 d1 = vec2(cos(rotRad), sin(rotRad));
            vec2 d2 = vec2(cos(rotRad + PI / 3.0), sin(rotRad + PI / 3.0));
            vec2 d3 = vec2(cos(rotRad + 2.0 * PI / 3.0), sin(rotRad + 2.0 * PI / 3.0));
            vec3 r1 = sampleHalfResStreak(uv, d1, halfTexelSize, spread * 1.10, TAPS, glarePass1Tex);
            vec3 r2 = sampleHalfResStreak(uv, d2, halfTexelSize, spread * 1.10, TAPS, glarePass1Tex);
            vec3 r3 = sampleHalfResStreak(uv, d3, halfTexelSize, spread * 1.10, TAPS, glarePass1Tex);
            glare = (r1 + r2 + r3) * 0.42;
        #else
            vec3 anam = sampleHalfResStreak(uv, vec2(1.0, 0.0), halfTexelSize, spread * 1.80, TAPS, glarePass1Tex);
            vec3 ray1 = sampleHalfResStreak(uv, dA,             halfTexelSize, spread * 1.10, TAPS, glarePass1Tex);
            vec3 ray2 = sampleHalfResStreak(uv, dB,             halfTexelSize, spread * 1.10, TAPS, glarePass1Tex);
            glare = anam * 0.48 + (ray1 + ray2) * 0.36;
        #endif

        return sanitizeHDR(glare) * float(GLARE_STRENGTH);
    #endif
}

// Single hardware-bilinear fetch of 0.5x0.5 Glare buffer (composite3)
vec3 sampleHalfResGlare(vec2 uv, sampler2D glareTex) {
    #ifndef GLARE_ENABLED
        return vec3(0.0);
    #else
        return sanitizeHDR(texture(glareTex, clamp(uv, vec2(0.002), vec2(0.998))).rgb);
    #endif
}

#endif // LIB_BLOOM_GLARE_GLSL
