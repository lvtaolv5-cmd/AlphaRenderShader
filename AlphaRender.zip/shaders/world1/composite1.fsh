#version 330 compatibility
#define FRAGMENT_SHADER
#define END
#include "/program/composite1.glsl"
