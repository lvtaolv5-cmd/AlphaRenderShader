#version 330 compatibility
#define FRAGMENT_SHADER
#define END
#define ENTITIES_PASS
#include "/program/gbuffers_terrain.glsl"
