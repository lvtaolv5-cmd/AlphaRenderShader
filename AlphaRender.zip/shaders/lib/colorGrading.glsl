#ifndef LIB_COLOR_GRADING_GLSL
#define LIB_COLOR_GRADING_GLSL

#include "/lib/colorStyles.glsl"

// ---------- 6 Tonemapping Operators ----------

vec3 tonemapACES(vec3 x) {
    // Narkowicz / Krzysztof fitted ACES Filmic with subtle highlight rolloff
    const mat3 ACESInput = mat3(
        0.59719, 0.07600, 0.02840,
        0.35458, 0.90834, 0.13383,
        0.04823, 0.01566, 0.83777
    );
    const mat3 ACESOutput = mat3(
         1.60475, -0.10208, -0.00327,
        -0.53108,  1.10813, -0.07276,
        -0.07367, -0.00605,  1.07602
    );
    vec3 v = ACESInput * max(x, vec3(0.0));
    vec3 a = v * (v + 0.0245786) - 0.000090537;
    vec3 b = v * (0.983729 * v + 0.4329510) + 0.238081;
    return saturate(ACESOutput * (a / max(b, vec3(1e-5))));
}

vec3 agxDefaultContrastApprox(vec3 x) {
    vec3 x2 = x * x;
    vec3 x4 = x2 * x2;
    return + 15.5     * x4 * x2
           - 40.14    * x4 * x
           + 31.96    * x4
           - 6.868    * x2 * x
           + 0.4298   * x2
           + 0.1191   * x
           - 0.00232;
}

vec3 tonemapAgX(vec3 c) {
    const mat3 agxMat = mat3(
        0.842479062253094,  0.0423282422610123, 0.0423756549057051,
        0.0784335999999992, 0.878468636469772,  0.0784336,
        0.0792237451477643, 0.0791661274605434, 0.879142973793104
    );
    const mat3 agxMatInv = mat3(
         1.19687900512017,   -0.0528968517574562, -0.0529716355144438,
        -0.0980208811401368,  1.15190312990417,   -0.0980434501171241,
        -0.0990297440797205, -0.0989611768448433,  1.15107367264116
    );
    vec3 v = agxMat * max(c, vec3(1e-6));
    v = clamp(log2(v), -12.47393, 4.026069);
    v = (v - (-12.47393)) / (4.026069 - (-12.47393));
    v = agxDefaultContrastApprox(v);
    v = agxMatInv * v;
    v = pow(max(v, vec3(0.0)), vec3(2.2));
    return saturate(v);
}

vec3 uncharted2Partial(vec3 x) {
    const float A = 0.15, B = 0.50, C = 0.10, D = 0.20, E = 0.02, F = 0.30;
    return ((x * (A * x + C * B) + D * E) / (x * (A * x + B) + D * F)) - E / F;
}

vec3 tonemapUncharted2(vec3 x) {
    vec3 curr = uncharted2Partial(max(x, vec3(0.0)) * 2.0);
    vec3 whiteScale = 1.0 / uncharted2Partial(vec3(11.2));
    return saturate(curr * whiteScale);
}

vec3 tonemapReinhardExt(vec3 x) {
    x = max(x, vec3(0.0));
    const float whitePoint = 4.5;
    float lum = getLuminance(x);
    float newLum = (lum * (1.0 + lum / (whitePoint * whitePoint))) / (1.0 + lum);
    vec3 mapped = x * (newLum / max(lum, 1e-5));
    return saturate(mapped);
}

vec3 tonemapNeutral(vec3 x) {
    x = max(x, vec3(0.0));
    float startCompression = 0.8 - 0.04;
    float desaturation = 0.15;
    float peak = maxOf(x);
    if (peak < startCompression) return x;
    float d = 1.0 - startCompression;
    float newPeak = 1.0 - d * d / (peak + d - startCompression);
    x *= newPeak / max(peak, 1e-5);
    float g = 1.0 - 1.0 / (desaturation * (peak - newPeak) + 1.0);
    return saturate(mix(x, vec3(newPeak), g));
}

vec3 applyTonemap(vec3 hdr) {
    #if TONEMAP_OPERATOR == 0
        return tonemapACES(hdr);
    #elif TONEMAP_OPERATOR == 1
        return tonemapAgX(hdr);
    #elif TONEMAP_OPERATOR == 2
        return tonemapUncharted2(hdr);
    #elif TONEMAP_OPERATOR == 3
        return tonemapReinhardExt(hdr);
    #elif TONEMAP_OPERATOR == 4
        return tonemapNeutral(hdr);
    #else
        return saturate(hdr);
    #endif
}

// ---------- White Balance (Temperature & Tint) ----------
vec3 applyWhiteBalance(vec3 c) {
    float temp = float(COLOR_TEMPERATURE);
    float tint = float(COLOR_GREEN_MAGENTA);
    vec3 wb = vec3(
        1.0 + temp * 0.22 + tint * 0.08,
        1.0 - tint * 0.14,
        1.0 - temp * 0.22 + tint * 0.08
    );
    return c * max(wb, vec3(0.25));
}

// ---------- 3-Way RGB Color Balance (Shadows / Midtones / Highlights) ----------
vec3 applyThreeWayRGB(vec3 c, vec3 shTint, vec3 midTint, vec3 hiTint) {
    float lum = saturate(getLuminance(c));
    float wShadow    = sqr(1.0 - smoothstep(0.0, 0.55, lum));
    float wHighlight = sqr(smoothstep(0.45, 1.0, lum));
    float wMidtone   = saturate(1.0 - wShadow - wHighlight);

    // Shadow lift/tint
    c *= mix(vec3(1.0), shTint, wShadow);
    // Midtone gamma/tint
    vec3 invMid = 1.0 / max(midTint, vec3(0.2));
    c = mix(c, pow(max(c, vec3(0.0)), invMid), wMidtone * 0.85);
    // Highlight gain/tint
    c *= mix(vec3(1.0), hiTint, wHighlight);
    return max(c, vec3(0.0));
}

// ---------- Saturation & Vibrance ----------
vec3 applySaturationVibrance(vec3 c, float sat, float vib) {
    float lum = getLuminance(c);
    float maxC = maxOf(c);
    float minC = minOf(c);
    float chroma = maxC - minC;
    // Vibrance boosts muted colors more than already saturated colors
    float vibFactor = 1.0 + vib * (1.0 - saturate(chroma * 1.35));
    float totalSat = max(0.0, sat * vibFactor);
    return max(mix(vec3(lum), c, totalSat), vec3(0.0));
}

// ---------- Complete Master Color Grading Pipeline ----------
vec3 applyMasterColorGrading(vec3 hdrColor, float autoExposureGain) {
    StylePostGrade style = getStylePostGrade();
    float styleStr = clamp(float(COLOR_STYLE_STRENGTH), 0.0, 1.5);

    // 1. Exposure (Manual EV + Smooth Auto-Exposure + Style exposure)
    float manualExp = exp2(float(EXPOSURE));
    float styleExp = mix(1.0, style.exposureMult, styleStr);
    vec3 c = max(hdrColor, vec3(0.0)) * manualExp * autoExposureGain * styleExp;

    // 2. White Balance (Temperature / Green-Magenta)
    c = applyWhiteBalance(c);

    // 3. Global RGB Tone Adjustment (User RGB channels!)
    vec3 userRGB = vec3(float(COLOR_TONE_R), float(COLOR_TONE_G), float(COLOR_TONE_B));
    c *= userRGB;

    // 4. Style Chromatic Matrix in Linear HDR space
    vec3 styledMatrixColor = max(style.colorMatrix * c, vec3(0.0));
    c = mix(c, styledMatrixColor, clamp(styleStr, 0.0, 1.0));
    if (styleStr > 1.0) {
        c = max(mix(c, styledMatrixColor, styleStr), vec3(0.0));
    }

    // 5. Tonemap HDR -> Linear Display [0, 1]
    c = applyTonemap(c);

    // 6. Apply Style Split-Toning (Shadow Lift / Midtone Gamma / Highlight Gain)
    vec3 styledC = c + style.shadowLift * (1.0 - c);
    styledC = max(styledC, vec3(0.0));
    styledC = applyThreeWayRGB(styledC, vec3(1.0), style.midtoneGamma, style.highlightGain);
    c = mix(c, styledC, clamp(styleStr, 0.0, 1.25));

    // 7. User 3-Way RGB Color Balance (Shadows / Midtones / Highlights)
    vec3 userSh  = vec3(float(SHADOW_TINT_R),    float(SHADOW_TINT_G),    float(SHADOW_TINT_B));
    vec3 userMid = vec3(float(MIDTONE_TINT_R),   float(MIDTONE_TINT_G),   float(MIDTONE_TINT_B));
    vec3 userHi  = vec3(float(HIGHLIGHT_TINT_R), float(HIGHLIGHT_TINT_G), float(HIGHLIGHT_TINT_B));
    c = applyThreeWayRGB(c, userSh, userMid, userHi);

    // 8. Brightness & Gamma
    c = max(c * float(BRIGHTNESS), vec3(0.0));
    c = pow(c, vec3(1.0 / max(float(GAMMA), 0.1)));

    // 9. Contrast (filmic midpoint pivot in display space)
    float totalContrast = float(CONTRAST) * mix(1.0, style.contrast, styleStr);
    vec3 srgb = linearToSrgb(saturate(c));
    srgb = saturate((srgb - 0.5) * totalContrast + 0.5);

    // 10. Saturation & Vibrance
    float totalSat = float(SATURATION) * mix(1.0, style.saturation, styleStr);
    float totalVib = float(VIBRANCE) + style.vibrance * styleStr;
    srgb = saturate(applySaturationVibrance(srgb, totalSat, totalVib));

    return srgb;
}

// ---------- Vignette, Film Grain & Triangular-PDF Anti-Banding Dither ----------
vec3 applyLensFinishing(vec3 srgb, vec2 uv, vec2 fragCoord, int frameCounter) {
    #ifdef VIGNETTE_ENABLED
        vec2 centered = (uv - 0.5) * vec2(1.15, 1.0);
        float dist = length(centered) * 1.41421356;
        float vig = smoothstep(float(VIGNETTE_RADIUS), float(VIGNETTE_RADIUS) + 0.65, dist);
        srgb *= 1.0 - vig * float(VIGNETTE_STRENGTH);
    #endif

    // Subtle analog film grain
    if (float(FILM_GRAIN) > 0.001) {
        float g1 = interleavedGradientNoiseTemporal(fragCoord, frameCounter);
        float g2 = interleavedGradientNoiseTemporal(fragCoord + vec2(17.3, 31.7), frameCounter + 7);
        float grain = (g1 + g2 - 1.0) * float(FILM_GRAIN) * 0.14;
        srgb = saturate(srgb + grain);
    }

    // Triangular-PDF 8-bit anti-banding dither
    float n1 = interleavedGradientNoiseTemporal(fragCoord, frameCounter);
    float n2 = interleavedGradientNoiseTemporal(fragCoord + vec2(37.1, 13.7), frameCounter);
    float dither = (n1 + n2 - 1.0) / 255.0;
    return saturate(srgb + dither);
}

#endif // LIB_COLOR_GRADING_GLSL
