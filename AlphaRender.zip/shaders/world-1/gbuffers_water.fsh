#version 330 compatibility
#define FRAGMENT_SHADER
#define NETHER
#define WATER_PASS
#include "/program/gbuffers_water.glsl"
