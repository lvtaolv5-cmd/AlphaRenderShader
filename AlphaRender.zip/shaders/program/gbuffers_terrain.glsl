#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/jitter.glsl"
#include "/lib/waving.glsl"
#include "/lib/lighting.glsl"

#ifdef VERTEX_SHADER

#ifdef TERRAIN_PASS
in vec3 mc_Entity;
in vec2 mc_midTexCoord;
#endif

uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform vec3 cameraPosition;
uniform vec3 shadowLightPosition;
uniform vec3 sunPosition;
uniform vec3 upPosition;
uniform float frameTimeCounter;
uniform float rainStrength;
uniform float viewWidth;
uniform float viewHeight;
uniform int frameCounter;
uniform int isEyeInWater;
uniform int heldBlockLightValue;
uniform int heldBlockLightValue2;

out vec2 vTexCoord;
out vec2 vLmCoordRaw;
out vec2 vLmCoord;
out vec4 vColor;
out vec3 vViewPos;
out vec3 vPlayerPos;
out vec3 vViewNormal;
out vec3 vWorldNormal;
flat out int vBlockId;

// Vertex-hoisted frame-constant lighting (eliminates per-pixel palette/day-factor ALU!)
flat out vec3 fShadowLightDir;
flat out vec3 fStyleSkyTint;
flat out vec3 fSunLightColor;
flat out vec3 fBlocklightTint;
flat out vec3 fAmbientDay;
flat out vec2 fDayHorizon;

void main() {
    vTexCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    vec2 lmRaw = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    vColor = gl_Color;

    #ifdef TERRAIN_PASS
        vBlockId = int(mc_Entity.x + 0.5);
    #else
        vBlockId = 0;
    #endif

    vec4 viewPos = gl_ModelViewMatrix * gl_Vertex;
    vec3 playerPos = (gbufferModelViewInverse * viewPos).xyz;

    #ifdef TERRAIN_PASS
        if (vBlockId >= 10001 && vBlockId <= 10004) {
            vec2 uvMidOffset = vTexCoord - mc_midTexCoord;
            vec3 wave = computeWavingOffset(playerPos + cameraPosition, vBlockId, uvMidOffset, frameTimeCounter, rainStrength);
            playerPos += wave;
            viewPos = gbufferModelView * vec4(playerPos, 1.0);
        }
    #endif

    #ifdef DYNAMIC_HANDLIGHT
        float heldVal = max(float(heldBlockLightValue), float(heldBlockLightValue2));
        if (heldVal > 0.5 && isEyeInWater != 1 && isEyeInWater != 2) {
            float handLevel = max(heldVal - 1.0 - length(viewPos.xyz), 0.0) / 15.0;
            lmRaw.x = max(lmRaw.x, handLevel * 0.9375 + 0.03125);
        }
    #endif

    vLmCoordRaw = clamp(lmRaw, vec2(0.03125), vec2(0.96875));
    vLmCoord = saturate((lmRaw - 0.03125) / 0.9375);

    vViewPos = viewPos.xyz;
    vPlayerPos = playerPos;
    vViewNormal = safeNormalize(gl_NormalMatrix * gl_Normal);
    vWorldNormal = safeNormalize(mat3(gbufferModelViewInverse) * vViewNormal);

    // Precompute frame lighting once per vertex!
    VertexLightData ld = precomputeVertexLightData(shadowLightPosition, sunPosition, upPosition, rainStrength);
    fShadowLightDir = ld.shadowLightDir;
    fStyleSkyTint   = ld.styleSkyTint;
    fSunLightColor  = ld.sunLightColor;
    fBlocklightTint = ld.blocklightTint;
    fAmbientDay     = ld.ambientDay;
    fDayHorizon     = vec2(ld.dayFactor, ld.horizonFade);

    gl_Position = gl_ProjectionMatrix * viewPos;

    #ifndef HAND_PASS
        gl_Position.xy += getClipJitterOffset(frameCounter, viewWidth, viewHeight) * gl_Position.w;
    #endif
}

#endif // VERTEX_SHADER

#ifdef FRAGMENT_SHADER

#include "/lib/shadows.glsl"

uniform sampler2D tex;
uniform sampler2D lightmap;
uniform sampler2D shadowtex0;
uniform sampler2D shadowtex1;
uniform sampler2D shadowcolor0;

uniform mat4 shadowModelView;
uniform mat4 shadowProjection;
uniform vec3 cameraPosition;
uniform ivec2 eyeBrightnessSmooth;
uniform float rainStrength;
uniform float wetness;
uniform float alphaTestRef;
uniform int frameCounter;

#if defined(ENTITIES_PASS) || defined(ENTITIES_GLOWING_PASS)
uniform vec4 entityColor;
uniform int entityId;
#endif

in vec2 vTexCoord;
in vec2 vLmCoordRaw;
in vec2 vLmCoord;
in vec4 vColor;
in vec3 vViewPos;
in vec3 vPlayerPos;
in vec3 vViewNormal;
in vec3 vWorldNormal;
flat in int vBlockId;

flat in vec3 fShadowLightDir;
flat in vec3 fStyleSkyTint;
flat in vec3 fSunLightColor;
flat in vec3 fBlocklightTint;
flat in vec3 fAmbientDay;
flat in vec2 fDayHorizon;

/* RENDERTARGETS:0,1,2 */
layout(location = 0) out vec4 outColor;
layout(location = 1) out vec4 outNormalMat;
layout(location = 2) out vec4 outEmissive;

void main() {
    vec4 texSample = texture(tex, vTexCoord);

    #if defined(ARMOR_GLINT_PASS)
        vec4 combined = texSample * vColor;
        if (combined.a < 0.01) discard;
        vec3 glintLin = srgbToLinear(combined.rgb) * 1.45;
        outColor = vec4(glintLin, combined.a);
        outNormalMat = vec4(encodeNormal(vViewNormal), MAT_TRANS, 0.5);
        outEmissive = vec4(saturate(glintLin * 0.12), 0.5);
    #elif defined(SPIDEREYES_PASS)
        vec4 combined = texSample * vColor;
        if (combined.a < 0.01) discard;
        vec3 eyeLin = srgbToLinear(combined.rgb) * 1.85 * float(EMISSIVE_STRENGTH);
        outColor = vec4(eyeLin, combined.a);
        outNormalMat = vec4(encodeNormal(vViewNormal), MAT_SOLID, 1.0);
        outEmissive = vec4(saturate(eyeLin * 0.25), 0.5);
    #elif defined(BEACON_PASS)
        vec4 combined = texSample * vColor;
        if (combined.a < 0.01) discard;
        vec3 beamLin = srgbToLinear(combined.rgb) * 2.4 * float(EMISSIVE_STRENGTH);
        outColor = vec4(beamLin, combined.a);
        outNormalMat = vec4(encodeNormal(vViewNormal), MAT_TRANS, 1.0);
        outEmissive = vec4(saturate(beamLin * 0.25), 0.5);
    #elif defined(DAMAGED_PASS)
        vec4 combined = texSample * vColor;
        if (combined.a < 0.01) discard;
        outColor = vec4(srgbToLinear(combined.rgb), combined.a);
        outNormalMat = vec4(encodeNormal(vViewNormal), MAT_SOLID, vLmCoord.y);
        outEmissive = vec4(0.0);
    #else
        #ifdef TERRAIN_PASS
            if (texSample.a < max(alphaTestRef, 0.1)) discard;
            vec3 albedoSrgb = texSample.rgb * vColor.rgb;
            float outAlpha = 1.0;
            float ao = mix(1.0, saturate(vColor.a), ambientOcclusionLevel);
        #else
            vec4 combined = texSample * vColor;
            float alphaCut = alphaTestRef > 0.001 ? alphaTestRef : 0.01;
            #if defined(PARTICLES_PASS) || defined(TEXTURED_PASS)
                alphaCut = 0.004;
            #endif
            if (combined.a < alphaCut) discard;
            vec3 albedoSrgb = combined.rgb;
            float outAlpha = combined.a;
            float ao = 1.0;
        #endif

        vec3 vanillaLightmapLin = srgbToLinear(texture(lightmap, vLmCoordRaw).rgb);

        #if defined(ENTITIES_PASS) || defined(ENTITIES_GLOWING_PASS)
            albedoSrgb = mix(albedoSrgb, entityColor.rgb, entityColor.a);
            if (entityId == 11000) {
                vec3 boltLin = vec3(1.8, 2.1, 3.2) * float(EMISSIVE_STRENGTH);
                outColor = vec4(boltLin, outAlpha);
                outNormalMat = vec4(encodeNormal(vViewNormal), MAT_TRANS, 1.0);
                outEmissive = vec4(saturate(boltLin * 0.25), 0.5);
                return;
            }
        #endif

        vec3 linearAlbedo = srgbToLinear(albedoSrgb);

        #if defined(TEXTURED_PASS) || defined(ENTITIES_PASS)
            if (outAlpha < 0.92 && maxOf(albedoSrgb) < 0.06) {
                outColor = vec4(linearAlbedo, outAlpha);
                outNormalMat = vec4(encodeNormal(vViewNormal), MAT_TRANS, vLmCoord.y);
                outEmissive = vec4(0.0);
                return;
            }
        #endif

        vec3 vNorm = safeNormalize(vViewNormal);
        vec3 wNorm = safeNormalize(vWorldNormal);

        bool isFoliage = false;
        #ifdef TERRAIN_PASS
            isFoliage = (vBlockId >= 10001 && vBlockId <= 10004);
        #endif

        if (!gl_FrontFacing && isFoliage) {
            vNorm = -vNorm;
            wNorm = -wNorm;
        }

        // Exact 1:1 Forced Pixel-Locked Real-Time Shadows (Terrain, Entities & Block Entities!)
        vec3 shadowVis = vec3(1.0);
        #if !defined(HAND_PASS) && !defined(PARTICLES_PASS) && !defined(TEXTURED_PASS)
            float NdotL = isFoliage ? 0.72 : max(dot(vNorm, fShadowLightDir), 0.0);
            if (vLmCoord.y > 0.02) {
                shadowVis = sampleShadows(
                    vPlayerPos, cameraPosition, wNorm, NdotL, isFoliage,
                    gl_FragCoord.xy, frameCounter,
                    shadowModelView, shadowProjection, shadowtex0, shadowtex1, shadowcolor0
                );
            } else {
                shadowVis = vec3(0.0);
            }
        #endif

        vec3 specBloom = vec3(0.0);
        vec3 litColor = computeHybridSurfaceLightingFast(
            linearAlbedo, vanillaLightmapLin, vNorm, wNorm, vViewPos,
            vLmCoord, ao, shadowVis, isFoliage,
            fShadowLightDir, fStyleSkyTint, fSunLightColor, fBlocklightTint, fAmbientDay,
            fDayHorizon.x, fDayHorizon.y,
            rainStrength, wetness, eyeBrightnessSmooth.y, specBloom
        );

        vec3 emissiveCol = vec3(0.0);
        #ifdef TERRAIN_PASS
            emissiveCol = computeBlockEmissive(linearAlbedo, vBlockId, vLmCoord);
        #elif defined(ENTITIES_GLOWING_PASS)
            emissiveCol = linearAlbedo * 1.5 * float(EMISSIVE_STRENGTH);
        #elif defined(PARTICLES_PASS)
            if (vLmCoord.x > 0.85 && maxOf(linearAlbedo) > 0.35) {
                emissiveCol = linearAlbedo * 0.9 * float(EMISSIVE_STRENGTH);
            }
        #endif

        litColor += emissiveCol;
        vec3 totalBloomTarget = emissiveCol + specBloom;

        float matId = MAT_SOLID;
        #ifdef HAND_PASS
            matId = MAT_HAND;
        #elif defined(TERRAIN_PASS)
            if (isFoliage) matId = MAT_FOLIAGE;
        #elif defined(PARTICLES_PASS) || defined(TEXTURED_PASS)
            matId = MAT_TRANS;
        #endif

        outColor = vec4(sanitizeHDR(litColor), outAlpha);
        outNormalMat = vec4(encodeNormal(vNorm), matId, vLmCoord.y);
        outEmissive = vec4(saturate(sanitizeHDR(totalBloomTarget) * 0.25), maxOf(totalBloomTarget) > 0.05 ? 0.5 : 0.0);
    #endif
}

#endif // FRAGMENT_SHADER
