#version 330 compatibility
#define FRAGMENT_SHADER
#define END
#define ENTITIES_GLOWING_PASS
#include "/program/gbuffers_terrain.glsl"
