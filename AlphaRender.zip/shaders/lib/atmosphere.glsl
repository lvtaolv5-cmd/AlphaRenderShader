#ifndef LIB_ATMOSPHERE_GLSL
#define LIB_ATMOSPHERE_GLSL

#include "/lib/colorStyles.glsl"

// Compute stylized Rayleigh/Mie atmospheric sky color for any view direction
vec3 computeSkyColor(
    vec3 viewDir,
    vec3 sunDirView,
    vec3 upDirView,
    float rainStrength,
    vec3 vanillaFogColor
) {
    StyleLightingPalette pal = getStyleLightingPalette();
    vec3 vDir = safeNormalize(viewDir);
    vec3 uDir = safeNormalize(upDirView);
    float upDot = dot(vDir, uDir);

    #ifdef NETHER
        vec3 base = srgbToLinear(vanillaFogColor) * 0.85 + vec3(0.14, 0.035, 0.018);
        float glow = exp(-abs(upDot) * 3.5);
        return (base + vec3(0.18, 0.05, 0.015) * glow) * float(SKY_INTENSITY);
    #elif defined(END)
        vec3 zenith = vec3(0.018, 0.010, 0.036);
        vec3 horizon = vec3(0.085, 0.045, 0.145);
        float band = pow(1.0 - saturate(abs(upDot)), 3.2);
        return mix(zenith, horizon, band) * float(SKY_INTENSITY);
    #else
        float dayFactor, sunsetFactor, nightFactor;
        getDayFactors(sunDirView, upDirView, dayFactor, sunsetFactor, nightFactor);

        vec3 zenith  = mix(pal.skyZenithNight,  pal.skyZenithDay,  dayFactor);
        vec3 horizon = mix(pal.skyHorizonNight, pal.skyHorizonDay, dayFactor);

        // Warm golden-rose horizon scatter at sunrise / sunset
        vec3 sunsetHorizon = pal.sunSunset * vec3(0.95, 0.72, 0.62);
        horizon = mix(horizon, sunsetHorizon, sunsetFactor * 0.78);
        zenith  = mix(zenith,  zenith * vec3(1.05, 0.78, 0.88), sunsetFactor * 0.45);

        // Rain clouds overcast softening
        float rainLuma = getLuminance(horizon) * 0.58 + 0.04;
        vec3 rainSky = vec3(rainLuma * 0.90, rainLuma * 0.95, rainLuma * 1.05);
        zenith  = mix(zenith,  rainSky * 0.72, rainStrength * 0.80);
        horizon = mix(horizon, rainSky * 0.95, rainStrength * 0.80);

        float horizonGrad = pow(1.0 - saturate(upDot), 3.4);
        vec3 sky = mix(zenith, horizon, horizonGrad);

        // Mie forward scattering halo around sun & moon
        vec3 sDir = safeNormalize(sunDirView);
        float sunCos = max(dot(vDir, sDir), 0.0);
        float mieWide = pow(sunCos, 6.0) * 0.28 + pow(sunCos, 48.0) * 0.65;
        vec3 mieCol = mix(pal.sunDay, pal.sunSunset, sunsetFactor);
        sky += mieCol * mieWide * dayFactor * (1.0 - rainStrength * 0.85) * 0.85;

        float moonCos = max(dot(vDir, -sDir), 0.0);
        float moonHalo = pow(moonCos, 16.0) * 0.14 + pow(moonCos, 96.0) * 0.25;
        sky += pal.moonColor * moonHalo * nightFactor * (1.0 - rainStrength * 0.80);

        // Subtle ground-hemisphere fade below horizon
        if (upDot < 0.0) {
            sky = mix(sky, horizon * 0.55, saturate(-upDot * 2.5));
        }

        return max(sky, vec3(0.0)) * float(SKY_INTENSITY);
    #endif
}

// Distance + Height atmospheric fog
vec3 applyAtmosphericFog(
    vec3 sceneColor,
    vec3 viewPos,
    vec3 playerPos,
    vec3 sunDirView,
    vec3 upDirView,
    float farPlane,
    float rainStrength,
    int isEyeInWater,
    vec3 vanillaFogColor
) {
    #ifndef FOG_ENABLED
        return sceneColor;
    #else
        float dist = length(viewPos);
        vec3 viewDir = viewPos / max(dist, 1e-4);

        if (isEyeInWater == 1) {
            // Underwater color absorption & turquoise depth fog
            StyleLightingPalette pal = getStyleLightingPalette();
            float waterFog = 1.0 - exp(-dist * 0.065 * float(WATER_ABSORPTION));
            vec3 uwColor = pal.waterTint * 0.55 + vec3(0.02, 0.09, 0.14);
            return mix(sceneColor, uwColor, saturate(waterFog));
        } else if (isEyeInWater == 2) {
            float lavaFog = 1.0 - exp(-dist * 0.45);
            return mix(sceneColor, vec3(1.1, 0.26, 0.04), saturate(lavaFog));
        }

        vec3 fogColor = computeSkyColor(viewDir, sunDirView, upDirView, rainStrength, vanillaFogColor);

        #ifdef NETHER
            float density = 0.011 * float(FOG_DENSITY);
            float f = 1.0 - exp(-dist * density);
            f = max(f, smoothstep(farPlane * 0.55, farPlane * 1.02, dist));
            return mix(sceneColor, fogColor, saturate(f));
        #elif defined(END)
            float density = 0.0055 * float(FOG_DENSITY);
            float f = 1.0 - exp(-dist * density);
            f = max(f, smoothstep(farPlane * 0.65, farPlane * 1.05, dist));
            return mix(sceneColor, fogColor, saturate(f));
        #else
            float baseDensity = (0.0022 + rainStrength * 0.0055) * float(FOG_DENSITY);
            float distFog = 1.0 - exp(-sqr(dist * baseDensity * 1.8));
            float borderFog = smoothstep(farPlane * 0.72, farPlane * 1.03, dist);

            // Soft low-altitude morning/valley height mist
            float heightFactor = exp(-max(playerPos.y + 8.0, 0.0) * 0.045) * float(HEIGHT_FOG);
            float hFog = (1.0 - exp(-dist * 0.0045 * heightFactor)) * 0.55;

            float totalFog = saturate(max(borderFog, distFog + hFog * (1.0 - distFog)));
            return mix(sceneColor, fogColor, totalFog);
        #endif
    #endif
}

// Screen-space radial volumetric light shafts (Godrays)
vec3 computeLightShafts(
    vec2 uv,
    vec2 fragCoord,
    int frameCounter,
    vec3 sunDirView,
    vec3 moonDirView,
    vec3 upDirView,
    mat4 proj,
    float rainStrength,
    sampler2D depthTex
) {
    #ifdef LIGHT_SHAFTS_ENABLED
    #if !defined(NETHER) && !defined(END)
        float dayFactor, sunsetFactor, nightFactor;
        getDayFactors(sunDirView, upDirView, dayFactor, sunsetFactor, nightFactor);

        vec3 lightDir = dayFactor >= 0.05 ? safeNormalize(sunDirView) : safeNormalize(moonDirView);
        // Light must be roughly in front of the camera (-Z in view space)
        float forwardDot = -lightDir.z;
        if (forwardDot <= 0.05) return vec3(0.0);

        vec4 lightClip = proj * vec4(lightDir * 100.0, 1.0);
        if (lightClip.w <= 0.0) return vec3(0.0);
        vec2 lightUV = (lightClip.xy / lightClip.w) * 0.5 + 0.5;

        // Smooth fade if sun goes far offscreen
        vec2 edgeDist = abs(lightUV - 0.5) - 0.5;
        float onScreen = 1.0 - smoothstep(0.0, 0.75, max(edgeDist.x, edgeDist.y));
        if (onScreen <= 0.001) return vec3(0.0);

        // Early radial cull BEFORE raymarch loop (~65% faster godrays!)
        float radialAtten = exp(-length((uv - lightUV) * vec2(1.4, 1.0)) * 2.1);
        float intensity = float(LIGHT_SHAFTS_STRENGTH) * (1.0 - rainStrength * 0.85) * onScreen * radialAtten;
        if (intensity <= 0.008) return vec3(0.0);

        #if LIGHT_SHAFTS_QUALITY == 1
            const int SHAFT_STEPS = 8;
        #elif LIGHT_SHAFTS_QUALITY == 2
            const int SHAFT_STEPS = 14;
        #else
            const int SHAFT_STEPS = 22;
        #endif

        vec2 delta = (lightUV - uv) / float(SHAFT_STEPS);
        float maxStep = 0.042;
        float dLen = length(delta);
        if (dLen > maxStep) delta *= (maxStep / dLen);

        float dither = interleavedGradientNoiseTemporal(fragCoord, frameCounter);
        vec2 sampleUV = uv + delta * dither;

        float illum = 0.0;
        float decay = 1.0;
        for (int i = 0; i < SHAFT_STEPS; i++) {
            vec2 clampedUV = clamp(sampleUV, vec2(0.001), vec2(0.999));
            float d = texture(depthTex, clampedUV).r;
            float skyVis = step(0.99985, d);
            illum += skyVis * decay;
            decay *= 0.915;
            sampleUV += delta;
        }
        illum /= float(SHAFT_STEPS);

        StyleLightingPalette pal = getStyleLightingPalette();
        vec3 shaftColor = dayFactor >= 0.05
            ? mix(pal.sunSunset, pal.sunDay, smoothstep(0.05, 0.45, dayFactor)) * dayFactor
            : pal.moonColor * nightFactor * 0.35;

        return shaftColor * illum * intensity * 0.82;
    #else
        return vec3(0.0);
    #endif
    #else
        return vec3(0.0);
    #endif
}

#endif // LIB_ATMOSPHERE_GLSL
