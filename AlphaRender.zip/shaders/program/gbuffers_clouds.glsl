#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/jitter.glsl"

#ifdef VERTEX_SHADER

uniform float viewWidth;
uniform float viewHeight;
uniform int frameCounter;

out vec2 vTexCoord;
out vec4 vColor;
out vec3 vViewPos;
out vec3 vNormal;

void main() {
    vTexCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    vColor = gl_Color;
    vec4 viewPos = gl_ModelViewMatrix * gl_Vertex;
    vViewPos = viewPos.xyz;
    vNormal = safeNormalize(gl_NormalMatrix * gl_Normal);

    gl_Position = gl_ProjectionMatrix * viewPos;
    gl_Position.xy += getClipJitterOffset(frameCounter, viewWidth, viewHeight) * gl_Position.w;
}

#endif // VERTEX_SHADER

#ifdef FRAGMENT_SHADER

#include "/lib/atmosphere.glsl"

uniform sampler2D tex;
uniform vec3 sunPosition;
uniform vec3 upPosition;
uniform vec3 fogColor;
uniform float rainStrength;
uniform float far;

in vec2 vTexCoord;
in vec4 vColor;
in vec3 vViewPos;
in vec3 vNormal;

/* RENDERTARGETS:0,1,2 */
layout(location = 0) out vec4 outColor;
layout(location = 1) out vec4 outNormalMat;
layout(location = 2) out vec4 outEmissive;

void main() {
    vec4 raw = texture(tex, vTexCoord) * vColor;
    if (raw.a < 0.05) discard;

    StyleLightingPalette pal = getStyleLightingPalette();
    float dayFactor, sunsetFactor, nightFactor;
    getDayFactors(sunPosition, upPosition, dayFactor, sunsetFactor, nightFactor);

    vec3 sunCol = mix(pal.sunSunset, pal.sunDay, smoothstep(0.05, 0.45, dayFactor));
    vec3 cloudLit = mix(pal.ambientNight * 0.9, sunCol * 0.92 + pal.ambientDay * 0.35, dayFactor);
    cloudLit = mix(cloudLit, vec3(getLuminance(cloudLit) * 0.55), rainStrength * 0.72);

    float NdotU = dot(safeNormalize(vNormal), safeNormalize(upPosition));
    float shade = mix(0.68, 1.05, NdotU * 0.5 + 0.5);
    vec3 col = srgbToLinear(raw.rgb) * cloudLit * shade * float(SKY_INTENSITY);

    // Soft distance horizon fade
    float dist = length(vViewPos);
    float fade = 1.0 - smoothstep(far * 0.45, far * 1.35, dist);
    vec3 skyCol = computeSkyColor(vViewPos, sunPosition, upPosition, rainStrength, fogColor);
    col = mix(skyCol, col, fade);

    outColor = vec4(col, raw.a * fade * 0.88);
    outNormalMat = vec4(encodeNormal(vNormal), MAT_SKY, 1.0);
    outEmissive = vec4(0.0);
}

#endif // FRAGMENT_SHADER
