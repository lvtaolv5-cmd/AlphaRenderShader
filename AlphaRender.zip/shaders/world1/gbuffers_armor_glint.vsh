#version 330 compatibility
#define VERTEX_SHADER
#define END
#define ARMOR_GLINT_PASS
#include "/program/gbuffers_terrain.glsl"
