#include "/lib/settings.glsl"
#include "/lib/common.glsl"

#ifdef VERTEX_SHADER

out vec2 vTexCoord;

void main() {
    vTexCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    gl_Position = ftransform();
}

#endif // VERTEX_SHADER

#ifdef FRAGMENT_SHADER

#include "/lib/bloomGlare.glsl"

uniform sampler2D colortex0;
uniform sampler2D colortex2;
uniform sampler2D colortex3;
uniform float viewWidth;
uniform float viewHeight;

in vec2 vTexCoord;

// TRUE HARDWARE 0.5x0.5 HALF-RES RENDER PASS (colortex6 & colortex4 = 4x fewer pixels rasterized!)
/* RENDERTARGETS:6,4 */
layout(location = 0) out vec4 outBloomAtlasH;
layout(location = 1) out vec4 outGlarePass1;

void main() {
    vec2 fullTexelSize = 1.0 / max(vec2(viewWidth, viewHeight), vec2(1.0));

    // Pass 1: Downsample full-res colortex3 -> 0.5x0.5 5-Octave Bloom Atlas + H-Blur
    vec3 bloomH = computeBloomTilePass1(vTexCoord, fullTexelSize, colortex3);

    // Pass 1: Extract & Pre-gather Half-Res Optical Glare (includes !Black Selection Box!)
    vec3 glare1 = computeGlarePass1(vTexCoord, fullTexelSize, colortex0, colortex2);

    outBloomAtlasH = vec4(sanitizeHDR(bloomH), 1.0);
    outGlarePass1  = vec4(sanitizeHDR(glare1), 1.0);
}

#endif // FRAGMENT_SHADER
