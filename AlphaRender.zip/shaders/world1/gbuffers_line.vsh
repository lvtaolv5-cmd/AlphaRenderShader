#version 330 compatibility
#define VERTEX_SHADER
#define END
#include "/program/gbuffers_line.glsl"
