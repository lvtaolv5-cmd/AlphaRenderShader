#version 330 compatibility
#define VERTEX_SHADER
#define NETHER
#define ENTITIES_PASS
#include "/program/gbuffers_terrain.glsl"
