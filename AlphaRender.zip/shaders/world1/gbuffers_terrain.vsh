#version 330 compatibility
#define VERTEX_SHADER
#define END
#define TERRAIN_PASS
#include "/program/gbuffers_terrain.glsl"
