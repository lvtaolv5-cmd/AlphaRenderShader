#include "/lib/settings.glsl"
#include "/lib/common.glsl"

#ifdef VERTEX_SHADER

out vec2 vTexCoord;
out vec2 vLmCoordRaw;
out vec4 vColor;

void main() {
    vTexCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    vec2 lmRaw = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    vLmCoordRaw = clamp(lmRaw, vec2(0.03125), vec2(0.96875));
    vColor = gl_Color;
    gl_Position = ftransform();
}

#endif // VERTEX_SHADER

#ifdef FRAGMENT_SHADER

uniform sampler2D tex;
uniform sampler2D lightmap;

in vec2 vTexCoord;
in vec2 vLmCoordRaw;
in vec4 vColor;

/* RENDERTARGETS:0 */
layout(location = 0) out vec4 outColor;

void main() {
    vec4 raw = texture(tex, vTexCoord) * vColor;
    if (raw.a < 0.05) discard;

    vec3 lm = srgbToLinear(texture(lightmap, vLmCoordRaw).rgb);
    vec3 col = srgbToLinear(raw.rgb) * lm;

    outColor = vec4(sanitizeHDR(col), raw.a * 0.62);
}

#endif // FRAGMENT_SHADER
