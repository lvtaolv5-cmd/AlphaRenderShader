#ifndef LIB_COLOR_STYLES_GLSL
#define LIB_COLOR_STYLES_GLSL

/* ============================================================================
   AlphaRender - 12 Signature Color Palette Styles
   Includes:
     0: Classic Color
     1: Nostalgia Color
     2: Legecy Color
     3: Vanilla Enhanced
     4: Cinematic Filmic
     5: Vibrant Fantasy
     6: Nordic Cold
     7: Golden Hour
     8: Pastel Dream
     9: Dark Moody
    10: Cyber Neon
    11: Retro Warm Film
   ============================================================================ */

struct StyleLightingPalette {
    vec3 sunDay;
    vec3 sunSunset;
    vec3 moonColor;
    vec3 ambientDay;
    vec3 ambientNight;
    vec3 skyZenithDay;
    vec3 skyHorizonDay;
    vec3 skyZenithNight;
    vec3 skyHorizonNight;
    vec3 fogDayTint;
    vec3 blocklightTint;
    vec3 waterTint;
};

struct StylePostGrade {
    mat3 colorMatrix;
    vec3 shadowLift;     // additive lift in linear darks
    vec3 midtoneGamma;   // power curve tint in midtones
    vec3 highlightGain;  // highlight multiplier tint
    float saturation;
    float vibrance;
    float contrast;
    float exposureMult;
};

StyleLightingPalette getStyleLightingPalette() {
    StyleLightingPalette p;

    // Baseline Classic Color defaults
    p.sunDay          = vec3(1.05, 0.98, 0.88);
    p.sunSunset       = vec3(1.25, 0.62, 0.28);
    p.moonColor       = vec3(0.55, 0.70, 1.05);
    p.ambientDay      = vec3(0.46, 0.60, 0.86);
    p.ambientNight    = vec3(0.14, 0.21, 0.38);
    p.skyZenithDay    = vec3(0.14, 0.36, 0.84);
    p.skyHorizonDay   = vec3(0.62, 0.80, 0.98);
    p.skyZenithNight  = vec3(0.015, 0.025, 0.065);
    p.skyHorizonNight = vec3(0.045, 0.075, 0.145);
    p.fogDayTint      = vec3(0.68, 0.82, 0.98);
    p.blocklightTint  = vec3(1.05, 0.72, 0.42);
    p.waterTint       = vec3(0.12, 0.44, 0.56);

    #if COLOR_STYLE == 0
        // 0: Classic Color — Crisp, iconic balanced Minecraft shader look
        // (uses clean baseline above)
    #elif COLOR_STYLE == 1
        // 1: Nostalgia Color — Warm amber sunlit nostalgia, soft hazy cerulean sky, dreamy vintage air
        p.sunDay          = vec3(1.12, 0.96, 0.78);
        p.sunSunset       = vec3(1.32, 0.68, 0.30);
        p.moonColor       = vec3(0.62, 0.74, 0.92);
        p.ambientDay      = vec3(0.52, 0.60, 0.74);
        p.ambientNight    = vec3(0.18, 0.22, 0.32);
        p.skyZenithDay    = vec3(0.22, 0.44, 0.78);
        p.skyHorizonDay   = vec3(0.80, 0.84, 0.88);
        p.skyZenithNight  = vec3(0.025, 0.032, 0.060);
        p.skyHorizonNight = vec3(0.080, 0.095, 0.140);
        p.fogDayTint      = vec3(0.84, 0.83, 0.80);
        p.blocklightTint  = vec3(1.15, 0.76, 0.38);
        p.waterTint       = vec3(0.18, 0.46, 0.52);
    #elif COLOR_STYLE == 2
        // 2: Legecy Color — Classic early-era punchy SEUS/Sildur legacy shader palette
        p.sunDay          = vec3(1.16, 1.00, 0.80);
        p.sunSunset       = vec3(1.40, 0.52, 0.18);
        p.moonColor       = vec3(0.45, 0.64, 1.12);
        p.ambientDay      = vec3(0.38, 0.54, 0.88);
        p.ambientNight    = vec3(0.11, 0.18, 0.36);
        p.skyZenithDay    = vec3(0.09, 0.30, 0.88);
        p.skyHorizonDay   = vec3(0.56, 0.78, 1.00);
        p.skyZenithNight  = vec3(0.010, 0.020, 0.075);
        p.skyHorizonNight = vec3(0.038, 0.068, 0.165);
        p.fogDayTint      = vec3(0.62, 0.79, 0.99);
        p.blocklightTint  = vec3(1.22, 0.64, 0.25);
        p.waterTint       = vec3(0.08, 0.38, 0.58);
    #elif COLOR_STYLE == 3
        // 3: Vanilla Enhanced — True-to-Mojang neutral daylight & sky
        p.sunDay          = vec3(1.00, 0.99, 0.97);
        p.sunSunset       = vec3(1.15, 0.68, 0.42);
        p.moonColor       = vec3(0.66, 0.74, 0.92);
        p.ambientDay      = vec3(0.54, 0.64, 0.80);
        p.ambientNight    = vec3(0.18, 0.22, 0.32);
        p.skyZenithDay    = vec3(0.24, 0.47, 0.92);
        p.skyHorizonDay   = vec3(0.68, 0.82, 0.98);
        p.skyZenithNight  = vec3(0.020, 0.028, 0.055);
        p.skyHorizonNight = vec3(0.055, 0.075, 0.125);
        p.fogDayTint      = vec3(0.72, 0.84, 0.98);
        p.blocklightTint  = vec3(1.02, 0.78, 0.52);
        p.waterTint       = vec3(0.16, 0.42, 0.68);
    #elif COLOR_STYLE == 4
        // 4: Cinematic Filmic — Teal & orange theatrical split-tone
        p.sunDay          = vec3(1.14, 0.94, 0.76);
        p.sunSunset       = vec3(1.36, 0.58, 0.26);
        p.moonColor       = vec3(0.42, 0.74, 0.94);
        p.ambientDay      = vec3(0.36, 0.58, 0.72);
        p.ambientNight    = vec3(0.10, 0.22, 0.30);
        p.skyZenithDay    = vec3(0.11, 0.34, 0.56);
        p.skyHorizonDay   = vec3(0.66, 0.78, 0.80);
        p.skyZenithNight  = vec3(0.012, 0.032, 0.050);
        p.skyHorizonNight = vec3(0.042, 0.088, 0.115);
        p.fogDayTint      = vec3(0.64, 0.76, 0.78);
        p.blocklightTint  = vec3(1.18, 0.68, 0.32);
        p.waterTint       = vec3(0.08, 0.44, 0.48);
    #elif COLOR_STYLE == 5
        // 5: Vibrant Fantasy — Radiant turquoise sky, golden sunbeams, luminous foliage
        p.sunDay          = vec3(1.15, 1.03, 0.82);
        p.sunSunset       = vec3(1.42, 0.58, 0.40);
        p.moonColor       = vec3(0.66, 0.58, 1.15);
        p.ambientDay      = vec3(0.44, 0.68, 0.92);
        p.ambientNight    = vec3(0.20, 0.18, 0.46);
        p.skyZenithDay    = vec3(0.08, 0.44, 0.96);
        p.skyHorizonDay   = vec3(0.56, 0.90, 1.00);
        p.skyZenithNight  = vec3(0.035, 0.020, 0.110);
        p.skyHorizonNight = vec3(0.095, 0.065, 0.220);
        p.fogDayTint      = vec3(0.62, 0.88, 1.00);
        p.blocklightTint  = vec3(1.18, 0.74, 0.34);
        p.waterTint       = vec3(0.06, 0.56, 0.68);
    #elif COLOR_STYLE == 6
        // 6: Nordic Cold — Crisp Arctic blue daylight, frosted atmosphere, cozy firelight
        p.sunDay          = vec3(0.92, 0.98, 1.12);
        p.sunSunset       = vec3(1.08, 0.72, 0.62);
        p.moonColor       = vec3(0.56, 0.80, 1.15);
        p.ambientDay      = vec3(0.46, 0.64, 0.88);
        p.ambientNight    = vec3(0.12, 0.22, 0.36);
        p.skyZenithDay    = vec3(0.18, 0.38, 0.68);
        p.skyHorizonDay   = vec3(0.74, 0.85, 0.95);
        p.skyZenithNight  = vec3(0.015, 0.032, 0.068);
        p.skyHorizonNight = vec3(0.055, 0.095, 0.155);
        p.fogDayTint      = vec3(0.76, 0.86, 0.94);
        p.blocklightTint  = vec3(1.22, 0.70, 0.32);
        p.waterTint       = vec3(0.12, 0.36, 0.54);
    #elif COLOR_STYLE == 7
        // 7: Golden Hour — Perpetual honey-amber sunshine and rosy-warm haze
        p.sunDay          = vec3(1.28, 0.88, 0.54);
        p.sunSunset       = vec3(1.45, 0.54, 0.22);
        p.moonColor       = vec3(0.78, 0.70, 0.96);
        p.ambientDay      = vec3(0.62, 0.54, 0.66);
        p.ambientNight    = vec3(0.20, 0.17, 0.30);
        p.skyZenithDay    = vec3(0.28, 0.38, 0.70);
        p.skyHorizonDay   = vec3(0.96, 0.76, 0.58);
        p.skyZenithNight  = vec3(0.030, 0.022, 0.058);
        p.skyHorizonNight = vec3(0.120, 0.075, 0.105);
        p.fogDayTint      = vec3(0.95, 0.78, 0.62);
        p.blocklightTint  = vec3(1.20, 0.76, 0.36);
        p.waterTint       = vec3(0.24, 0.44, 0.52);
    #elif COLOR_STYLE == 8
        // 8: Pastel Dream — Soft airy anime sky, creamy highlights, powdery tints
        p.sunDay          = vec3(1.08, 1.00, 0.94);
        p.sunSunset       = vec3(1.25, 0.76, 0.70);
        p.moonColor       = vec3(0.76, 0.80, 1.08);
        p.ambientDay      = vec3(0.64, 0.72, 0.90);
        p.ambientNight    = vec3(0.26, 0.28, 0.44);
        p.skyZenithDay    = vec3(0.32, 0.58, 0.94);
        p.skyHorizonDay   = vec3(0.88, 0.86, 0.96);
        p.skyZenithNight  = vec3(0.045, 0.050, 0.110);
        p.skyHorizonNight = vec3(0.145, 0.140, 0.230);
        p.fogDayTint      = vec3(0.88, 0.88, 0.96);
        p.blocklightTint  = vec3(1.08, 0.82, 0.58);
        p.waterTint       = vec3(0.26, 0.62, 0.74);
    #elif COLOR_STYLE == 9
        // 9: Dark Moody — Atmospheric gothic drama, deep slate shadows, piercing light
        p.sunDay          = vec3(0.96, 0.92, 0.86);
        p.sunSunset       = vec3(1.18, 0.52, 0.28);
        p.moonColor       = vec3(0.44, 0.58, 0.82);
        p.ambientDay      = vec3(0.32, 0.40, 0.52);
        p.ambientNight    = vec3(0.07, 0.10, 0.16);
        p.skyZenithDay    = vec3(0.14, 0.22, 0.36);
        p.skyHorizonDay   = vec3(0.46, 0.52, 0.58);
        p.skyZenithNight  = vec3(0.008, 0.012, 0.024);
        p.skyHorizonNight = vec3(0.028, 0.036, 0.052);
        p.fogDayTint      = vec3(0.44, 0.49, 0.54);
        p.blocklightTint  = vec3(1.25, 0.64, 0.26);
        p.waterTint       = vec3(0.08, 0.22, 0.28);
    #elif COLOR_STYLE == 10
        // 10: Cyber Neon — Electric cyan/magenta atmosphere & punchy emissive contrast
        p.sunDay          = vec3(0.96, 1.04, 1.18);
        p.sunSunset       = vec3(1.35, 0.42, 0.85);
        p.moonColor       = vec3(0.38, 0.92, 1.25);
        p.ambientDay      = vec3(0.44, 0.42, 0.86);
        p.ambientNight    = vec3(0.18, 0.10, 0.38);
        p.skyZenithDay    = vec3(0.16, 0.14, 0.62);
        p.skyHorizonDay   = vec3(0.34, 0.82, 0.98);
        p.skyZenithNight  = vec3(0.045, 0.012, 0.125);
        p.skyHorizonNight = vec3(0.150, 0.045, 0.240);
        p.fogDayTint      = vec3(0.42, 0.68, 0.92);
        p.blocklightTint  = vec3(1.25, 0.50, 0.95);
        p.waterTint       = vec3(0.06, 0.48, 0.66);
    #elif COLOR_STYLE == 11
        // 11: Retro Warm Film — Analog Kodak 35mm faded sepia-cream film aesthetic
        p.sunDay          = vec3(1.14, 0.97, 0.78);
        p.sunSunset       = vec3(1.28, 0.66, 0.36);
        p.moonColor       = vec3(0.64, 0.72, 0.82);
        p.ambientDay      = vec3(0.50, 0.56, 0.62);
        p.ambientNight    = vec3(0.16, 0.18, 0.22);
        p.skyZenithDay    = vec3(0.24, 0.44, 0.64);
        p.skyHorizonDay   = vec3(0.84, 0.82, 0.74);
        p.skyZenithNight  = vec3(0.025, 0.028, 0.040);
        p.skyHorizonNight = vec3(0.085, 0.082, 0.088);
        p.fogDayTint      = vec3(0.84, 0.80, 0.72);
        p.blocklightTint  = vec3(1.16, 0.78, 0.42);
        p.waterTint       = vec3(0.18, 0.42, 0.44);
    #endif

    // Blend smoothly with neutral vanilla palette by COLOR_STYLE_STRENGTH
    float s = clamp(float(COLOR_STYLE_STRENGTH), 0.0, 1.5);
    if (abs(s - 1.0) > 0.001) {
        vec3 nSun   = vec3(1.00, 0.99, 0.97);
        vec3 nAmb   = vec3(0.54, 0.64, 0.80);
        vec3 nSkyZ  = vec3(0.24, 0.47, 0.92);
        vec3 nSkyH  = vec3(0.68, 0.82, 0.98);
        vec3 nFog   = vec3(0.72, 0.84, 0.98);
        vec3 nBlock = vec3(1.02, 0.78, 0.52);
        p.sunDay        = max(mix(nSun,   p.sunDay,        s), vec3(0.05));
        p.ambientDay    = max(mix(nAmb,   p.ambientDay,    s), vec3(0.05));
        p.skyZenithDay  = max(mix(nSkyZ,  p.skyZenithDay,  s), vec3(0.02));
        p.skyHorizonDay = max(mix(nSkyH,  p.skyHorizonDay, s), vec3(0.05));
        p.fogDayTint    = max(mix(nFog,   p.fogDayTint,    s), vec3(0.05));
        p.blocklightTint= max(mix(nBlock, p.blocklightTint,s), vec3(0.05));
    }

    return p;
}

StylePostGrade getStylePostGrade() {
    StylePostGrade g;
    g.colorMatrix   = mat3(1.0);
    g.shadowLift    = vec3(0.0);
    g.midtoneGamma  = vec3(1.0);
    g.highlightGain = vec3(1.0);
    g.saturation    = 1.00;
    g.vibrance      = 0.00;
    g.contrast      = 1.00;
    g.exposureMult  = 1.00;

    #if COLOR_STYLE == 0
        // 0: Classic Color
        g.colorMatrix = mat3(
             1.03, -0.01, -0.02,
            -0.01,  1.02, -0.01,
            -0.01,  0.00,  1.01
        );
        g.shadowLift    = vec3(-0.002, 0.000, 0.004);
        g.midtoneGamma  = vec3(1.00, 1.00, 0.99);
        g.highlightGain = vec3(1.03, 1.01, 0.97);
        g.saturation    = 1.08;
        g.vibrance      = 0.12;
        g.contrast      = 1.04;
        g.exposureMult  = 1.02;

    #elif COLOR_STYLE == 1
        // 1: Nostalgia Color
        g.colorMatrix = mat3(
             1.05,  0.02, -0.04,
             0.02,  1.00, -0.02,
            -0.03,  0.02,  0.96
        );
        g.shadowLift    = vec3(0.006, 0.009, 0.012);
        g.midtoneGamma  = vec3(1.04, 1.01, 0.94);
        g.highlightGain = vec3(1.08, 1.01, 0.90);
        g.saturation    = 0.92;
        g.vibrance      = 0.06;
        g.contrast      = 0.96;
        g.exposureMult  = 1.04;

    #elif COLOR_STYLE == 2
        // 2: Legecy Color
        g.colorMatrix = mat3(
             1.08, -0.03, -0.05,
            -0.02,  1.06, -0.04,
            -0.03, -0.02,  1.05
        );
        g.shadowLift    = vec3(-0.006, -0.004, 0.005);
        g.midtoneGamma  = vec3(1.02, 1.01, 0.98);
        g.highlightGain = vec3(1.10, 1.01, 0.91);
        g.saturation    = 1.18;
        g.vibrance      = 0.16;
        g.contrast      = 1.12;
        g.exposureMult  = 1.05;

    #elif COLOR_STYLE == 3
        // 3: Vanilla Enhanced
        g.colorMatrix   = mat3(1.0);
        g.shadowLift    = vec3(0.0);
        g.midtoneGamma  = vec3(1.0);
        g.highlightGain = vec3(1.00, 1.00, 1.00);
        g.saturation    = 1.02;
        g.vibrance      = 0.05;
        g.contrast      = 1.01;
        g.exposureMult  = 1.00;

    #elif COLOR_STYLE == 4
        // 4: Cinematic Filmic (Teal & Orange)
        g.colorMatrix = mat3(
             1.07,  0.01, -0.08,
            -0.02,  1.02,  0.00,
            -0.05,  0.05,  1.00
        );
        g.shadowLift    = vec3(-0.006, 0.006, 0.012);
        g.midtoneGamma  = vec3(1.02, 1.00, 0.97);
        g.highlightGain = vec3(1.10, 0.99, 0.89);
        g.saturation    = 0.96;
        g.vibrance      = 0.14;
        g.contrast      = 1.10;
        g.exposureMult  = 1.00;

    #elif COLOR_STYLE == 5
        // 5: Vibrant Fantasy
        g.colorMatrix = mat3(
             1.09, -0.04, -0.05,
            -0.04,  1.09, -0.05,
            -0.03, -0.02,  1.08
        );
        g.shadowLift    = vec3(0.004, 0.002, 0.010);
        g.midtoneGamma  = vec3(1.02, 1.03, 1.04);
        g.highlightGain = vec3(1.08, 1.04, 0.98);
        g.saturation    = 1.24;
        g.vibrance      = 0.25;
        g.contrast      = 1.06;
        g.exposureMult  = 1.06;

    #elif COLOR_STYLE == 6
        // 6: Nordic Cold
        g.colorMatrix = mat3(
             0.94,  0.02,  0.04,
             0.00,  1.00,  0.02,
             0.02,  0.03,  1.05
        );
        g.shadowLift    = vec3(-0.004, 0.002, 0.010);
        g.midtoneGamma  = vec3(0.95, 1.00, 1.06);
        g.highlightGain = vec3(0.96, 1.00, 1.07);
        g.saturation    = 0.86;
        g.vibrance      = 0.08;
        g.contrast      = 1.08;
        g.exposureMult  = 1.00;

    #elif COLOR_STYLE == 7
        // 7: Golden Hour
        g.colorMatrix = mat3(
             1.10,  0.03, -0.06,
             0.02,  0.99, -0.04,
            -0.04, -0.02,  0.90
        );
        g.shadowLift    = vec3(0.006, 0.002, 0.008);
        g.midtoneGamma  = vec3(1.08, 0.99, 0.88);
        g.highlightGain = vec3(1.16, 0.98, 0.82);
        g.saturation    = 1.12;
        g.vibrance      = 0.14;
        g.contrast      = 1.05;
        g.exposureMult  = 1.03;

    #elif COLOR_STYLE == 8
        // 8: Pastel Dream
        g.colorMatrix = mat3(
             0.96,  0.03,  0.02,
             0.02,  0.96,  0.03,
             0.03,  0.02,  0.98
        );
        g.shadowLift    = vec3(0.018, 0.016, 0.024);
        g.midtoneGamma  = vec3(1.03, 1.02, 1.05);
        g.highlightGain = vec3(1.05, 1.02, 1.06);
        g.saturation    = 0.88;
        g.vibrance      = 0.20;
        g.contrast      = 0.88;
        g.exposureMult  = 1.08;

    #elif COLOR_STYLE == 9
        // 9: Dark Moody
        g.colorMatrix = mat3(
             0.98,  0.02,  0.00,
             0.01,  0.96,  0.02,
             0.00,  0.03,  0.96
        );
        g.shadowLift    = vec3(-0.010, -0.008, -0.004);
        g.midtoneGamma  = vec3(0.94, 0.96, 1.00);
        g.highlightGain = vec3(1.02, 0.99, 0.96);
        g.saturation    = 0.78;
        g.vibrance      = 0.10;
        g.contrast      = 1.20;
        g.exposureMult  = 0.90;

    #elif COLOR_STYLE == 10
        // 10: Cyber Neon
        g.colorMatrix = mat3(
             1.08, -0.06,  0.04,
            -0.05,  1.04,  0.02,
             0.05, -0.03,  1.10
        );
        g.shadowLift    = vec3(0.010, -0.004, 0.018);
        g.midtoneGamma  = vec3(0.98, 1.02, 1.08);
        g.highlightGain = vec3(1.08, 1.00, 1.14);
        g.saturation    = 1.26;
        g.vibrance      = 0.28;
        g.contrast      = 1.18;
        g.exposureMult  = 1.02;

    #elif COLOR_STYLE == 11
        // 11: Retro Warm Film
        g.colorMatrix = mat3(
             1.04,  0.06, -0.05,
             0.02,  0.98, -0.02,
            -0.04,  0.05,  0.91
        );
        g.shadowLift    = vec3(0.016, 0.014, 0.010);
        g.midtoneGamma  = vec3(1.04, 1.00, 0.92);
        g.highlightGain = vec3(1.08, 1.01, 0.88);
        g.saturation    = 0.84;
        g.vibrance      = 0.04;
        g.contrast      = 0.94;
        g.exposureMult  = 1.02;
    #endif

    return g;
}

#endif // LIB_COLOR_STYLES_GLSL
