#version 330 compatibility
#define VERTEX_SHADER
#define NETHER
#define HAND_PASS
#include "/program/gbuffers_terrain.glsl"
