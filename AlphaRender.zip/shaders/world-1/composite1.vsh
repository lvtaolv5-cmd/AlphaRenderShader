#version 330 compatibility
#define VERTEX_SHADER
#define NETHER
#include "/program/composite1.glsl"
