#ifndef LIB_WAVING_GLSL
#define LIB_WAVING_GLSL

vec3 computeWavingOffset(vec3 worldPos, int blockId, vec2 uvMidOffset, float timeSec, float rainStrength) {
    vec3 offset = vec3(0.0);
    float speed = timeSec * float(WAVING_SPEED) * (1.0 + rainStrength * 0.55);
    float windAmp = 1.0 + rainStrength * 0.65;

    #ifdef WAVING_FOLIAGE
        // 10001: Short grass / flowers / saplings / ferns (wave top vertices)
        if (blockId == 10001) {
            float topMask = uvMidOffset.y < 0.0 ? 1.0 : 0.0;
            float phase = speed * 2.3 + worldPos.x * 0.7 + worldPos.z * 0.5 + worldPos.y * 0.3;
            float swayX = (sin(phase) * 0.065 + sin(phase * 2.1 + 1.3) * 0.025) * windAmp;
            float swayZ = (cos(phase * 0.85 + 0.7) * 0.055) * windAmp;
            offset.xz += vec2(swayX, swayZ) * topMask;
        }
        // 10002: Tall plants / double flowers / crops
        else if (blockId == 10002) {
            float topMask = uvMidOffset.y < 0.0 ? 1.0 : 0.35;
            float phase = speed * 2.0 + worldPos.x * 0.55 + worldPos.z * 0.65;
            offset.x += (sin(phase) * 0.07 + sin(phase * 1.9) * 0.025) * windAmp * topMask;
            offset.z += (cos(phase * 0.9 + 0.5) * 0.055) * windAmp * topMask;
        }
        // 10003: Leaves (gentle 3D canopy rustle)
        else if (blockId == 10003) {
            float phase = speed * 1.7 + worldPos.x * 0.45 + worldPos.y * 0.55 + worldPos.z * 0.45;
            offset.x += (sin(phase) * 0.032 + sin(phase * 2.3) * 0.012) * windAmp;
            offset.y += (cos(phase * 1.25 + 0.8) * 0.018) * windAmp;
            offset.z += (sin(phase * 0.9 + 1.7) * 0.030) * windAmp;
        }
        // 10004: Vines / hanging foliage / lanterns
        else if (blockId == 10004) {
            float phase = speed * 1.85 + worldPos.x * 0.6 + worldPos.z * 0.6 + worldPos.y * 0.4;
            offset.x += sin(phase) * 0.045 * windAmp;
            offset.z += cos(phase * 0.95) * 0.045 * windAmp;
        }
    #endif

    #ifdef WAVING_WATER
        // 10010: Water surface subtle vertical bobbing
        if (blockId == 10010) {
            float phase = speed * 2.1 * float(WATER_WAVE_SPEED) + worldPos.x * 0.85 + worldPos.z * 0.72;
            float h = sin(phase) * 0.032 + cos(phase * 0.73 - worldPos.z * 0.9) * 0.022;
            offset.y += h * float(WATER_WAVES_STRENGTH) * 0.65;
        }
    #endif

    return offset;
}

#endif // LIB_WAVING_GLSL
