#version 330 compatibility
#define VERTEX_SHADER
#define END
#define HAND_WATER_PASS
#include "/program/gbuffers_water.glsl"
