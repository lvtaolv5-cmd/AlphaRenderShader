#version 330 compatibility
#define VERTEX_SHADER
#define NETHER
#include "/program/deferred.glsl"
