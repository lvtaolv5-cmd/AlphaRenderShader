#version 330 compatibility
#define FRAGMENT_SHADER
#define END
#define TERRAIN_PASS
#include "/program/gbuffers_terrain.glsl"
