#ifndef LIB_SHADOWS_GLSL
#define LIB_SHADOWS_GLSL

const float SHADOW_DISTORT_BIAS = 0.85;

float getShadowDistortFactor(vec2 posXY) {
    return length(posXY) * SHADOW_DISTORT_BIAS + (1.0 - SHADOW_DISTORT_BIAS);
}

vec2 distortShadowXY(vec2 posXY) {
    return posXY / max(getShadowDistortFactor(posXY), 1e-4);
}

vec3 worldToShadowClip(vec3 playerPos, mat4 shadowMV, mat4 shadowProj) {
    vec4 shadowPos = shadowProj * (shadowMV * vec4(playerPos, 1.0));
    return shadowPos.xyz / max(abs(shadowPos.w), 1e-5);
}

// High-Performance 1:1 Geometry-Aligned Forced Pixel-Locked Shadows
// Covers Terrain, Entities (mobs/players), Block Entities (chests/signs/beds), and Water!
vec3 sampleShadows(
    vec3 playerPos,
    vec3 cameraPos,
    vec3 worldNormal,
    float NdotL,
    bool isFoliage,
    vec2 fragCoord,
    int frameCounter,
    mat4 shadowMV,
    mat4 shadowProj,
    sampler2D shadowTexAll,
    sampler2D shadowTexOpaque,
    sampler2D shadowColTex
) {
    #ifdef SHADOW_ENABLED
    #if !defined(NETHER) && !defined(END)
        // Back-facing opaque surfaces are naturally in self-shadow (zero shadow fetch!)
        if (!isFoliage && NdotL <= 0.002) {
            return vec3(0.0);
        }

        float distFade = 1.0 - smoothstep(shadowDistance * 0.78, shadowDistance * 0.98, length(playerPos.xz));
        if (distFade <= 0.001) return vec3(1.0);

        // ---------- FORCED WORLD-SPACE PIXEL LOCKING ----------
        float pixRes = float(SHADOW_PIXEL);
        vec3 stableWorld = playerPos + mod(cameraPos, 64.0);
        vec3 epsNormal = worldNormal * (0.04 / pixRes);
        vec3 snappedWorld = (floor((stableWorld + epsNormal) * pixRes) + 0.5) / pixRes;
        vec3 worldDiff = snappedWorld - stableWorld;
        vec3 tangentDiff = worldDiff - worldNormal * dot(worldDiff, worldNormal);
        vec3 pixelPlayerPos = playerPos + tangentDiff;

        vec3 baseClip = worldToShadowClip(pixelPlayerPos, shadowMV, shadowProj);
        float distortF = getShadowDistortFactor(baseClip.xy);
        float texelWorld = (shadowDistance * 2.0 / float(shadowMapResolution)) * distortF;

        float clampedNdotL = clamp(NdotL, 0.05, 1.0);
        float slope = sqrt(max(1.0 - clampedNdotL * clampedNdotL, 0.0));
        float normalOffset = (0.20 / pixRes + (0.28 + slope * 0.65) * texelWorld) * float(SHADOW_BIAS);
        if (isFoliage) normalOffset *= 0.45;

        vec3 biasedPlayerPos = pixelPlayerPos + worldNormal * normalOffset;
        vec3 clipPos = worldToShadowClip(biasedPlayerPos, shadowMV, shadowProj);
        float dFactor = getShadowDistortFactor(clipPos.xy);
        vec2 distortedXY = clipPos.xy / max(dFactor, 1e-4);

        vec3 shadowUV;
        shadowUV.xy = distortedXY * 0.5 + 0.5;
        shadowUV.z  = clipPos.z * 0.5 + 0.5;

        if (shadowUV.x < 0.002 || shadowUV.x > 0.998 || shadowUV.y < 0.002 || shadowUV.y > 0.998 || shadowUV.z <= 0.0001 || shadowUV.z >= 0.9999) {
            return vec3(1.0);
        }

        float depthBias = (0.00018 + 0.00028 * dFactor * dFactor + (0.0006 / pixRes)) * float(SHADOW_BIAS) * (2048.0 / float(shadowMapResolution));
        if (isFoliage) depthBias = 0.00065 * float(SHADOW_BIAS);
        float compareZ = shadowUV.z - depthBias;

        // Ultra-fast 1-tap crisp pixel shadow on Quality 1 OR when SHADOW_SOFTNESS == 0.0!
        float softness = float(SHADOW_SOFTNESS);
        #if SHADOW_QUALITY == 1
            bool singleTap = true;
        #else
            bool singleTap = (softness <= 0.001);
        #endif

        if (singleTap) {
            float depthOpaque = texture(shadowTexOpaque, shadowUV.xy).r;
            float visOpaque = step(compareZ, depthOpaque);
            #ifdef SHADOW_COLORED
                if (visOpaque > 0.5) {
                    float depthAll = texture(shadowTexAll, shadowUV.xy).r;
                    if (step(compareZ, depthAll) < 0.5) {
                        vec4 sCol = texture(shadowColTex, shadowUV.xy);
                        vec3 tint = srgbToLinear(sCol.rgb);
                        vec3 colored = mix(vec3(1.0), tint * 1.35, clamp(sCol.a * 1.15, 0.2, 0.92));
                        return mix(vec3(1.0), colored, distFade);
                    }
                }
            #endif
            return mix(vec3(1.0), vec3(visOpaque), distFade);
        }

        // Optimized Pixel-Shadow PCF tap counts (2x-3x faster & crisper pixel steps!)
        #if SHADOW_QUALITY == 2
            const int TAP_COUNT = 4;
        #elif SHADOW_QUALITY == 3
            const int TAP_COUNT = 8;
        #else
            const int TAP_COUNT = 12;
        #endif

        float filterRadius = (0.65 * softness) / float(shadowMapResolution);
        filterRadius /= max(dFactor * 0.75 + 0.25, 0.35);

        float rotAngle = interleavedGradientNoise(snappedWorld.xz * pixRes + snappedWorld.yy * (pixRes * 0.73)) * TAU;
        float cRot = cos(rotAngle);
        float sRot = sin(rotAngle);
        mat2 rotMat = mat2(cRot, -sRot, sRot, cRot);

        vec3 shadowAccum = vec3(0.0);
        for (int i = 0; i < TAP_COUNT; i++) {
            float r = sqrt((float(i) + 0.5) / float(TAP_COUNT));
            float theta = float(i) * GOLDEN_ANGLE;
            vec2 offset = rotMat * (vec2(cos(theta), sin(theta)) * r * filterRadius);
            vec2 sampleUV = clamp(shadowUV.xy + offset, vec2(0.001), vec2(0.999));

            float depthOpaque = texture(shadowTexOpaque, sampleUV).r;
            float visOpaque = step(compareZ, depthOpaque);

            #ifdef SHADOW_COLORED
                // Early skip translucent shadowtex0/shadowcolor0 fetches when already in opaque shadow!
                if (visOpaque > 0.5) {
                    float depthAll = texture(shadowTexAll, sampleUV).r;
                    if (step(compareZ, depthAll) < 0.5) {
                        vec4 sCol = texture(shadowColTex, sampleUV);
                        vec3 tint = srgbToLinear(sCol.rgb);
                        shadowAccum += mix(vec3(1.0), tint * 1.35, clamp(sCol.a * 1.15, 0.2, 0.92));
                    } else {
                        shadowAccum += vec3(1.0);
                    }
                }
            #else
                shadowAccum += vec3(visOpaque);
            #endif
        }

        vec3 visibility = shadowAccum / float(TAP_COUNT);
        return mix(vec3(1.0), visibility, distFade);
    #else
        return vec3(1.0);
    #endif
    #else
        return vec3(1.0);
    #endif
}

#endif // LIB_SHADOWS_GLSL
