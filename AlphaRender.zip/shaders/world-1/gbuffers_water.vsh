#version 330 compatibility
#define VERTEX_SHADER
#define NETHER
#define WATER_PASS
#include "/program/gbuffers_water.glsl"
