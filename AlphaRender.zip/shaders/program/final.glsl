#include "/lib/settings.glsl"
#include "/lib/common.glsl"

#ifdef VERTEX_SHADER

out vec2 vTexCoord;

void main() {
    vTexCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    gl_Position = ftransform();
}

#endif // VERTEX_SHADER

#ifdef FRAGMENT_SHADER

#include "/lib/antialiasing.glsl"
#include "/lib/colorGrading.glsl"

uniform sampler2D colortex0;
uniform sampler2D colortex5;
uniform sampler2D depthtex0;

uniform float viewWidth;
uniform float viewHeight;
uniform float near;
uniform float far;
uniform int frameCounter;

in vec2 vTexCoord;

layout(location = 0) out vec4 outFinalColor;

vec3 sampleSpatialAA(vec2 uv, vec2 texel) {
    #if AA_USES_FXAA
        return computeFXAA(uv, texel, colortex0);
    #elif AA_USES_SMAA
        return computeSMAA(uv, texel, colortex0);
    #else
        return sanitizeHDR(texture(colortex0, uv).rgb);
    #endif
}

void main() {
    vec2 viewSize = max(vec2(viewWidth, viewHeight), vec2(1.0));
    vec2 texel = 1.0 / viewSize;

    // 1. Spatial Anti-Aliasing (FXAA 3.11 / SMAA Morphological) + Optional Radial Chromatic Aberration
    vec3 hdrColor;
    #ifdef CA_ENABLED
        vec2 radial = vTexCoord - 0.5;
        float dist2 = dot(radial, radial);
        vec2 caOffset = radial * dist2 * 0.012 * float(CA_STRENGTH);
        vec3 baseCenter = sampleSpatialAA(vTexCoord, texel);
        float rCh = sanitizeHDR(texture(colortex0, clamp(vTexCoord + caOffset, vec2(0.001), vec2(0.999))).rgb).r;
        float bCh = sanitizeHDR(texture(colortex0, clamp(vTexCoord - caOffset, vec2(0.001), vec2(0.999))).rgb).b;
        hdrColor = vec3(mix(baseCenter.r, rCh, 0.85), baseCenter.g, mix(baseCenter.b, bCh, 0.85));
    #else
        hdrColor = sampleSpatialAA(vTexCoord, texel);
    #endif

    // 2. Distance-Aware Contrast Adaptive Sharpening (restores crisp far-terrain detail under TAA!)
    float extraFarSharp = 0.0;
    #if AA_USES_TAA
        float rawD = texture(depthtex0, vTexCoord).r;
        if (rawD < 0.9999) {
            float linD = linearizeDepth(rawD, near, far);
            float farMask = smoothstep(26.0, 120.0, linD);
            extraFarSharp = farMask * float(TAA_FAR_SHARPNESS) * 0.28;
        }
    #endif
    hdrColor = applyCASSharpening(hdrColor, vTexCoord, texel, extraFarSharp, colortex0);

    // 3. Smooth Auto-Exposure Gain (read strictly from persistent texel (0, 0)!)
    float autoGain = 1.0;
    #ifdef AUTO_EXPOSURE
        float avgLum = texelFetch(colortex5, ivec2(0, 0), 0).a;
        if (avgLum > 1e-4 && !isnan(avgLum) && !isinf(avgLum)) {
            autoGain = clamp(float(AUTO_EXPOSURE_TARGET) / max(avgLum, 0.02), float(AUTO_EXPOSURE_MIN), float(AUTO_EXPOSURE_MAX));
        }
    #endif

    // 4. Master Color Grading: 12 Color Styles + Global RGB Tone + 3-Way RGB Balance + 6 Tonemappers
    vec3 srgbColor = applyMasterColorGrading(hdrColor, autoGain);

    // 5. Lens Finishing: Vignette, Film Grain & Triangular-PDF Anti-Banding Dither
    srgbColor = applyLensFinishing(srgbColor, vTexCoord, gl_FragCoord.xy, frameCounter);

    outFinalColor = vec4(srgbColor, 1.0);
}

#endif // FRAGMENT_SHADER
