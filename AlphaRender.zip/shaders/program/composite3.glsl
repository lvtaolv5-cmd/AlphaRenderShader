#include "/lib/settings.glsl"
#include "/lib/common.glsl"

#ifdef VERTEX_SHADER

out vec2 vTexCoord;

void main() {
    vTexCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    gl_Position = ftransform();
}

#endif // VERTEX_SHADER

#ifdef FRAGMENT_SHADER

#include "/lib/bloomGlare.glsl"

uniform sampler2D colortex0;
uniform sampler2D colortex4;
uniform sampler2D colortex6;
uniform float viewWidth;
uniform float viewHeight;

in vec2 vTexCoord;

/* RENDERTARGETS:0 */
layout(location = 0) out vec4 outScene;

void main() {
    vec2 halfTexelSize = 2.0 / max(vec2(viewWidth, viewHeight), vec2(2.0));

    vec3 sceneCol = sanitizeHDR(texture(colortex0, vTexCoord).rgb);
    vec3 bloom    = sampleCombinedBloom(vTexCoord, halfTexelSize, colortex6);
    vec3 glare    = sampleHalfResGlare(vTexCoord, colortex4);

    outScene = vec4(sanitizeHDR(sceneCol + bloom + glare), 1.0);
}

#endif // FRAGMENT_SHADER
