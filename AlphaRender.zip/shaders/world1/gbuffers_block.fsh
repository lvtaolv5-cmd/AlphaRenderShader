#version 330 compatibility
#define FRAGMENT_SHADER
#define END
#define BLOCK_PASS
#include "/program/gbuffers_terrain.glsl"
