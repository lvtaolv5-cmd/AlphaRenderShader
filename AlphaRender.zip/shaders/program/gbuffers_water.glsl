#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/jitter.glsl"
#include "/lib/waving.glsl"
#include "/lib/lighting.glsl"

#ifdef VERTEX_SHADER

#ifndef HAND_WATER_PASS
in vec3 mc_Entity;
in vec2 mc_midTexCoord;
#endif

uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform vec3 cameraPosition;
uniform vec3 shadowLightPosition;
uniform vec3 sunPosition;
uniform vec3 upPosition;
uniform float frameTimeCounter;
uniform float rainStrength;
uniform float viewWidth;
uniform float viewHeight;
uniform int frameCounter;
uniform int isEyeInWater;
uniform int heldBlockLightValue;
uniform int heldBlockLightValue2;

out vec2 vTexCoord;
out vec2 vLmCoordRaw;
out vec2 vLmCoord;
out vec4 vColor;
out vec3 vViewPos;
out vec3 vPlayerPos;
out vec3 vViewNormal;
out vec3 vWorldNormal;
flat out int vBlockId;

flat out vec3 fShadowLightDir;
flat out vec3 fStyleSkyTint;
flat out vec3 fSunLightColor;
flat out vec3 fBlocklightTint;
flat out vec3 fAmbientDay;
flat out vec3 fWaterTint;
flat out vec2 fDayHorizon;

void main() {
    vTexCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    vec2 lmRaw = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    vColor = gl_Color;

    #ifndef HAND_WATER_PASS
        vBlockId = int(mc_Entity.x + 0.5);
    #else
        vBlockId = 0;
    #endif

    vec4 viewPos = gl_ModelViewMatrix * gl_Vertex;
    vec3 playerPos = (gbufferModelViewInverse * viewPos).xyz;

    #ifndef HAND_WATER_PASS
        if (vBlockId == 10010) {
            vec2 uvMidOffset = vTexCoord - mc_midTexCoord;
            vec3 wave = computeWavingOffset(playerPos + cameraPosition, vBlockId, uvMidOffset, frameTimeCounter, rainStrength);
            playerPos += wave;
            viewPos = gbufferModelView * vec4(playerPos, 1.0);
        }
    #endif

    #ifdef DYNAMIC_HANDLIGHT
        float heldVal = max(float(heldBlockLightValue), float(heldBlockLightValue2));
        if (heldVal > 0.5 && isEyeInWater != 1 && isEyeInWater != 2) {
            float handLevel = max(heldVal - 1.0 - length(viewPos.xyz), 0.0) / 15.0;
            lmRaw.x = max(lmRaw.x, handLevel * 0.9375 + 0.03125);
        }
    #endif

    vLmCoordRaw = clamp(lmRaw, vec2(0.03125), vec2(0.96875));
    vLmCoord = saturate((lmRaw - 0.03125) / 0.9375);

    vViewPos = viewPos.xyz;
    vPlayerPos = playerPos;
    vViewNormal = safeNormalize(gl_NormalMatrix * gl_Normal);
    vWorldNormal = safeNormalize(mat3(gbufferModelViewInverse) * vViewNormal);

    StyleLightingPalette pal = getStyleLightingPalette();
    VertexLightData ld = precomputeVertexLightData(shadowLightPosition, sunPosition, upPosition, rainStrength);
    fShadowLightDir = ld.shadowLightDir;
    fStyleSkyTint   = ld.styleSkyTint;
    fSunLightColor  = ld.sunLightColor;
    fBlocklightTint = ld.blocklightTint;
    fAmbientDay     = ld.ambientDay;
    fWaterTint      = pal.waterTint;
    fDayHorizon     = vec2(ld.dayFactor, ld.horizonFade);

    gl_Position = gl_ProjectionMatrix * viewPos;

    #ifndef HAND_WATER_PASS
        gl_Position.xy += getClipJitterOffset(frameCounter, viewWidth, viewHeight) * gl_Position.w;
    #endif
}

#endif // VERTEX_SHADER

#ifdef FRAGMENT_SHADER

#include "/lib/shadows.glsl"
#include "/lib/atmosphere.glsl"
#include "/lib/water.glsl"

// ONLY Iris-guaranteed gbuffer samplers! (ZERO colortex* in gbuffers_water!)
uniform sampler2D tex;
uniform sampler2D lightmap;
uniform sampler2D shadowtex0;
uniform sampler2D shadowtex1;
uniform sampler2D shadowcolor0;

uniform mat4 gbufferModelView;
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;

uniform vec3 cameraPosition;
uniform vec3 sunPosition;
uniform vec3 upPosition;
uniform vec3 fogColor;
uniform ivec2 eyeBrightnessSmooth;
uniform float frameTimeCounter;
uniform float rainStrength;
uniform float wetness;
uniform float far;
uniform int frameCounter;
uniform int isEyeInWater;

in vec2 vTexCoord;
in vec2 vLmCoordRaw;
in vec2 vLmCoord;
in vec4 vColor;
in vec3 vViewPos;
in vec3 vPlayerPos;
in vec3 vViewNormal;
in vec3 vWorldNormal;
flat in int vBlockId;

flat in vec3 fShadowLightDir;
flat in vec3 fStyleSkyTint;
flat in vec3 fSunLightColor;
flat in vec3 fBlocklightTint;
flat in vec3 fAmbientDay;
flat in vec3 fWaterTint;
flat in vec2 fDayHorizon;

/* RENDERTARGETS:0,1,2 */
layout(location = 0) out vec4 outColor;
layout(location = 1) out vec4 outNormalMat;
layout(location = 2) out vec4 outEmissive;

void main() {
    vec4 rawTex = texture(tex, vTexCoord);
    vec4 texSample = rawTex * vColor;
    if (texSample.a < 0.01) discard;

    bool isWater = (vBlockId == 10010);
    vec3 wNorm = safeNormalize(vWorldNormal);
    vec3 vNorm = safeNormalize(vViewNormal);
    float distToCam = length(vViewPos);
    vec3 worldPos = vPlayerPos + cameraPosition;

    vec3 linearAlbedo = srgbToLinear(texSample.rgb);
    vec3 vanillaLightmapLin = srgbToLinear(texture(lightmap, vLmCoordRaw).rgb);

    if (isWater) {
        vec2 waveSlope = vec2(0.0);
        float waveH = 0.0;
        #if WATER_MODE == 0
            wNorm = computeWaterWorldNormal(worldPos, wNorm, frameTimeCounter, distToCam, false, waveSlope, waveH);
            wNorm = safeNormalize(mix(safeNormalize(vWorldNormal), wNorm, 0.25));
        #elif WATER_MODE == 1 || WATER_MODE == 2
            wNorm = computeWaterWorldNormal(worldPos, wNorm, frameTimeCounter, distToCam, false, waveSlope, waveH);
        #else
            wNorm = computeWaterWorldNormal(worldPos, wNorm, frameTimeCounter, distToCam, true, waveSlope, waveH);
        #endif
        vNorm = safeNormalize(mat3(gbufferModelView) * wNorm);
        vec3 faceNorm = gl_FrontFacing ? vNorm : -vNorm;

        if (isEyeInWater == 1) {
            vec3 V = safeNormalize(-vViewPos);
            float snell = smoothstep(0.45, 0.72, max(dot(faceNorm, V), 0.0));
            vec3 uwTint = mix(fWaterTint * 0.45 * vanillaLightmapLin, linearAlbedo * vanillaLightmapLin, 0.35);
            outColor = vec4(sanitizeHDR(uwTint), mix(0.55, 0.14, snell));
            outNormalMat = vec4(encodeNormal(faceNorm), MAT_TRANS, vLmCoord.y);
            outEmissive = vec4(0.0);
            return;
        }

        vec3 shadowVis = vec3(1.0);
        #ifndef HAND_WATER_PASS
            float NdotLS = max(dot(faceNorm, fShadowLightDir), 0.0);
            if (vLmCoord.y > 0.02) {
                shadowVis = sampleShadows(
                    vPlayerPos, cameraPosition, safeNormalize(vWorldNormal), NdotLS, false,
                    gl_FragCoord.xy, frameCounter,
                    shadowModelView, shadowProjection, shadowtex0, shadowtex1, shadowcolor0
                );
            } else {
                shadowVis = vec3(0.0);
            }
        #endif

        vec3 V = safeNormalize(-vViewPos);
        vec3 H = safeNormalize(fShadowLightDir + V);
        float NdotH = max(dot(faceNorm, H), 0.0);
        float specTight = pow(NdotH, WATER_MODE == 3 ? 220.0 : 120.0) * (WATER_MODE == 3 ? 3.8 : 2.0);
        float specBroad = pow(NdotH, 26.0) * (WATER_MODE == 3 ? 0.22 : 0.12);
        vec3 specular = fSunLightColor * (specTight + specBroad) * shadowVis * (1.0 - rainStrength * 0.80) * smoothstep(0.1, 0.6, vLmCoord.y);

        vec3 biomeLinear = srgbToLinear(vColor.rgb);

        #if WATER_MODE == 0
            vec3 vanillaSurface = linearAlbedo * vanillaLightmapLin * 1.08 + specular * 0.35;
            vanillaSurface = applyAtmosphericFog(vanillaSurface, vViewPos, vPlayerPos, sunPosition, upPosition, far, rainStrength, isEyeInWater, fogColor);
            outColor     = vec4(sanitizeHDR(vanillaSurface), clamp(texSample.a * 0.86, 0.35, 0.88));
            outNormalMat = vec4(encodeNormal(faceNorm), MAT_WATER, vLmCoord.y);
            outEmissive  = vec4(saturate(specular * 0.14), maxOf(specular) > 0.30 ? 0.5 : 0.0);
        #elif WATER_MODE == 1
            vec3 enhancedTex = linearAlbedo * vanillaLightmapLin * 1.24;
            vec3 vibrantTint = mix(biomeLinear, fWaterTint * 1.30, 0.36) * vanillaLightmapLin;
            vec3 surfaceBody = mix(enhancedTex, enhancedTex * 0.74 + vibrantTint * 0.42, 0.48);
            outColor     = vec4(sanitizeHDR(surfaceBody), 1.0);
            outNormalMat = vec4(encodeNormal(faceNorm), MAT_WATER, vLmCoord.y);
            outEmissive  = vec4(saturate(specular * 0.25), maxOf(specular) > 0.20 ? 0.5 : 0.0);
        #elif WATER_MODE == 2
            vec3 cleanWaterColor = mix(biomeLinear * 0.85, fWaterTint * 1.15, 0.46) * vanillaLightmapLin;
            outColor     = vec4(sanitizeHDR(cleanWaterColor), 1.0);
            outNormalMat = vec4(encodeNormal(faceNorm), MAT_WATER, vLmCoord.y);
            outEmissive  = vec4(saturate(specular * 0.25), maxOf(specular) > 0.20 ? 0.5 : 0.0);
        #else
            vec3 scatterCol = mix(biomeLinear * 0.55, fWaterTint * 0.95, 0.52) * vanillaLightmapLin;
            float waveSSS = saturate(waveH * 4.5 + 0.35) * fDayHorizon.x * shadowVis.r * vLmCoord.y;
            scatterCol += vec3(0.04, 0.24, 0.26) * fSunLightColor * waveSSS * 0.55;
            outColor     = vec4(sanitizeHDR(scatterCol), 1.0);
            outNormalMat = vec4(encodeNormal(faceNorm), MAT_WATER, vLmCoord.y);
            outEmissive  = vec4(saturate(specular * 0.25), maxOf(specular) > 0.15 ? 0.5 : 0.0);
        #endif
        return;
    }

    // Non-water translucents
    vec3 shadowVis = vec3(1.0);
    #ifndef HAND_WATER_PASS
        float NdotLS = max(dot(vNorm, fShadowLightDir), 0.0);
        if (vLmCoord.y > 0.02) {
            shadowVis = sampleShadows(
                vPlayerPos, cameraPosition, wNorm, NdotLS, false,
                gl_FragCoord.xy, frameCounter,
                shadowModelView, shadowProjection, shadowtex0, shadowtex1, shadowcolor0
            );
        } else {
            shadowVis = vec3(0.0);
        }
    #endif

    vec3 specBloom = vec3(0.0);
    vec3 litBase = computeHybridSurfaceLightingFast(
        linearAlbedo, vanillaLightmapLin, vNorm, wNorm, vViewPos,
        vLmCoord, 1.0, shadowVis, false,
        fShadowLightDir, fStyleSkyTint, fSunLightColor, fBlocklightTint, fAmbientDay,
        fDayHorizon.x, fDayHorizon.y,
        rainStrength, wetness, eyeBrightnessSmooth.y, specBloom
    );

    vec3 V = safeNormalize(-vViewPos);
    float fresnel = 0.04 + 0.96 * pow(1.0 - max(dot(vNorm, V), 0.0), 5.0);
    vec3 skyRefl = computeSkyColor(reflect(-V, vNorm), sunPosition, upPosition, rainStrength, fogColor) * vLmCoord.y;
    vec3 finalTrans = mix(litBase, skyRefl, fresnel * 0.30);

    vec3 emitCol = vec3(0.0);
    if (vBlockId == 10102) {
        emitCol = linearAlbedo * 1.55 * float(EMISSIVE_STRENGTH);
        finalTrans += emitCol;
    }

    #ifndef HAND_WATER_PASS
        finalTrans = applyAtmosphericFog(finalTrans, vViewPos, vPlayerPos, sunPosition, upPosition, far, rainStrength, isEyeInWater, fogColor);
        float matId = MAT_TRANS;
    #else
        float matId = MAT_HAND;
    #endif

    outColor = vec4(sanitizeHDR(finalTrans), texSample.a);
    outNormalMat = vec4(encodeNormal(vNorm), matId, vLmCoord.y);
    outEmissive = vec4(saturate(emitCol * 0.25), maxOf(emitCol) > 0.05 ? 0.5 : 0.0);
}

#endif // FRAGMENT_SHADER
